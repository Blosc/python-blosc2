#######################################################################
# Copyright (c) 2019-present, Blosc Development Team <blosc@blosc.org>
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#######################################################################

# Avoid checking the name of type annotations at run time
from __future__ import annotations

import ast
import builtins
import concurrent.futures
import contextlib
import contextvars
import copy
import enum
import math
import operator
import os
import pathlib
import re
import sys
import threading
import warnings
from abc import ABC, abstractmethod, abstractproperty
from collections import OrderedDict
from collections.abc import MutableMapping
from dataclasses import asdict, dataclass, field
from enum import Enum
from functools import lru_cache
from pathlib import Path
from queue import Empty, Full, Queue
from typing import TYPE_CHECKING, Any

from numpy.exceptions import ComplexWarning

from . import exceptions

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

import ndindex
import numpy as np

import blosc2
from blosc2 import compute_chunks_blocks
from blosc2.info import InfoReporter

from .b2objects import (
    encode_b2object_payload,
    encode_operand_reference,
    make_b2object_carrier,
    read_b2object_user_vlmeta,
    write_b2object_payload,
    write_b2object_user_vlmeta,
)
from .dsl_kernel import DSLSyntaxError, DSLValidator, specialize_miniexpr_inputs
from .dsl_kernel import SourceKernel as DSLKernel
from .expression_evaluator import (
    binary_result_dtype,
    compute_typed_prefilter,
    compute_typed_reduction,
    typed_evaluator_enabled,
)
from .expression_graph import (
    _NUMPY_VALUE_PROMOTION,
    arithmetic_names,
    evaluate_expression,
    evaluation_mode,
    expression_constructor,
    expression_evaluation,
    expression_method,
    expression_syntax,
    normalize_operands,
    parse_expression,
    record_expression_metadata,
    validate_operands,
)
from .ndarray import blocks_contiguous
from .ndarray import chunks_tile_flat as _chunks_tile_flat
from .prepared_evaluate import remember_evaluation
from .proxy_source import convert_dtype
from .utils import (
    check_smaller_shape,
    compute_smaller_slice,
    constructors,
    elementwise_funcs,
    format_expr_scalar,
    get_chunk_operands,
    get_chunks_idx,
    get_intersecting_chunks,
    infer_shape,
    linalg_attrs,
    linalg_funcs,
    npcumprod,
    npcumsum,
    populate_safe_numpy_globals,
    process_key,
    reducers,
    safe_numpy_globals,
    sliced_chunk_iter,
    try_miniexpr,
)

# Canonical expression text has no quoted strings or attribute names to rewrite.
_IDENTIFIER_RE = re.compile(r"\b[A-Za-z_]\w*\b")


def _int64_datetime_operands(local_dict):
    """Return `local_dict` with datetime64/timedelta64 values viewed as int64.

    Both are int64 counts underneath, so a comparison against a count is exact
    in that representation. Returns None when the substitution would not be faithful:

    * mixed units, because the counts are then on different scales (NumPy
      promotes to the finer unit instead);
    * NaT, which views as INT64_MIN and would come out as the smallest value
      rather than never comparing true.

    Both cases are rare and correctly handled by the NumPy fallback, just more
    slowly.
    """
    converted = {}
    units = set()
    for key, value in local_dict.items():
        dtype = getattr(value, "dtype", None)
        # Frame locals get merged in below, so `local_dict` also carries blosc2
        # containers that cannot be reinterpreted as resident counts; leave
        # anything that is not a NumPy value alone.
        if dtype is None or dtype.kind not in "Mm" or not isinstance(value, np.ndarray | np.generic):
            converted[key] = value
            continue
        units.add(np.datetime_data(dtype)[0])
        if len(units) > 1 or np.isnat(value).any():
            return None
        converted[key] = np.asarray(value).view("i8")
    return converted if units else None


@lru_cache(maxsize=1024)
def _numpy_boolean_graph(expression):
    """Admit array-aware boolean evaluation without rewriting scalar control flow."""
    if not any(tok in expression for tok in ("and", "or", "not")):
        return None
    try:
        _, nodes = expression_syntax(expression)
        if any(
            isinstance(node, ast.BoolOp) or (isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not))
            for node in nodes
        ):
            return parse_expression(expression)
    except (SyntaxError, exceptions.UnsafeDeserializationError):
        # Trusted full-mode syntax outside the admitted graph keeps Python's
        # own control flow. No execution has occurred at this admission gate.
        pass
    return None


def _eval_numpy_expression(expression, globals_, operands):
    graph = _numpy_boolean_graph(expression) if globals_ is safe_numpy_globals else None
    if graph is not None and graph.names <= operands.keys():
        # Graph traversal stays lazy for scalars, including their operand-valued
        # and/or results. Only actual arrays select NumPy logical operations.
        return graph.evaluate(operands, numpy_bool_ops=True)
    # In trusted full mode an unbound name in an unvisited scalar branch need
    # not resolve at all. Safe-mode evaluation keeps its original binding checks.
    return evaluate_expression(expression, globals_, operands)


def _numpy_eval_datetime_aware(expression, _globals, local_dict):
    """``eval`` an expression with NumPy, reading bare numbers as datetime counts.

    NumPy refuses to compare a datetime64 against a plain number, but a string
    expression has no way to spell a datetime literal, so blosc2 reads the
    number as a count in the operand's own unit (see
    `_int64_datetime_operands`).  Only comparisons are meant by this; anything
    else keeps NumPy's error.
    """
    try:
        return _eval_numpy_expression(expression, _globals, local_dict)
    except TypeError:
        int_dict = _int64_datetime_operands(local_dict)
        if int_dict is None:
            raise
        res = _eval_numpy_expression(expression, _globals, int_dict)
        if getattr(res, "dtype", None) != np.bool_:
            raise
        return res


def _prepare_chunk_schedule(expression, operands, optimization, policy, state):
    """Amortize native preparation across one traversal without retaining arrays."""
    from .native_graph import lower_native_graph, native_weak_scalars_eligible

    cache_key = None
    if state is not None:
        cache_key = (
            expression,
            optimization,
            typed_evaluator_enabled(),
            tuple(policy.items()),
            tuple((name, value.dtype, value.shape) for name, value in sorted(operands.items())),
        )
        prepared = state.schedules.get(cache_key)
        if prepared is not None:
            return prepared
    stub = LazyExpr(None)
    stub.expression, stub.operands, stub._optimization = expression, operands, optimization
    try:
        # Respect explicit no-JIT and unsupported compiler/accuracy policies.
        graph_jit = (
            policy["jit"]
            if policy["jit_backend"] is None and policy["fp_accuracy"] == blosc2.FPAccuracy.DEFAULT
            else False
        )
        plan, arrays, _ = lower_native_graph(stub, jit=graph_jit, allow_output=True)
        if typed_evaluator_enabled() and not native_weak_scalars_eligible(plan, expression, operands):
            return None
    except (NotImplementedError, ValueError, TypeError):
        return None
    except blosc2.MenudetError as error:
        if error.status not in {"invalid_signature", "unsupported"}:
            raise
        return None
    # Bound map tiles without starting another pool inside a storage worker.
    # Checked recipes and reductions retain their existing traversal.
    tile_items = 65536 if plan.info().get("partitionable", False) else 1024
    schedule = plan.specialize(
        {name: (value.dtype, value.shape) for name, value in arrays.items()}, tile_items=tile_items
    )
    prepared = plan, tuple(arrays), schedule, schedule.info()
    if cache_key is not None:
        if len(state.schedules) >= 64:
            state.schedules.pop(next(iter(state.schedules)))
        state.schedules[cache_key] = prepared
    return prepared


def evaluate_chunk(expression, local_dict=None, **kwargs):
    """Evaluate an invocation-local chunk with native numerical or NumPy semantics.

    Native admission is metadata-only. Unsupported signatures decline before
    execution; runtime failures are never replayed through NumPy.
    """
    from .native_graph import _native_first_syntax

    operands = {} if local_dict is None else dict(local_dict)
    depth = kwargs.pop("_frame_depth", 0)
    optimization = kwargs.pop("_optimization", "moderate")
    graph = parse_expression(expression)
    if graph.names - operands.keys():
        frame = sys._getframe(depth + 1)
        try:
            for name in graph.names - operands.keys():
                if name in frame.f_locals:
                    operands[name] = frame.f_locals[name]
                elif name in frame.f_globals:
                    operands[name] = frame.f_globals[name]
        finally:
            del frame
    validate_operands(operands)
    output = kwargs.pop("out", None)
    validate_evaluate_options(kwargs)
    policy = blosc2.jit_config.execution_options()
    prepared = None
    state = _chunk_read_state.get()
    if (
        not _NUMPY_VALUE_PROMOTION
        and operands
        and _native_first_syntax(expression)
        and all(type(value) is np.ndarray and value.dtype.kind in "biuf" for value in operands.values())
        and not (
            state is not None
            and graph.arithmetic
            and optimization == "moderate"
            and typed_evaluator_enabled()
            and policy["jit"] is None
            and policy["jit_backend"] is None
            and policy["math_backend"] is None
            and policy["fp_accuracy"] == blosc2.FPAccuracy.DEFAULT
            and not any(
                policy[name] for name in ("compiler", "cflags", "trace", "compiler_output", "cache_dir")
            )
            and all(value.dtype.kind == "f" and value.size < 65536 for value in operands.values())
        )
        and not (output is not None and any(np.shares_memory(output, value) for value in operands.values()))
    ):
        prepared = _prepare_chunk_schedule(expression, operands, optimization, policy, state)
    if prepared is not None:
        _, names, schedule, info = prepared
        arrays = {name: operands[name] for name in names}
        direct = (
            output is not None
            and type(output) is np.ndarray
            and output.shape == info["shape"]
            and output.dtype == info["dtype"]
            and getattr(blosc2.blosc2_ext, "native_graph_output_available", lambda: False)()
        )
        result, _ = schedule.execute(arrays, out=output) if direct else schedule.execute(arrays)
    else:
        # For small floating arithmetic chunks without a JIT request, NumPy's
        # vectorized operations beat scalar interpretation. Large chunks and explicit
        # execution policies retain native admission. Integer policy is unchanged.
        # Native chunk execution collects FP status without emitting Python
        # warnings by default. Preserve that policy in the explicit fallback.
        with np.errstate(all="ignore"):
            result = _numpy_eval_datetime_aware(expression, safe_numpy_globals, operands)
    result = np.asarray(result)
    if output is not None:
        if result is not output:
            np.copyto(output, result, casting=kwargs.get("casting", "same_kind"))
        return output
    return result


# Temporary compatibility alias; a direct alias preserves caller-scope lookup.
ne_evaluate = evaluate_chunk


def _get_result(expression, chunk_operands, eval_kwargs, where=None, indices=None, _order=None):
    chunk_indices = None

    # Apply the where condition (in result) — fusion path, evaluate before shortcut
    if where is not None and len(where) == 2:
        # x = chunk_operands["_where_x"]
        # y = chunk_operands["_where_y"]
        # Preserve a fused native select when the expression is supported.
        new_expr = f"where({expression}, _where_x, _where_y)"
        return evaluate_chunk(new_expr, chunk_operands, **eval_kwargs), None

    # If the expression is a simple operand reference (e.g. "key", "o0"),
    # grab it directly from chunk_operands instead of calling evaluate_chunk.
    # This avoids unnecessary expression preparation for identity chunks.
    _expr = expression.strip("()")
    if _expr in chunk_operands:
        result = chunk_operands[_expr]
    else:
        result = evaluate_chunk(expression, chunk_operands, **eval_kwargs)
    if where is None:
        return result, None
    elif len(where) == 1:
        x = chunk_operands["_where_x"]
        if (indices is not None) or (_order is not None):
            # Return indices only makes sense when the where condition is a tuple with one element
            # and result is a boolean array
            if len(x.shape) > 1:
                raise ValueError("argsort() and sort() only support 1D arrays")
            if result.dtype != np.bool_:
                raise ValueError("argsort() and sort() only support bool conditions")
            if _order:
                # We need to cumulate all the fields in _order, as well as indices
                chunk_indices = indices[result]
                result = x[_order][result]
            else:
                chunk_indices = None
                result = indices[result]
            return result, chunk_indices
        else:
            return x[result], None
    raise ValueError("The where condition must be a tuple with one or two elements")


# Define empty ndindex tuple for function defaults
NDINDEX_EMPTY_TUPLE = ndindex.Tuple()

# All the dtypes that are supported by the expression evaluator
dtype_symbols = {
    "int8": np.int8,
    "int16": np.int16,
    "int32": np.int32,
    "int64": np.int64,
    "uint8": np.uint8,
    "uint16": np.uint16,
    "uint32": np.uint32,
    "uint64": np.uint64,
    "float32": np.float32,
    "float64": np.float64,
    "complex64": np.complex64,
    "complex128": np.complex128,
    "bool": np.bool_,
    "str": np.str_,
    "bytes": np.bytes_,
    "i1": np.int8,
    "i2": np.int16,
    "i4": np.int32,
    "i8": np.int64,
    "u1": np.uint8,
    "u2": np.uint16,
    "u4": np.uint32,
    "u8": np.uint64,
    "f4": np.float32,
    "f8": np.float64,
    "c8": np.complex64,
    "c16": np.complex128,
    "b1": np.bool_,
    "S": np.str_,
    "V": np.bytes_,
}
blosc2_funcs = constructors + linalg_funcs + elementwise_funcs + reducers
# functions that have to be evaluated before chunkwise lazyexpr machinery
eager_funcs = linalg_funcs + reducers + ["slice"] + ["." + attr for attr in linalg_attrs]
functions = blosc2_funcs
_TRANSIENT_MASK_CPARAMS = blosc2.CParams(codec=blosc2.Codec.LZ4, clevel=5, filters=[blosc2.Filter.SHUFFLE])
_constructor_call_patterns = {name: re.compile(rf"\b{re.escape(name)}\s*\(") for name in constructors}
_any_constructor_call_pattern = re.compile(
    rf"\b(?:{'|'.join(re.escape(name) for name in constructors)})\s*\("
)


def _restore_code_unit_shuffle(cparams: blosc2.CParams, dtype) -> None:
    """Give SHUFFLE the code-unit width that constructing a CParams erases.

    Left to itself, ``blosc2.uninit()`` shuffles a ``<U`` array by 4 bytes --
    the UCS4 code unit -- which for text groups the (mostly zero) high bytes of
    every codepoint together.  ``CParams`` defaults ``filters_meta`` to all
    zeros, meaning "shuffle by the whole item", so merely passing a ``CParams``
    to set something unrelated silently scatters characters across the slot
    instead.  That cost 3.2x on the compressed result of every string
    expression: 2.01 MB against 0.63 for the same bytes.

    Only touches an entry the caller left at 0, and only for ``U``.
    """
    if getattr(dtype, "kind", None) != "U":
        return
    for i, filt in enumerate(cparams.filters):
        if filt == blosc2.Filter.SHUFFLE and cparams.filters_meta[i] == 0:
            cparams.filters_meta[i] = 4


def _has_constructor_call(expression: str, constructor: str) -> bool:
    return _constructor_call_patterns[constructor].search(expression) is not None


def _has_any_constructor_call(expression: str) -> bool:
    return _any_constructor_call_pattern.search(expression) is not None


def _find_constructor_call(expression: str, constructor: str) -> re.Match | None:
    return _constructor_call_patterns[constructor].search(expression)


relational_ops = ["==", "!=", "<", "<=", ">", ">="]
# Arithmetic whose result dtype NumPy defines specially for datetime operands
_datetime_binops = {
    "+": operator.add,
    "-": operator.sub,
    "*": operator.mul,
    "/": operator.truediv,
    "//": operator.floordiv,
    "%": operator.mod,
}
logical_ops = ["&", "|", "^", "~"]
not_complex_ops = ["maximum", "minimum", "<", "<=", ">", ">="]
funcs_2args = (
    "arctan2",
    "contains",
    "pow",
    "power",
    "nextafter",
    "copysign",
    "hypot",
    "maximum",
    "minimum",
    "startswith",
    "endswith",
)


def get_expr_globals(expression):
    """Build a dictionary of functions needed for evaluating the expression."""
    if evaluation_mode() == "safe":
        parse_expression(expression)
        return {"blosc2": blosc2}
    _globals = {"np": np, "blosc2": blosc2, "nan": math.nan, "inf": math.inf}
    # Only check for functions that actually appear in the expression.
    for func in functions:
        if func in expression:
            if hasattr(blosc2, func):
                _globals[func] = getattr(blosc2, func)
            else:
                try:
                    _globals[func] = safe_numpy_globals[func]
                except KeyError as e:
                    raise AttributeError(f"Function {func} not found in blosc2 or numpy") from e

    # Lazily support bare numpy calls not covered by the Blosc2 function list.
    populate_safe_numpy_globals(expression)
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError:
        return _globals
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name):
            continue
        func = node.func.id
        if func in _globals:
            continue
        if hasattr(blosc2, func):
            _globals[func] = getattr(blosc2, func)
        elif func in safe_numpy_globals:
            _globals[func] = safe_numpy_globals[func]

    return _globals


if not hasattr(enum, "member"):
    # copy-pasted from Lib/enum.py
    class MyMember:
        """
        Forces item to become an Enum member during class creation.
        """

        def __init__(self, value):
            self.value = value
else:
    MyMember = enum.member  # only available after python 3.11


class ReduceOp(Enum):
    """
    Available reduce operations.
    """

    # wrap as enum.member so that Python doesn't treat some funcs
    # as class methods (rather than Enum members)
    SUM = MyMember(np.add)
    PROD = MyMember(np.multiply)
    MEAN = MyMember(np.mean)
    STD = MyMember(np.std)
    VAR = MyMember(np.var)
    # Computing a median from partial results is not straightforward because the median
    # is a positional statistic, which means it depends on the relative ordering of all
    # the data points. Unlike statistics such as the sum or mean, you can't compute a median
    # from partial results without knowing the entire dataset, and this is way too expensive
    # for arrays that cannot typically fit in-memory (e.g. disk-based NDArray).
    # MEDIAN = np.median
    MAX = MyMember(np.maximum)
    MIN = MyMember(np.minimum)
    ANY = MyMember(np.any)
    ALL = MyMember(np.all)
    ARGMAX = MyMember(np.argmax)
    ARGMIN = MyMember(np.argmin)
    CUMULATIVE_SUM = MyMember(npcumsum)
    CUMULATIVE_PROD = MyMember(npcumprod)


class LazyArrayEnum(Enum):
    """
    Available LazyArrays.
    """

    Expr = 0
    UDF = 1


class LazyArrayVLMeta(MutableMapping):
    """User metadata attached to a LazyArray."""

    def __init__(self, lazyarr: LazyArray):
        self.lazyarr = lazyarr

    def __getitem__(self, key):
        return self.lazyarr._get_user_vlmeta()[key]

    def __setitem__(self, key, value):
        data = self.lazyarr._get_user_vlmeta()
        data[key] = value
        self.lazyarr._sync_user_vlmeta()

    def __delitem__(self, key):
        data = self.lazyarr._get_user_vlmeta()
        del data[key]
        self.lazyarr._sync_user_vlmeta()

    def __iter__(self):
        return iter(self.lazyarr._get_user_vlmeta())

    def __len__(self):
        return len(self.lazyarr._get_user_vlmeta())

    def getall(self):
        return self.lazyarr._get_user_vlmeta().copy()

    def __repr__(self):
        return repr(self.getall())

    def __str__(self):
        return str(self.getall())


class LazyArray(ABC, blosc2.Operand):
    """Base class for lazy array expressions that compute data on demand."""

    def _get_user_vlmeta(self) -> dict[str, Any]:
        if not hasattr(self, "_vlmeta_user"):
            self._vlmeta_user = {}
        return self._vlmeta_user

    def _set_user_vlmeta(self, metadata: dict[str, Any], *, sync: bool = True) -> None:
        self._vlmeta_user = dict(metadata)
        if sync:
            self._sync_user_vlmeta()

    def _sync_user_vlmeta(self) -> None:
        array = getattr(self, "array", None)
        if array is not None:
            write_b2object_user_vlmeta(array, self._get_user_vlmeta())

    @property
    def attrs(self):
        """User attributes; the recommended alias for :attr:`vlmeta`.

        Shares the existing metadata storage and access rules without filtering keys.
        """
        return self.vlmeta

    @property
    def vlmeta(self) -> LazyArrayVLMeta:
        """User variable-length metadata for this LazyArray."""
        if not hasattr(self, "_vlmeta_proxy"):
            self._vlmeta_proxy = LazyArrayVLMeta(self)
        return self._vlmeta_proxy

    def __enter__(self) -> LazyArray:
        """Enter a context manager and return this lazy array."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Exit a context manager.

        Lazy arrays do not currently keep explicit closeable resources, so this
        is a logical no-op kept for API consistency with :func:`blosc2.open`.
        """
        return False

    @abstractmethod
    def argsort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        """
        Return an :ref:`LazyArray` containing the positions selected by self.

        The LazyArray must be of bool dtype (e.g. a condition).

        Parameters
        ----------
        order: str, list of str, optional
            Specifies which fields to compare first, second, etc. A single
            field can be specified as a string. Not all fields need to be
            specified, only the ones by which the array is to be sorted.

        Returns
        -------
        out: :ref:`LazyArray`
            The positions of the :ref:`LazyArray` self that are True.
        """
        pass

    @abstractmethod
    def sort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        """
        Return a sorted :ref:`LazyArray`.

        This is only valid for LazyArrays with structured dtypes.

        Parameters
        ----------
        order: str, list of str, optional
            Specifies which fields to compare first, second, etc. A single
            field can be specified as a string. Not all fields need to be
            specified, only the ones by which the array is to be sorted.

        Returns
        -------
        out: :ref:`LazyArray`
            A sorted :ref:`LazyArray`.
        """
        pass

    @abstractmethod
    def compute(
        self,
        item: slice | list[slice] | None = None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs: Any,
    ) -> blosc2.NDArray:
        """
        Return a :ref:`NDArray` containing the evaluation of the :ref:`LazyArray`.

        Parameters
        ----------
        item: slice, list of slices, optional
            If provided, item is used to slice the operands *prior* to computation; not to retrieve specified slices of
            the evaluated result. This difference between slicing operands and slicing the final expression
            is important when reductions or a where clause are used in the expression.

        fp_accuracy: :class:`blosc2.FPAccuracy`, optional
            Specifies the floating-point accuracy to be used during computation.
            By default, :attr:`blosc2.FPAccuracy.DEFAULT` is used.

        kwargs: Any, optional
            Keyword arguments that are supported by the :func:`empty` constructor.
            These arguments will be set in the resulting :ref:`NDArray`.
            Additionally, the following special kwargs are supported:

            - ``eval_kwargs`` (dict): for :ref:`LazyExpr`, override the expression
              evaluation options supplied to :func:`lazyexpr` for this call.
              ``ne_args`` is a compatibility alias; do not pass both names.

            - ``strict_miniexpr`` (bool): controls whether miniexpr compilation/execution
              failures are raised instead of silently falling back to regular chunked eval
              for non-DSL expressions.  Setting it ``True`` also opts a DSL kernel out of the
              WebAssembly prefer-js default, keeping it on miniexpr.

            - ``jit`` (bool | None): enable (``True``) or disable (``False``) JIT compilation
              of the expression via miniexpr. None inherits :ref:`JITOptions` defaults.
              With built-in defaults, JIT is only used
              for DSL kernels; plain expressions are evaluated by the bytecode interpreter.
              Setting ``jit=True`` requests auto-lift of plain expressions into DSL
              kernels. Native JIT is best effort: compilation/allocation/loading
              failures use the interpreter quietly. See :ref:`JITOptions`.

            - ``jit_backend`` (str | None): select the JIT compiler backend.  Valid
              values are ``"tcc"`` (bundled Tiny C Compiler), ``"cc"`` (system C
              compiler, e.g. gcc or clang), and ``"js"`` (transpile the DSL kernel to
              JavaScript; browser/Pyodide only — see below).  ``None`` (default) defers
              to the miniexpr default (``"tcc"``), except under WebAssembly where — unless
              ``jit=False`` — it *prefers* ``"js"`` for transpilable float DSL kernels and
              falls back to miniexpr otherwise.  Since ``"js"`` is itself JIT-compiled by
              the JS engine, ``jit=True`` prefers it too; force miniexpr with
              ``jit_backend="tcc"``/``"cc"``.

            - ``"js"`` backend (WebAssembly/Pyodide only): transpiles a
              compatibility DSLKernel to JavaScript so it runs at the browser engine's
              optimized native speed.  It tends to beat the WASM miniexpr JIT (~2x) for
              float kernels dominated by arithmetic and control flow, and is roughly a
              wash for transcendental-heavy or trivial kernels.  Outside WebAssembly,
              ``jit_backend="js"`` raises.  Forcing ``"tcc"``/``"cc"`` always uses miniexpr.

            - ``BLOSC_ME_JIT`` environment variable: when set to ``"1"``, ``"true"``,
              ``"on"``, ``"tcc"``, or ``"cc"``, it forces ``jit=True`` and overrides
              ``jit`` on paths calling ``LazyExpr.compute()``. Setting it to
              ``"tcc"`` or ``"cc"`` additionally overrides ``jit_backend``. It is
              not a universal constructor/LazyUDF override, and ``"0"`` does not
              disable JIT. Use ``ME_DSL_JIT=0`` to disable miniexpr runtime JIT.

            - ``BLOSC_ME_JIT_TRACE`` environment variable: when set to ``"1"``,
              ``"true"``, or ``"on"``, prints a one-line diagnostic to stdout
              showing which compute engine was selected (``miniexpr`` or
              ``evaluate_chunk``), the JIT mode and backend if applicable, and the
              expression being evaluated.

        Returns
        -------
        out: :ref:`NDArray`
            A :ref:`NDArray` containing the result of evaluating the
            :ref:`LazyUDF` or :ref:`LazyExpr`.

        Notes
        -----
        * If self is a LazyArray from an udf, the kwargs used to store the resulting
          array will be the ones passed to the constructor in :func:`lazyudf` (except the
          `urlpath`) updated with the kwargs passed when calling this method.

        Examples
        --------
        >>> import blosc2
        >>> import numpy as np
        >>> dtype = np.float64
        >>> shape = [3, 3]
        >>> size = shape[0] * shape[1]
        >>> a = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
        >>> b = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
        >>> #  Convert numpy arrays to Blosc2 arrays
        >>> a1 = blosc2.asarray(a)
        >>> b1 = blosc2.asarray(b)
        >>> # Perform the mathematical operation
        >>> expr = a1 + b1
        >>> output = expr.compute()
        >>> f"Result of a + b (lazy evaluation): {output[:]}"
        Result of a + b (lazy evaluation):
                    [[ 0.    1.25  2.5 ]
                    [ 3.75  5.    6.25]
                    [ 7.5   8.75 10.  ]]
        """
        pass

    @abstractmethod
    def __getitem__(self, item: int | slice | Sequence[slice]) -> np.ndarray:
        """
        Return a numpy.ndarray containing the evaluation of the :ref:`LazyArray`.

        Parameters
        ----------
        item: int, slice or sequence of slices
            If provided, item is used to slice the operands *prior* to computation; not to retrieve specified slices of
            the evaluated result. This difference between slicing operands and slicing the final expression
            is important when reductions or a where clause are used in the expression.

        Returns
        -------
        out: np.ndarray
            An array with the data containing the evaluated slice.

        Examples
        --------
        >>> import blosc2
        >>> import numpy as np
        >>> dtype = np.float64
        >>> shape = [30, 4]
        >>> size = shape[0] * shape[1]
        >>> a = np.linspace(0, 10, num=size, dtype=dtype).reshape(shape)
        >>> b = np.linspace(0, 10, num=size, dtype=dtype).reshape(shape)
        >>> #  Convert numpy arrays to Blosc2 arrays
        >>> a1 = blosc2.asarray(a)
        >>> b1 = blosc2.asarray(b)
        >>> # Perform the mathematical operation
        >>> expr = a1 + b1  # LazyExpr expression
        >>> expr[3]
        [2.01680672 2.18487395 2.35294118 2.5210084 ]
        >>> expr[2:4]
        [[1.34453782 1.51260504 1.68067227 1.8487395 ]
        [2.01680672 2.18487395 2.35294118 2.5210084 ]]
        """
        pass

    @abstractmethod
    def save(self, **kwargs: Any) -> None:
        """
        Save the :ref:`LazyArray` on disk.

        Parameters
        ----------
        kwargs: Any, optional
            Keyword arguments that are supported by the :func:`empty` constructor.
            The `urlpath` must always be provided.

        Returns
        -------
        out: None

        Notes
        -----
        * All the operands of the LazyArray must be Python scalars, or :class:`blosc2.Array` objects.
        * If an operand is a :ref:`Proxy`, keep in mind that Python-Blosc2 will only be able to reopen it as such
          if its source is a :ref:`SChunk`, :ref:`NDArray` or a :ref:`C2Array` (see :func:`blosc2.open` notes
          section for more info). A :ref:`RemoteArray` is persisted as its
          portable source descriptor rather than embedding its carrier cache.
        * This is currently only supported for :ref:`LazyExpr` and :ref:`LazyUDF`
          (including internally normalized source kernels).
        * User metadata can be attached via :attr:`vlmeta`. For in-memory LazyArrays
          this stays in memory; for persisted LazyArrays it is serialized and restored
          on reopen.

        Examples
        --------
        >>> import blosc2
        >>> import numpy as np
        >>> dtype = np.float64
        >>> shape = [3, 3]
        >>> size = shape[0] * shape[1]
        >>> a = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
        >>> b = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
        >>> # Define file paths for storing the arrays
        >>> a1 = blosc2.asarray(a, urlpath='a_array.b2nd', mode='w')
        >>> b1 = blosc2.asarray(b, urlpath='b_array.b2nd', mode='w')
        >>> # Perform the mathematical operation to create a LazyExpr expression
        >>> expr = a1 + b1
        >>> # Save the LazyExpr to disk
        >>> expr.save(urlpath='lazy_array.b2nd', mode='w')
        >>> # Open and load the LazyExpr from disk
        >>> disk_expr = blosc2.open('lazy_array.b2nd', mode='r')
        >>> disk_expr[:2]
        [[0.   1.25 2.5 ]
        [3.75 5.   6.25]]
        """
        pass

    # Provide a way to serialize the LazyArray
    def to_cframe(self) -> bytes:
        """
        Compute LazyArray and convert to cframe.

        Returns
        -------
        out: bytes
            The buffer containing the serialized :ref:`NDArray` instance.
        """
        return self.compute().to_cframe()

    @abstractproperty
    def chunks(self) -> tuple[int]:
        """
        Return :ref:`LazyArray` chunks.
        """
        pass

    @abstractproperty
    def blocks(self) -> tuple[int]:
        """
        Return :ref:`LazyArray` blocks.
        """
        pass

    def get_chunk(self, nchunk):
        """Get the `nchunk` of the expression, evaluating only that one."""
        # Create an empty array with the chunkshape and dtype; this is fast
        shape = self.shape
        chunks = self.chunks
        # Calculate the shape of the (chunk) slice_ (especially at the end of the array)
        chunks_idx, _ = get_chunks_idx(shape, chunks)
        coords = tuple(np.unravel_index(nchunk, chunks_idx))
        slice_ = tuple(
            slice(c * s, min((c + 1) * s, shape[i]))
            for i, (c, s) in enumerate(zip(coords, chunks, strict=True))
        )
        loc_chunks = tuple(s.stop - s.start for s in slice_)
        out = blosc2.empty(shape=self.chunks, dtype=self.dtype, chunks=self.chunks, blocks=self.blocks)
        if loc_chunks == self.chunks:
            self.compute(item=slice_, out=out)
        else:
            _slice_ = tuple(slice(0, s) for s in loc_chunks)
            out[_slice_] = self.compute(item=slice_)
        return out.schunk.get_chunk(0)


def convert_inputs(inputs):
    if not inputs or len(inputs) == 0:
        return []
    inputs_ = []
    for obj in inputs:
        # CTable Column — unwrap to the backing NDArray so shape and identity match.
        with contextlib.suppress(AttributeError):
            obj = obj._raw_col
        if not isinstance(obj, np.ndarray | blosc2.Operand) and not np.isscalar(obj):
            try:
                obj = blosc2.SimpleProxy(obj)
            except Exception:
                print(
                    "Inputs not being np.ndarray, Array or Python scalar objects"
                    " should be convertible to SimpleProxy."
                )
                raise
        inputs_.append(obj)
    return inputs_


def compute_broadcast_shape(arrays):
    """
    Returns the shape of the outcome of an operation with the input arrays.
    """
    # When dealing with UDFs, one can arrive params that are not arrays
    shapes = [arr.shape for arr in arrays if hasattr(arr, "shape") and arr is not np]
    return np.broadcast_shapes(*shapes) if shapes else None


def _jit_from_env(jit, jit_backend):
    """Apply BLOSC_ME_JIT environment variable to jit/jit_backend defaults."""
    env_jit = os.environ.get("BLOSC_ME_JIT", "")
    if not env_jit:
        return jit, jit_backend
    env_jit_lower = env_jit.lower()
    # Env var always wins over both jit= and jit_backend= for easy CLI experimentation.
    if env_jit_lower in ("1", "true", "on", "tcc", "cc"):
        jit = True
    if env_jit_lower in ("tcc", "cc"):
        jit_backend = env_jit_lower
    return jit, jit_backend


# Define the patterns for validation
validation_patterns = [
    r"[\;]",  # Flow control characters
    r"(^|[^\w])__[\w]+__($|[^\w])",  # Dunder methods
    r"\.\b(?!real|imag|T|mT|(\d*[eE]?[+-]?\d+)|(\d*[eE]?[+-]?\d+j)|\d*j\b|(sum|prod|min|max|std|mean|var|any|all|where)"
    r"\s*\([^)]*\)|[a-zA-Z_]\w*\s*\([^)]*\))",  # Attribute patterns
]

# Compile the blacklist regex
_blacklist_re = re.compile("|".join(validation_patterns))

# Define valid method names
valid_methods = {
    "sum",
    "prod",
    "min",
    "max",
    "std",
    "mean",
    "var",
    "any",
    "all",
    "where",
    "reshape",
    "slice",
}
valid_methods |= {"int8", "int16", "int32", "int64", "uint8", "uint16", "uint32", "uint64"}
valid_methods |= {"float32", "float64", "complex64", "complex128"}
valid_methods |= {"bool", "str", "bytes"}
valid_methods |= {
    name for name in dir(blosc2.NDArray) if not name.startswith("_")
}  # allow attributes and methods


def validate_expr(expr: str) -> None:
    """
    Validate expression for forbidden syntax and valid method names.

    Parameters
    ----------
    expr : str
        The expression to validate.

    Returns
    -------
    None
    """
    if evaluation_mode() == "safe":
        parse_expression(expr)
        return
    # Remove whitespace and skip quoted strings
    no_whitespace = re.sub(r"\s+", "", expr)
    skip_quotes = re.sub(r"(\'[^\']*\')", "", no_whitespace)

    # Check for forbidden patterns
    forbiddens = _blacklist_re.search(skip_quotes)
    if forbiddens is not None:
        raise ValueError(f"'{expr}' is not a valid expression.")

    # Check for invalid characters not covered by the tokenizer
    invalid_chars = re.compile(r"[^\w\s+\-*/%()[].,=<>!&|~^]")
    if invalid_chars.search(skip_quotes) is not None:
        invalid_chars = invalid_chars.findall(skip_quotes)
        raise ValueError(f"Expression {expr} contains invalid characters: {invalid_chars}")

    # Check for invalid method names
    method_calls = re.findall(r"\.\b(\w+)\s*\(", skip_quotes)
    for method in method_calls:
        if method not in valid_methods:
            raise ValueError(f"Invalid method name: {method}")


def extract_and_replace_slices(expr, operands):
    """
    Return new expression and operands with op.slice(...) replaced by temporary operands.
    """
    # Copy shapes and operands
    shapes = {k: () if not hasattr(v, "shape") else v.shape for k, v in operands.items()}
    new_ops = operands.copy()  # copy dictionary

    # Parse the expression
    tree = ast.parse(expr, mode="eval")

    # Mapping of AST nodes to new variable names
    replacements = {}

    class SliceCollector(ast.NodeTransformer):
        def visit_Call(self, node):
            # Recursively visit children first
            self.generic_visit(node)

            # Detect method calls: obj.slice(...)
            if isinstance(node.func, ast.Attribute) and node.func.attr == "slice":
                obj = node.func.value

                # If the object is already replaced, keep the replacement
                base_name = None
                if isinstance(obj, ast.Name):
                    base_name = obj.id
                elif isinstance(obj, ast.Call) and obj in replacements:
                    base_name = replacements[obj]["base_var"]

                # Build the full slice chain expression as a string
                full_expr = ast.unparse(node)

                # Create a new temporary variable
                new_var = f"o{len(new_ops)}"

                # Infer shape
                try:
                    shape = infer_shape(full_expr, shapes)
                except Exception as e:
                    print(f"Shape inference failed for {full_expr}: {e}")
                    shape = ()

                # Determine dtype
                dtype = new_ops[base_name].dtype if base_name else None

                # Create placeholder array
                if isinstance(new_ops[base_name], blosc2.NDArray):
                    new_op = blosc2.ones((1,) * len(shape), dtype=dtype)
                else:
                    new_op = np.ones((1,) * len(shape), dtype=dtype)

                new_ops[new_var] = new_op
                shapes[new_var] = shape

                # Record replacement
                replacements[node] = {"new_var": new_var, "base_var": base_name}

                # Replace the AST node with the new variable
                return ast.Name(id=new_var, ctx=ast.Load())

            return node

    # Transform the AST
    transformer = SliceCollector()
    new_tree = transformer.visit(tree)
    ast.fix_missing_locations(new_tree)

    # Convert back to expression string
    new_expr = ast.unparse(new_tree)

    return new_expr, new_ops


def get_expr_operands(expression: str) -> set:
    """
    Given an expression in string form, return its operands.

    Parameters
    ----------
    expression : str
        The expression in string form.

    Returns
    -------
    set
        A set of operands found in the expression.
    """

    class OperandVisitor(ast.NodeVisitor):
        def __init__(self):
            self.operands = set()
            self.function_names = set()

        def visit_Name(self, node):
            if node.id == "np":
                # Skip NumPy namespace (e.g. np.int8, which will be treated separately)
                return
            if node.id not in self.function_names and node.id not in dtype_symbols:
                self.operands.add(node.id)
            self.generic_visit(node)

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name):
                self.function_names.add(node.func.id)
            self.generic_visit(node)

    tree = ast.parse(expression)
    visitor = OperandVisitor()
    visitor.visit(tree)
    return set(visitor.operands)


def conserve_functions(  # noqa: C901
    expression: str,
    operands_old: dict[str, blosc2.Array],
    operands_new: dict[str, blosc2.Array],
    *,
    tree=None,
) -> tuple[str, dict[str, blosc2.Array]]:
    """
    Given an expression in string form, return its operands.

    Parameters
    ----------
    expression : str
        The expression in string form.

    operands_old: dict[str : blosc2.ndarray | blosc2.LazyExpr]
        Dict of operands from expression prior to eval.

    operands_new: dict[str : blosc2.ndarray | blosc2.LazyExpr]
        Dict of operands from expression after eval.
    Returns
    -------
    newexpression
        A modified string expression with the functions/constructors conserved and
        true operands rebased and written in o- notation.
    newoperands
        Dict of the set of rebased operands.
    """

    operand_to_key = {id(v): k for k, v in operands_new.items()}
    for k, v in operands_old.items():  # extend operands_to_key with old operands
        if isinstance(
            v, blosc2.LazyExpr
        ):  # unroll operands in LazyExpr (only necessary when have reduced a lazyexpr)
            d = v.operands
        else:
            d = {k: v}
        for newk, newv in d.items():
            try:
                operand_to_key[id(newv)]
            except KeyError:
                newk = (
                    f"o{len(operands_new)}" if newk in operands_new else newk
                )  # possible that names coincide
                operand_to_key[id(newv)] = newk
                operands_new[newk] = newv

    class OperandVisitor(ast.NodeVisitor):
        def __init__(self):
            self.operandmap = {}
            self.operands = {}
            self.opcounter = 0
            self.function_names = set()

        def update_func(self, localop):
            k = operand_to_key[id(localop)]
            if k not in self.operandmap:
                newkey = f"o{self.opcounter}"
                self.operands[newkey] = operands_new[k]
                self.operandmap[k] = newkey
                self.opcounter += 1
                return newkey
            else:
                return self.operandmap[k]

        def visit_Name(self, node):
            if node.id in {"np", "numpy", "blosc2"}:  # Registered namespaces are not operands
                return
            if node.id in self.function_names:  # Skip function names
                return
            elif node.id not in dtype_symbols:
                if node.id in ("nan", "inf") and node.id not in operands_old:
                    return  # non-finite float literal, not an operand
                localop = operands_old[node.id]
                if isinstance(localop, blosc2.LazyExpr):
                    newexpr = localop.expression
                    for (
                        opname,
                        v,
                    ) in localop.operands.items():  # expression operands already in terms of basic operands
                        # add illegal character ; to track changed operands and not overwrite later
                        newopname = ";" + self.update_func(v)
                        newexpr = re.sub(
                            rf"(?<=\s){opname}|(?<=\(){opname}", newopname, newexpr
                        )  # replace with newopname
                    # remove all instances of ; as all changes completed
                    node.id = newexpr.replace(";", "")
                else:
                    node.id = self.update_func(localop)
            self.generic_visit(node)

        def visit_Call(self, node):
            if isinstance(
                node.func, ast.Name
            ):  # visits Call first, then Name, so don't increment operandcounter yet
                self.function_names.add(node.func.id)
            self.generic_visit(node)

    if tree is None:
        tree = ast.parse(expression)
    else:
        # Renaming must not mutate syntax shared by other expressions or threads.
        def clone(node):
            if isinstance(node, ast.AST):
                return type(node)(**{name: clone(value) for name, value in ast.iter_fields(node)})
            if isinstance(node, list):
                return [clone(value) for value in node]
            return node

        tree = clone(tree)
    visitor = OperandVisitor()
    visitor.visit(tree)
    newexpression, newoperands = ast.unparse(tree), visitor.operands
    return newexpression, newoperands


def convert_to_slice(expression):
    """
    Takes expression and converts all instances of [] to .slice(....)

    Parameters
    ----------
    expression: str

    Returns
    -------
    new_expr : str
    """

    new_expr = ""
    skip_to_char = 0
    for i, expr_i in enumerate(expression):
        if i < skip_to_char:
            continue
        if expr_i == "[":
            k = expression[i:].find("]")  # start checking from after [
            slice_convert = expression[i : i + k + 1]  # include [ and ]
            try:
                slicer = parse_expression(f"a{slice_convert}").root[2]
                # Build the slice tuple directly without indexing an actual array.
                from .expression_graph import evaluate_index

                slicer = evaluate_index(slicer)
                slicer = (slicer,) if not isinstance(slicer, tuple) else slicer  # standardise to tuple
                if any(isinstance(el, str) for el in slicer):  # handle fields
                    raise ValueError("Cannot handle fields for slicing lazy expressions.")
                slicer = str(slicer)
                # use slice so that lazyexpr uses blosc arrays internally
                # (and doesn't decompress according to getitem syntax)
                new_expr += f".slice({slicer})"
                skip_to_char = i + k + 1
                continue
            except Exception:
                pass
        new_expr += expr_i  # if slice_convert is e.g. a list, not a slice, do nothing
    return new_expr


class TransformNumpyCalls(ast.NodeTransformer):
    def __init__(self):
        self.replacements = {}
        self.tmp_counter = 0

    def visit_Call(self, node):
        # Check if the call is a numpy type-casting call
        if (
            isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id in ["np", "numpy"]
            and isinstance(node.args[0], ast.Constant)
        ):
            # Create a new temporary variable name
            tmp_var = f"tmp{self.tmp_counter}"
            self.tmp_counter += 1

            # Evaluate the type-casting call to create the new variable's value
            numpy_type = getattr(np, node.func.attr)
            self.replacements[tmp_var] = numpy_type(node.args[0].value)

            # Replace the call node with a variable node
            return ast.copy_location(ast.Name(id=tmp_var, ctx=ast.Load()), node)
        return self.generic_visit(node)


def extract_numpy_scalars(expr: str):
    # Parse the expression into an AST
    tree = ast.parse(expr, mode="eval")

    # Transform the AST
    transformer = TransformNumpyCalls()
    transformed_tree = transformer.visit(tree)

    # Generate the modified expression
    transformed_expr = ast.unparse(transformed_tree)

    return transformed_expr, transformer.replacements


def _isscalar(arr):
    return np.isscalar(arr) or (hasattr(arr, "shape") and arr.shape == ())


def validate_inputs(inputs: dict, out=None, reduce=False) -> tuple:  # noqa: C901
    """Validate the inputs for the expression."""
    if not inputs:
        if out is None:
            raise ValueError(
                "You really want to pass at least one input or one output for building a LazyArray."
                " Maybe you want blosc2.empty() instead?"
            )
        if isinstance(out, blosc2.NDArray):
            return out.shape, out.chunks, out.blocks, True
        else:
            return out.shape, None, None, True

    raw_inputs = [input_ for input_ in inputs.values() if (input_ is not np and not _isscalar(input_))]
    if not raw_inputs:
        # Scalar-only expressions have scalar output shape but can use miniexpr
        return (), None, None, True

    # This will raise an exception if the input shapes are not compatible
    shape = compute_broadcast_shape(raw_inputs)

    if not all(np.array_equal(shape, input.shape) for input in raw_inputs):
        # If inputs have different shapes (other than scalars), we cannot take the fast path
        return shape, None, None, False

    # More checks specific to NDArray inputs
    # NDInputs are either non-SimpleProxy with chunks or are SimpleProxy with src having chunks
    NDinputs = [
        input
        for input in raw_inputs
        if (hasattr(input, "chunks") and not isinstance(input, blosc2.SimpleProxy))
        or (isinstance(input, blosc2.SimpleProxy) and hasattr(input.src, "chunks"))
    ]
    if not NDinputs:
        # All inputs are NumPy arrays, so we cannot take the fast path
        if raw_inputs and hasattr(raw_inputs[0], "shape"):
            shape = raw_inputs[0].shape
        else:
            shape = None
        return shape, None, None, False

    # Check if we can take the fast path
    # For this we need that the chunks and blocks for all inputs (and a possible output)
    # are the same
    fast_path = True
    first_input = NDinputs[0]
    # Check the out NDArray (if present) first
    if isinstance(out, blosc2.NDArray) and not reduce:
        if first_input.shape != out.shape:
            return None, None, None, False
        if first_input.chunks != out.chunks:
            fast_path = False
        if first_input.blocks != out.blocks:
            fast_path = False
        if 0 in out.chunks:  # fast_eval has zero division error for 0 shapes
            fast_path = False
    # Then, the rest of the operands
    for input_ in NDinputs:
        if first_input.chunks != input_.chunks:
            fast_path = False
        if first_input.blocks != input_.blocks:
            fast_path = False
        if 0 in input_.chunks:  # fast_eval has zero division error for 0 shapes
            fast_path = False

    return first_input.shape, first_input.chunks, first_input.blocks, fast_path


def is_full_slice(item):
    """Check whether the slice represented by item is a full slice."""
    if item == ():
        # This is the case when the user does not pass any slice in compute() method
        return True
    if isinstance(item, tuple):
        return all((isinstance(i, slice) and i == slice(None, None, None)) or i == Ellipsis for i in item)
    elif isinstance(item, int | bool):
        return False
    else:
        return item in (slice(None, None, None), Ellipsis)


def do_slices_intersect(slice1: list | tuple, slice2: list | tuple) -> bool:
    """
    Check whether two slices intersect.

    Parameters
    ----------
    slice1: list of slices
        The first slice
    slice2: list of slices
        The second slice

    Returns
    -------
    bool
        Whether the slices intersect
    """

    # Pad the shorter slice list with full slices (:)
    while len(slice1) < len(slice2):
        slice1.append(slice(None))
    while len(slice2) < len(slice1):
        slice2.append(slice(None))

    # Check each dimension for intersection
    for s1, s2 in zip(slice1, slice2, strict=True):
        if s1 is Ellipsis or s2 is Ellipsis:
            return True
        if s1.start >= s2.stop:
            return False
        if s1.stop <= s2.start:
            return False

    return True


def get_chunk(arr, info, nchunk):
    reduc, low_mem, chunks_idx = info

    if low_mem:
        # We don't want to uncompress the chunk, so keep it compressed and
        # decompress it just before execution.  This is normally slower, but
        # can be useful in scarce memory situations.
        return arr.schunk.get_chunk(nchunk)

    # First check if the chunk is a special zero chunk.
    # Using lazychunks is very effective here because we only need to read the header.
    if reduc:
        # Reductions can treat zero scalars as zero chunks
        chunk = arr.schunk.get_lazychunk(nchunk)
        special = blosc2.SpecialValue((chunk[31] & 0x70) >> 4)
        if special == blosc2.SpecialValue.ZERO:
            return np.zeros((), dtype=arr.dtype)

    shape, chunks = arr.shape, arr.chunks
    coords = tuple(np.unravel_index(nchunk, chunks_idx))
    slice_ = tuple(
        # slice(c * s, min((c + 1) * s, shape))  # uncomment to make code hang here
        slice(c * s, min((c + 1) * s, shape[i]))
        for i, (c, s) in enumerate(zip(coords, chunks, strict=True))
    )
    return arr[slice_]


def _stoppable_put(queue, item, stop):
    """Put *item* into the bounded *queue*, giving up when *stop* gets set.

    Returns False when aborted, so the producer can exit instead of blocking
    forever on a queue whose consumer is gone.
    """
    while not stop.is_set():
        try:
            queue.put(item, timeout=0.1)
            return True
        except Full:
            continue
    return False


def read_chunks_worker(arrs, info, queue, stop):
    """Read the chunks of all operands concurrently and feed them into *queue*.

    For each chunk index, the reads are submitted to a thread pool (one task per
    operand) so that file reads and decompression overlap; the bounded queue in
    :func:`sync_read_chunks` provides the prefetch ahead of the consumer.
    """
    shape, chunks_ = arrs[0].shape, arrs[0].chunks
    max_workers = max(1, min(len(arrs), int(getattr(blosc2, "nthreads", 1) or 1)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        my_chunk_iter = range(arrs[0].schunk.nchunks)
        if len(info) == 4:
            if info[-1] is not None:
                my_chunk_iter = sliced_chunk_iter(chunks_, (), shape, axis=info[-1], nchunk=True)
            info = info[:3]
        for i, nchunk in enumerate(my_chunk_iter):
            futures = [executor.submit(get_chunk, arr, info, nchunk) for arr in arrs]
            # result() keeps operand order and propagates the first exception raised
            if not _stoppable_put(queue, (i, [future.result() for future in futures]), stop):
                return

    _stoppable_put(queue, None, stop)  # signal the end of the chunks


def sync_read_chunks(arrs, info):
    queue_size = 2  # maximum number of chunks in the queue
    queue = Queue(maxsize=queue_size)
    # Signals the producer to bail out when the consumer goes away (e.g. an
    # exception during evaluation closes this generator early); without it,
    # the producer can block forever on a full queue and deadlock the
    # thread.join() below during generator finalization.
    stop = threading.Event()
    worker_exc = None

    def _run_reader():
        nonlocal worker_exc
        try:
            read_chunks_worker(arrs, info, queue, stop)
        except BaseException as exc:
            worker_exc = exc
            _stoppable_put(queue, None, stop)

    # Start the file reading in a separate thread
    thread = threading.Thread(target=_run_reader)
    thread.start()

    try:
        # Read the chunks synchronously from the queue
        while True:
            try:
                chunks = queue.get(timeout=1)  # Wait for the next chunk
                if chunks is None:  # End of chunks
                    if worker_exc is not None:
                        raise worker_exc
                    break
                yield chunks
            except Empty:
                if not thread.is_alive():
                    if worker_exc is not None:
                        raise worker_exc from None
                    break
                continue
    finally:
        stop.set()
        thread.join()


def read_nchunk(arrs, info):
    with contextlib.closing(sync_read_chunks(arrs, info)) as reader:
        for _, chunks in reader:
            yield chunks


@dataclass
class _ChunkReadState:
    """Own one traversal's reader and metadata-only schedules, with deterministic cleanup."""

    iterator: Any = None
    schedules: dict = field(default_factory=dict)

    def close(self):
        self.schedules.clear()
        iterator, self.iterator = self.iterator, None
        if iterator is not None:
            iterator.close()


_chunk_read_state = contextvars.ContextVar("chunk_read_state", default=None)


def _chunk_buffers(operands, shape, chunks):
    """Reusable chunk-sized buffers for the NDArray operands of `shape` and `chunks` whose
    decompressed chunks are C-order.

    That is the case when blocks are C-contiguous runs of their chunk (as with the default
    partitions), so a plain decompress_chunk() gives the (padded) chunk, and is cheaper than a
    slice read.
    """
    return {
        key: np.empty(value.chunks, dtype=value.dtype)
        for key, value in operands.items()
        if isinstance(value, blosc2.NDArray)
        and value.ndim > 0
        and value.shape == shape
        and value.chunks == chunks
        and 0 not in value.blocks
        and blocks_contiguous(value.chunks, value.blocks)
    }


def fill_chunk_operands(
    operands,
    slice_,
    chunks_,
    full_chunk,
    nchunk,
    iter_disk,
    chunk_operands,
    reduc=False,
    axis=None,
    chunk_buffers=None,
):
    """Retrieve the chunk operands for evaluating an expression.

    This function provides an optimized path for full chunks and a slower path for partial chunks.
    Operands with a buffer in `chunk_buffers` (see `_chunk_buffers`) get their chunk decompressed
    into it, whether the chunk is full or not.
    """
    if iter_disk:
        # Use an environment variable to control the memory usage
        low_mem = os.environ.get("BLOSC_LOW_MEM", False)
        # This method is only useful when all operands are NDArray and shows better
        # performance only when at least one of them is persisted on disk
        state = _chunk_read_state.get()
        if state is None:
            raise RuntimeError("Persisted chunk reads require an invocation-local reader")
        iter_chunks = state.iterator
        if iter_chunks is None:
            # Initialize the iterator for reading the chunks
            # Take any operand (all should have the same shape and chunks)
            arr = next(iter(operands.values()))
            chunks_idx, _ = get_chunks_idx(arr.shape, arr.chunks)
            info = (reduc, low_mem, chunks_idx, axis)
            iter_chunks = read_nchunk(list(operands.values()), info)
            state.iterator = iter_chunks
        # Run the asynchronous file reading function from a synchronous context
        chunks = next(iter_chunks)

        for i, (key, value) in enumerate(operands.items()):
            # The reader already returns valid-shaped edge chunks (or scalar
            # zeros for reductions). Do not decompress edge chunks a second time.
            chunk_operands[key] = chunks[i] if not low_mem else value[slice_]
        return

    # Get the starts and stops for the slice
    starts = [s.start if s.start is not None else 0 for s in slice_]
    stops = [s.stop if s.stop is not None else sh for s, sh in zip(slice_, chunks_, strict=True)]

    for key, value in operands.items():
        if np.isscalar(value):
            chunk_operands[key] = value
            continue
        if value.shape == ():
            chunk_operands[key] = value[()]
            continue
        buf = chunk_buffers.get(key) if chunk_buffers else None
        if buf is not None:
            value.schunk.decompress_chunk(nchunk, buf)
            chunk_operands[key] = buf if full_chunk else buf[tuple(slice(0, n) for n in chunks_)]
            continue
        if not isinstance(value, blosc2.NDArray):
            chunk_operands[key] = value[slice_]
            continue

        # Read valid-shaped edge chunks directly too. General __getitem__ adds
        # key/metadata processing that this scheduler has already performed.
        if key not in chunk_operands or chunks_ != chunk_operands[key].shape:
            chunk_operands[key] = np.empty(chunks_, dtype=value.dtype)
        value.get_slice_numpy(chunk_operands[key], (starts, stops))


def _apply_jit_backend_pragma(expression: str, inputs: dict, jit_backend: str | None) -> str:
    # Author-written pragmas are authoritative. Python's synthesized pragma is
    # only a local default and must not override the native environment policy.
    if "# me:compiler=" in expression:
        return expression
    if jit_backend is None:
        return expression
    if jit_backend == "js":
        # "js" is handled earlier (DSL kernels -> JS bridge); it never carries a C pragma.
        return expression
    if jit_backend not in ("tcc", "cc"):
        raise ValueError("jit_backend must be one of: None, 'tcc', 'cc', 'js'")

    env_backend = os.environ.get("ME_DSL_JIT_COMPILER", "").strip().lower()
    if env_backend in ("tcc", "cc"):
        jit_backend = env_backend

    pragma = f"# me:compiler={jit_backend}\n"
    stripped = "\n".join(
        line for line in expression.splitlines() if not line.lstrip().startswith("#")
    ).lstrip()
    if stripped.startswith("def "):
        return pragma + expression
    params = ", ".join(k for k, v in inputs.items() if hasattr(v, "dtype"))
    return f"{pragma}def __me_auto({params}):\n    return {expression}"


def _inject_dummy_param_for_zero_input_dsl(expression: str, param_name: str) -> str:
    pattern = re.compile(r"^(\s*def\s+[A-Za-z_]\w*)\(\s*\)(\s*:)", re.MULTILINE)
    rewritten, nsubs = pattern.subn(rf"\1({param_name})\2", expression, count=1)
    if nsubs == 0:
        raise ValueError("Could not inject dummy DSL parameter for zero-input kernel")
    return rewritten


def _is_dsl_kernel_expression(expression) -> bool:
    return isinstance(expression, DSLKernel) and expression.dsl_source is not None


def _as_js_udf(expression, shape=None):
    """For jit_backend="js": transpile a DSL kernel to JS and return a plain per-block
    callable (so the normal UDF path runs it). Browser/Pyodide only.

    *shape* (the whole-array output shape) is forwarded to the transpiler so kernels using
    index/shape symbols can reconstruct global coordinates per block."""
    if not _is_dsl_kernel_expression(expression):
        raise ValueError('jit_backend="js" requires a compatibility DSLKernel')
    if not blosc2.IS_WASM:
        raise RuntimeError('jit_backend="js" is only available under WebAssembly/Pyodide')
    from .dsl_js import js_kernel

    return js_kernel(expression, shape=shape)


def _js_dtypes_ok(operands, kwargs) -> bool:
    """True only if the JS bridge (which computes in float64) is safe for these operands.

    The output dtype must be floating: integer/complex *output* goes to miniexpr (the bridge
    can't reproduce integer division/overflow/truncation semantics, and float64 can't hold
    int64 exactly). Smaller integer inputs are exactly representable in float64,
    but 64-bit integer inputs must stay on miniexpr: comparisons can retain their
    integer precision even with a float output. Complex inputs are rejected
    (the bridge is real-only)."""
    dt = kwargs.get("dtype")
    if dt is None:
        # Inferred output: only safe when all operands are float (so the output is float too).
        return all(np.issubdtype(op.dtype, np.floating) for op in operands.values() if hasattr(op, "dtype"))
    if not np.issubdtype(np.dtype(dt), np.floating):
        return False
    return all(
        np.issubdtype(op.dtype, np.floating)
        or (np.issubdtype(op.dtype, np.integer) and op.dtype.itemsize < 8)
        for op in operands.values()
        if hasattr(op, "dtype")
    )


def _trace_js_backend(expression):
    """BLOSC_ME_JIT_TRACE counterpart for the JS bridge, which never reaches
    miniexpr's trace point in `fast_eval` (see there for the message format)."""
    if blosc2.jit_config.trace_enabled() or os.environ.get("BLOSC_ME_JIT_TRACE", "").lower() in (
        "1",
        "true",
        "on",
    ):
        source = getattr(expression, "dsl_source", None) or expression
        expr_short = str(source)[:120].replace("\n", " ")
        stream = sys.stderr if blosc2.jit_config.trace_enabled() else sys.stdout
        print(f"[blosc2] engine=js expr={expr_short}", file=stream, flush=True)


def _maybe_js_backend(expression, jit, jit_backend, reduce_args, operands, kwargs, shape=None):
    """Resolve the JS backend for a DSL kernel.

    - ``jit_backend="js"`` (explicit): transpile to the JS bridge, or raise if it can't.
    - ``jit_backend=None`` under WebAssembly, unless ``jit=False``: *prefer* JS (it is a
      JIT too, and the fastest one here) for transpilable float DSL kernels, silently
      falling back to miniexpr for anything it can't do (non-float dtypes, reductions, or
      unsupported DSL constructs).  ``jit=True`` and ``jit=None`` both prefer JS; only
      ``jit=False`` (interpreter), ``strict_miniexpr=True``, or an explicit ``jit_backend``
      opts out.

    *shape* is the whole-array output shape, forwarded to the transpiler for kernels that
    use index/shape symbols (``_i0``/``_n0``/``_flat_idx``); without it such kernels fall
    back to miniexpr.

    Returns ``(expression, jit, jit_backend)`` — expression becomes a plain per-block
    callable when JS is chosen, else everything passes through unchanged.
    """
    if jit_backend == "js":
        if reduce_args:
            raise ValueError('jit_backend="js" does not support reductions')
        out_dtype = kwargs.get("dtype")
        if out_dtype is not None and not np.issubdtype(np.dtype(out_dtype), np.floating):
            # The JS bridge computes in float64 and cannot reproduce integer/complex output
            # semantics (division/overflow/truncation); keep those on miniexpr.
            raise ValueError(
                'jit_backend="js" requires a floating-point output dtype '
                f"(got {np.dtype(out_dtype)}); drop jit_backend to use miniexpr"
            )
        bridge = _as_js_udf(expression, shape)
        _trace_js_backend(expression)
        return bridge, None, None
    prefer_js = (
        jit is not False  # jit=True/None prefer the best JIT (js); only jit=False forces interpreter
        and jit_backend is None
        and not kwargs.get("strict_miniexpr")  # explicit strict_miniexpr=True keeps miniexpr
        and blosc2.IS_WASM
        and _is_dsl_kernel_expression(expression)
        and operands  # at least one operand: the zero-input DSL path stays on miniexpr
        and not reduce_args
        and _js_dtypes_ok(operands, kwargs)
    )
    if not prefer_js:
        return expression, jit, jit_backend
    try:
        bridge = _as_js_udf(expression, shape)  # transpiles; raises on any unsupported construct
    except Exception:
        return expression, jit, jit_backend  # fall back to miniexpr, no regression
    _trace_js_backend(expression)
    return bridge, None, None


def _format_dsl_parse_error_hint(expr_text: str, backend_msg: str):
    marker = "parse_error_pos="
    pos0 = backend_msg.find(marker)
    if pos0 < 0:
        return None
    pos0 += len(marker)
    pos1 = pos0
    while pos1 < len(backend_msg) and backend_msg[pos1].isdigit():
        pos1 += 1
    if pos1 == pos0:
        return None
    err_pos = int(backend_msg[pos0:pos1])
    if err_pos < 0:
        return None
    if err_pos > len(expr_text):
        err_pos = len(expr_text)
    line_no = expr_text.count("\n", 0, err_pos) + 1
    line_start = expr_text.rfind("\n", 0, err_pos) + 1
    col_no = err_pos - line_start + 1
    dump = DSLValidator(expr_text)._format_source_with_pointer(line_no, col_no)
    return f"Parse error location (line {line_no}, col {col_no}, offset {err_pos}):\n{dump}"


def _dsl_miniexpr_required_message(reason: str | None = None) -> str:
    message = ""
    if reason:
        message = f"{message}{reason}"
    return message


def _raise_dsl_miniexpr_required(reason: str | None = None) -> None:
    raise RuntimeError(_dsl_miniexpr_required_message(reason))


def _miniexpr_integer_atan2(expression, operands):
    # ponytail: use the chunked fallback until miniexpr promotes integer atan2 inputs.
    return (
        isinstance(expression, str)
        and re.search(r"\b(?:arctan2|atan2)\s*\(", expression)
        and any(getattr(op, "dtype", np.dtype(float)).kind in "biu" for op in operands.values())
    )


def _literal_value(node):
    """The number a literal AST node stands for (signs included), or None."""
    sign = 1
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub | ast.UAdd):
        sign = -1 if isinstance(node.op, ast.USub) else 1
        node = node.operand
    if isinstance(node, ast.Constant) and isinstance(node.value, bool | int | float):
        return sign * node.value
    return None


def _scalar_operand_value(value):
    """The number a scalar operand stands for, or None for arrays (and anything else)."""
    if hasattr(value, "shape"):
        if value.shape != ():
            return None
        value = value[()]
    if isinstance(value, np.generic):
        value = value.item()
    return value if isinstance(value, bool | int | float) else None


def _is_typed_numeric_scalar(value):
    """A NumPy scalar or scalar array whose strong dtype must survive expression fusion."""
    if not isinstance(value, np.generic) and getattr(value, "shape", None) != ():
        return False
    dtype = getattr(value, "dtype", None)
    return dtype is not None and convert_dtype(dtype).kind in "biufc"


def _exact_in_dtype(value, dtype) -> bool:
    """Whether `dtype`, and the C double miniexpr keeps literals in, hold the number exactly."""
    if dtype.kind not in "biuf" or float(value) != value:
        return False
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return dtype.type(value).item() == value
    except (OverflowError, ValueError):
        return False


@lru_cache(maxsize=1024)
def _parse_expression(expression: str) -> ast.Expression | None:
    """The AST of an expression (None if it is not Python syntax); the callers do not modify it."""
    try:
        return ast.parse(expression, mode="eval")
    except SyntaxError:
        return None


@lru_cache(maxsize=1024)
def _miniexpr_inexact_int_literal(expression: str) -> bool:
    """Whether the expression holds an integer literal beyond 2**53.

    miniexpr parses numeric literals into C doubles, which round such integers.
    """
    tree = _parse_expression(expression)
    return tree is not None and any(
        isinstance(node, ast.Constant)
        and isinstance(node.value, int)
        and not isinstance(node.value, bool)
        and float(node.value) != node.value
        for node in ast.walk(tree)
    )


def _miniexpr_where_matches_numpy(cond: str, operands: dict, dtype) -> bool:  # noqa: C901
    """Whether miniexpr computes where(cond, x, y) as NumPy does, once the where() is fused in.

    miniexpr types the literals of the fused expression by its output dtype, and computes in it,
    while NumPy evaluates the condition in the dtypes of its operands, with Python scalars as weak
    scalars (NEP 50).  With a float32 `a`, NumPy compares ``a > 0.1`` against float32(0.1), but
    miniexpr compares ``where(a > 0.1, 1, 0)`` against the double 0.1, and adds ``a + b`` in
    ``where(a + b == c, 1, 0)`` in a wider type.  The two agree when computing in the output dtype
    changes nothing: when every operand of the condition has the output dtype, or when the
    condition only compares operands that cast safely to it, against literals that their dtypes
    hold exactly.  Inside where(), miniexpr also passes 64-bit integers through doubles, so
    where() on them stays with NumPy.
    """
    if dtype is None:
        return False
    out_dtype = np.dtype(dtype)
    dtypes = [out_dtype] + [
        np.dtype(op.dtype)
        for op in operands.values()
        if hasattr(op, "dtype") and _scalar_operand_value(op) is None
    ]
    if any(dt.kind in "iu" and dt.itemsize > 4 for dt in dtypes):
        return False
    tree = _parse_expression(cond)
    if tree is None:
        return False

    def term(node):
        """("literal", number) or ("array", dtype) for a leaf of the condition, else None."""
        value = _literal_value(node)
        if value is not None:
            return "literal", value
        if isinstance(node, ast.Name) and node.id in operands:
            op = operands[node.id]
            value = _scalar_operand_value(op)
            if value is not None:
                return "literal", value
            if hasattr(op, "dtype"):
                return "array", np.dtype(op.dtype)
        return None

    comparisons = []

    def only_compares(node):
        """Whether `node` combines comparisons of leaves with & | ~ only (collected into comparisons)."""
        if isinstance(node, ast.Compare):
            terms = [term(n) for n in (node.left, *node.comparators)]
            if len(node.ops) > 1 or None in terms:
                return False
            comparisons.append(terms)
            return True
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitAnd | ast.BitOr | ast.BitXor):
            return only_compares(node.left) and only_compares(node.right)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Invert | ast.Not):
            return only_compares(node.operand)
        if isinstance(node, ast.BoolOp):
            return all(only_compares(value) for value in node.values)
        leaf = term(node)
        if leaf is not None and leaf[0] == "array" and leaf[1].kind == "b":
            comparisons.append([leaf])
            return True
        return False

    if only_compares(tree.body):
        for terms in comparisons:
            dtypes = [dt for kind, dt in terms if kind == "array"]
            if not all(np.can_cast(dt, out_dtype, "safe") for dt in dtypes):
                return False
            literals = [value for kind, value in terms if kind == "literal"]
            if not all(_exact_in_dtype(value, dt) for value in literals for dt in (*dtypes, out_dtype)):
                return False
        return True

    # With arithmetic, the condition is computed as in NumPy only in its own dtype
    def same_dtype(node):
        leaf = term(node)
        if leaf is not None:
            kind, value = leaf
            return value == out_dtype if kind == "array" else _exact_in_dtype(value, out_dtype)
        if isinstance(node, ast.Name):  # a function name
            return True
        if isinstance(node, ast.Constant):  # strings and other non-numbers
            return False
        return all(same_dtype(child) for child in ast.iter_child_nodes(node))

    return same_dtype(tree.body)


@blosc2.jit_config.jit_execution
def fast_eval(  # noqa: C901
    expression: str | Callable[[tuple, np.ndarray, tuple[int]], None],
    operands: dict,
    getitem: bool,
    **kwargs,
) -> blosc2.NDArray | np.ndarray:
    """Evaluate the expression in chunks of operands using a fast path.

    Parameters
    ----------
    expression: str or callable
        The expression or udf to evaluate.
    operands: dict
        A dictionary containing the operands for the expression.
    getitem: bool, optional
        Indicates whether the expression is being evaluated for a getitem operation or compute().
        Default is False.
    kwargs: Any, optional
        Additional keyword arguments supported by the :func:`empty` constructor.

    Returns
    -------
    :ref:`NDArray` or np.ndarray
        The output array.
    """
    global try_miniexpr

    # Use a local copy so we don't modify the global
    use_miniexpr = try_miniexpr

    is_dsl = _is_dsl_kernel_expression(expression)
    expr_string = expression.dsl_source if is_dsl else expression
    dsl_disable_reason = None
    # NumPy 1 has no string ufuncs, so non-numeric expressions keep their
    # existing (miniexpr-backed) route there. The pre-2 policy is numerical.
    string_operands = _NUMPY_VALUE_PROMOTION and any(
        isinstance(value, blosc2.NDArray | np.ndarray) and value.dtype.kind in "SU"
        for value in operands.values()
    )
    typed_expression = (
        not is_dsl
        and isinstance(expression, str)
        and not string_operands
        and (typed_evaluator_enabled() or _NUMPY_VALUE_PROMOTION)
    )
    if typed_expression:
        # This route may use typed artifacts or explicit NumPy fallback, never
        # the uniform-output-dtype expression compiler.
        use_miniexpr = False

    # Disable miniexpr for UDFs (callable expressions), except DSL kernels
    if callable(expression) and not is_dsl:
        use_miniexpr = False

    out = kwargs.pop("_output", None)
    owned_output = False
    eval_kwargs: dict = kwargs.pop("_eval_kwargs", {})
    if eval_kwargs is None:
        eval_kwargs = {}
    fp_accuracy = kwargs.pop("fp_accuracy", blosc2.FPAccuracy.DEFAULT)
    jit = kwargs.pop("jit", None)
    jit_backend = kwargs.pop("jit_backend", None)
    optimization = kwargs.pop("_optimization", "moderate")
    strict_miniexpr = kwargs.pop("strict_miniexpr", None)
    _in_place = kwargs.pop("in_place", None)
    dtype = kwargs.pop("dtype", None)
    requested_shape = kwargs.pop("shape", None)
    where: dict | None = kwargs.pop("_where_args", None)
    # Optional candidate-block bitmap (1-D miniexpr only): uint8, one byte per
    # global block (0 = skip → false output, non-zero = evaluate).  Used by the
    # CTable SUMMARY-index path to skip non-candidate blocks inside miniexpr.
    candidate_blocks = kwargs.pop("_candidate_blocks", None)
    # Opt-in: skip update_data for chunks that contain no candidate block.  The
    # result array is left uninitialized in those chunks, so the caller MUST read
    # only candidate chunks (scoped extraction).  Used by the CTable SUMMARY path.
    prune_chunks = kwargs.pop("_prune_chunks", False)
    if strict_miniexpr is None:
        # Be strict by default for DSL kernels to avoid silently losing DSL fast-path regressions.
        strict_miniexpr = bool(is_dsl)
    if where is not None and len(where) != 2:
        # miniexpr does not support cardinality-changing where (len==1);
        # where(cond, x, y) with two args is element-wise and IS supported.
        use_miniexpr = False
        if is_dsl:
            dsl_disable_reason = "DSL kernels cannot be run without miniexpr."
    if isinstance(out, blosc2.NDArray):
        # If 'out' has been passed, and is a NDArray, use it as the base array
        basearr = out
    elif isinstance(out, np.ndarray) and not any(hasattr(o, "chunks") for o in operands.values()):
        # If 'out' is a NumPy array, create a NDArray with the same shape and dtype
        basearr = blosc2.empty(out.shape, dtype=out.dtype, **kwargs)
    else:
        # Otherwise, find the operand with the 'chunks' attribute and the longest shape
        operands_with_chunks = [o for o in operands.values() if hasattr(o, "chunks")]
        if operands_with_chunks and any(arr.chunks != () for arr in operands_with_chunks):
            basearr = max(operands_with_chunks, key=lambda x: len(x.shape))
        else:
            if requested_shape is None:
                raise ValueError("Cannot infer output shape without operands; pass `shape` explicitly")
            if dtype is None:
                raise ValueError("Cannot infer output dtype without operands; pass `dtype` explicitly")
            basearr = blosc2.empty(
                requested_shape,
                dtype=dtype,
                chunks=kwargs.get("chunks"),
                blocks=kwargs.get("blocks"),
            )

    # Get the shape of the base array
    shape = basearr.shape
    chunks = kwargs.pop("chunks", None)
    if chunks is None:
        chunks = basearr.chunks
    blocks = kwargs.pop("blocks", None)
    if blocks is None:
        blocks = basearr.blocks
    # Check whether the partitions are behaved
    behaved = blosc2.are_partitions_behaved(shape, chunks, blocks)

    if (
        typed_expression
        and try_miniexpr
        and not eval_kwargs
        and not _in_place
        and fp_accuracy == blosc2.FPAccuracy.DEFAULT
        and (where is None or len(where) == 2)
    ):
        typed_source = f"where({expression}, _where_x, _where_y)" if where is not None else expression
        result = compute_typed_prefilter(
            typed_source,
            operands,
            dtype=dtype,
            getitem=getitem,
            out=out,
            jit=jit,
            jit_backend=jit_backend,
            options={**kwargs, "chunks": chunks, "blocks": blocks},
            candidate_blocks=candidate_blocks,
            prune_chunks=prune_chunks,
            optimization=optimization,
        )
        if result is not None:
            return result

    # Check that all operands are NDArray for fast path
    all_ndarray = all(isinstance(value, blosc2.NDArray) and value.shape != () for value in operands.values())
    # Check that there is some NDArray that is persisted in the disk
    any_persisted = any(
        (isinstance(value, blosc2.NDArray) and value.shape != () and value.schunk.urlpath is not None)
        for value in operands.values()
    )
    if not blosc2.IS_WASM:
        iter_disk = all_ndarray and any_persisted
    else:
        # WebAssembly does not support threading, so we cannot use the iter_disk option
        iter_disk = False

    expr_string_miniexpr = expr_string
    operands_miniexpr = operands
    if not is_dsl and any(_is_typed_numeric_scalar(value) for value in operands.values()):
        # Scalar specialization erases strong dtypes. Keep them as operands for
        # the typed graph/NumPy evaluator, rather than compiling weak literals.
        use_miniexpr = False
    # Fuse where(cond, x, y) before specializing, so that scalar x/y get inlined as well;
    # fusing afterwards would reference a dropped operand and make miniexpr fail to compile.
    where_fused = (
        use_miniexpr
        and isinstance(expr_string, str)
        and not is_dsl
        and where is not None
        and len(where) == 2
    )
    if where_fused and not _miniexpr_where_matches_numpy(expr_string, operands, dtype):
        use_miniexpr = where_fused = False
    if where_fused:
        expr_string_miniexpr = f"where({expr_string}, _where_x, _where_y)"
    if use_miniexpr and isinstance(expr_string, str):
        # If specialization fails, keep original expression/operands and let normal checks decide.
        with contextlib.suppress(Exception):
            expr_string_miniexpr, operands_miniexpr = specialize_miniexpr_inputs(
                expr_string_miniexpr, operands
            )
        if not is_dsl and _miniexpr_inexact_int_literal(expr_string_miniexpr):
            # Typed literals and inlined scalars alike
            use_miniexpr = False

    # Check whether we can use miniexpr
    if use_miniexpr:
        if is_dsl and isinstance(expression, DSLKernel) and not operands_miniexpr:
            # Scalar specialization may remove all kernel inputs at runtime (e.g. `f(start)` with start=3),
            # so inject a dummy array operand for miniexpr even if the original DSL signature had parameters.
            dummy_name = "__me_dummy0"
            dummy_dtype = dtype if dtype is not None else np.uint8
            expr_string_miniexpr = _inject_dummy_param_for_zero_input_dsl(expr_string_miniexpr, dummy_name)
            operands_miniexpr = {
                dummy_name: blosc2.zeros(shape, dtype=dummy_dtype, chunks=chunks, blocks=blocks)
            }
        if math.prod(shape) <= 1:
            # Avoid miniexpr for scalar-like outputs; current prefilter path is unstable here.
            use_miniexpr = False
            if is_dsl and dsl_disable_reason is None:
                dsl_disable_reason = "scalar-like outputs are not supported by the DSL miniexpr path."
        if (
            isinstance(expr_string_miniexpr, str)
            and
            # Prefix scans are stateful across chunks and not safe for miniexpr prefilter execution.
            any(tok in expr_string_miniexpr for tok in ("cumsum(", "cumprod(", "cumulative_sum("))
        ):
            use_miniexpr = False
            if is_dsl and dsl_disable_reason is None:
                dsl_disable_reason = "cumulative scans are not supported by the DSL miniexpr path."
        if isinstance(expr_string_miniexpr, str):
            if not is_dsl and _miniexpr_integer_atan2(expr_string_miniexpr, operands):
                use_miniexpr = False
            expr_string_miniexpr = _apply_jit_backend_pragma(
                expr_string_miniexpr, operands_miniexpr, jit_backend
            )

        def _miniexpr_eligible_operand(op):
            if isinstance(op, blosc2.NDArray):
                return op.shape != () and op.shape == shape and op.chunks == chunks and op.blocks == blocks
            if isinstance(op, np.ndarray):
                # Raw NumPy operands are only miniexpr-eligible for DSL kernels (the
                # jit control-flow dispatch route). Plain string expressions and traced
                # `jit` calls keep the established NDArray-only gate, preserving
                # existing numerical and dtype behavior.
                return (
                    is_dsl
                    and op.ndim > 0
                    and op.shape == shape
                    and op.dtype.isnative
                    and op.dtype.kind in "biufcUS"
                )
            return False

        all_eligible_miniexpr = all(_miniexpr_eligible_operand(op) for op in operands_miniexpr.values())
        if not all_eligible_miniexpr:
            use_miniexpr = False
            if is_dsl and dsl_disable_reason is None:
                dsl_disable_reason = (
                    "all DSL operands must be NDArray or NumPy inputs sharing shape/chunks/blocks."
                )
        numpy_output = (
            (getitem or isinstance(out, np.ndarray))
            # Each chunk's payload must be a consecutive run of the C-order result
            and _chunks_tile_flat(shape, chunks, blocks)
            and not prune_chunks
            and (out is None or not is_dsl)
            # Rebinding an existing LazyExpr can leave unused operand names.
            # Retain its established fallback rather than compiling extra inputs.
            and (is_dsl or set(operands_miniexpr) == set(get_expr_operands(expr_string)))
            and (
                out is None
                # A 1-D out may be strided; an N-D one is written through its flat view
                or (out.dtype == dtype and out.flags.writeable and (out.ndim == 1 or out.flags.c_contiguous))
            )
        )
        if not (all_eligible_miniexpr and (out is None or numpy_output)):
            use_miniexpr = False
            if is_dsl and dsl_disable_reason is None:
                dsl_disable_reason = (
                    "DSL kernels require NDArray or NumPy inputs and do not support the `out` argument."
                )
        has_complex = any(
            isinstance(op, blosc2.NDArray) and blosc2.isdtype(op.dtype, "complex floating")
            for op in operands_miniexpr.values()
        )
        if (
            isinstance(expr_string_miniexpr, str)
            and has_complex
            and any(tok in expr_string_miniexpr for tok in ("!=", "==", "<=", ">=", "<", ">"))
        ):
            use_miniexpr = False
            if is_dsl and dsl_disable_reason is None:
                dsl_disable_reason = "complex comparisons are not supported by miniexpr."

    if is_dsl and not use_miniexpr:
        _raise_dsl_miniexpr_required(dsl_disable_reason)

    if blosc2.jit_config.trace_enabled() or os.environ.get("BLOSC_ME_JIT_TRACE", "").lower() in (
        "1",
        "true",
        "on",
    ):
        engine = (
            "miniexpr"
            if use_miniexpr
            else ("evaluate_chunk" if isinstance(expr_string, str) else "python-udf")
        )
        jit_info = f"jit={jit}, backend={jit_backend}" if use_miniexpr else ""
        expr_short = str(expr_string)[:120].replace("\n", " ")
        stream = sys.stderr if blosc2.jit_config.trace_enabled() else sys.stdout
        print(f"[blosc2] engine={engine} {jit_info} expr={expr_short}", file=stream, flush=True)

    if use_miniexpr:
        cparams = kwargs.pop("cparams", None)
        if numpy_output:
            # NumPy output needs only an uncompressed, reusable chunk payload.
            cparams = blosc2.CParams(clevel=0)
        elif cparams is None and getitem:
            cparams = blosc2.CParams(clevel=0)
        # Otherwise leave cparams unset rather than passing CParams(): its
        # filters_meta defaults to all zeros, which *overrides* the dtype-aware
        # shuffle width uninit() would pick.  For <U that width is 4 (the UCS4
        # code unit); shuffling by the full slot instead scatters characters
        # across it and cost 3.2x on the compressed result.
        if cparams is not None:
            kwargs["cparams"] = cparams
        # All values will be overwritten, so we can use an uninitialized array
        res_eval = blosc2.uninit(shape, dtype, chunks=chunks, blocks=blocks, **kwargs)
        prefilter_set = False
        try:
            # Fuse where(cond, x, y) into the expression for miniexpr
            _pref_expr = expr_string_miniexpr
            _pref_ops = operands_miniexpr
            if any(isinstance(v, np.ndarray) for v in _pref_ops.values()):
                _pref_ops = {
                    k: (np.ascontiguousarray(v) if isinstance(v, np.ndarray) else v)
                    for k, v in _pref_ops.items()
                }
            if where is not None and len(where) == 2 and not where_fused:
                _pref_expr = f"where({_pref_expr}, _where_x, _where_y)"
            # _cb_anchor keeps the contiguous bitmap alive for the whole
            # update_data loop (the prefilter dereferences it per block).  Pass
            # candidate_blocks only when present so external wrappers of
            # _set_pref_expr with the legacy signature keep working.
            _pref_kwargs = {"fp_accuracy": fp_accuracy, "jit": jit}
            if candidate_blocks is not None:
                _pref_kwargs["candidate_blocks"] = candidate_blocks
            _cb_anchor = res_eval._set_pref_expr(_pref_expr, _pref_ops, **_pref_kwargs)
            prefilter_set = True
            # print("expr->miniexpr:", expression, fp_accuracy)
            # Data to compress is fetched from operands, so it can be uninitialized here
            data = np.empty(res_eval.schunk.chunksize, dtype=np.uint8)
            if numpy_output:
                chunk_nitems = math.prod(chunks)
                out_flat = None if out is None else (out if out.ndim == 1 else out.reshape(-1))
                output_storage = None
                if out is None:
                    # Reserve a header prefix and at most one chunk of tail
                    # padding. C-Blosc2 can then write each uncompressed payload
                    # directly into the final NumPy allocation, in parallel.
                    output_storage = np.empty(
                        res_eval.schunk.nchunks * data.size + blosc2.EXTENDED_HEADER_LENGTH, dtype=np.uint8
                    )
                    out = np.ndarray(
                        shape, dtype=dtype, buffer=output_storage, offset=blosc2.EXTENDED_HEADER_LENGTH
                    )
                else:
                    # Caller-owned output has no reserved header prefix. Keep
                    # the existing buffer and reuse bounded chunk scratch.
                    chunk_data = np.empty(data.size + blosc2.MAX_OVERHEAD, dtype=np.uint8)
            # Exercise prefilter for each chunk.  With a candidate bitmap the
            # prefilter zeroes non-candidate blocks without decompressing inputs
            # or running miniexpr, which is where the savings come from.  With
            # _prune_chunks, whole chunks that contain no candidate block are
            # skipped entirely (left uninitialized — caller reads only candidates).
            chunk_has_candidate = None
            if prune_chunks and _cb_anchor is not None and len(chunks) == 1 and len(blocks) == 1:
                bpc = -(-int(chunks[0]) // int(blocks[0]))  # blocks per chunk (ceil)
                nct = res_eval.schunk.nchunks
                if bpc > 0 and _cb_anchor.shape[0] >= nct * bpc:
                    chunk_has_candidate = _cb_anchor[: nct * bpc].reshape(nct, bpc).any(axis=1)
            # The prefilter reads the operands' super-chunks from C, outside their methods
            operand_locks = blosc2.blosc2_ext.HandleLocks(_pref_ops.values())
            for nchunk in range(res_eval.schunk.nchunks):
                if chunk_has_candidate is not None and not chunk_has_candidate[nchunk]:
                    continue
                if numpy_output:
                    # Chunks are consecutive runs of the C-order result (see _chunks_tile_flat)
                    start = nchunk * chunk_nitems
                    count = min(chunk_nitems, out.size - start)
                    if output_storage is not None:
                        byte_start = nchunk * data.size
                        chunk_data = output_storage[
                            byte_start : byte_start + data.size + blosc2.EXTENDED_HEADER_LENGTH
                        ]
                        # Beyond the first chunk the header overlaps the end of
                        # the preceding result. Preserve it while this synchronous
                        # call runs, then restore before advancing to the next chunk.
                        header = chunk_data[: blosc2.EXTENDED_HEADER_LENGTH].copy()
                        try:
                            with operand_locks:
                                res_eval.schunk._prefilter_data(nchunk, data, chunk_data)
                        finally:
                            chunk_data[: blosc2.EXTENDED_HEADER_LENGTH] = header
                    else:
                        with operand_locks:
                            res_eval.schunk._prefilter_data(nchunk, data, chunk_data)
                        values = np.frombuffer(
                            chunk_data, dtype=dtype, count=count, offset=blosc2.EXTENDED_HEADER_LENGTH
                        )
                        out_flat[start : start + count] = values
                else:
                    with operand_locks:
                        res_eval.schunk.update_data(nchunk, data, copy=False)
            # _cb_anchor (if any) stays referenced until fast_eval returns, which
            # is after the finally below removes the prefilter — so the buffer
            # safely outlives every prefilter dereference.
        except Exception as e:
            if blosc2.jit_config.execution_options()["math_backend"] is not None:
                raise
            if is_dsl:
                reason = (
                    f"miniexpr compilation or execution failed for this DSL kernel:\n{expression.dsl_source}"
                )
                backend_error = str(e)
                parse_hint = None
                if isinstance(expr_string_miniexpr, str):
                    parse_hint = _format_dsl_parse_error_hint(expr_string_miniexpr, backend_error)
                reason = f"{reason}\nBackend error: {backend_error}"
                if parse_hint is not None:
                    reason = f"{reason}\n{parse_hint}"
                raise RuntimeError(_dsl_miniexpr_required_message(reason)) from e
            if strict_miniexpr:
                raise RuntimeError("miniexpr evaluation failed while strict_miniexpr=True") from e
            # Only preparation may decline to NumPy. Once installed, the native
            # prefilter may have written caller output or compressed chunks;
            # replaying an execution failure would hide errors/partial writes.
            if prefilter_set:
                raise
            use_miniexpr = False
        finally:
            if prefilter_set:
                res_eval.schunk.remove_prefilter("miniexpr")

        if not use_miniexpr:
            # If miniexpr failed, fallback to regular evaluation
            # (continue to the manual chunked evaluation below)
            pass
        else:
            if numpy_output:
                return out
            if getitem:
                return res_eval[()]
            return res_eval

    chunk_operands = {}
    chunk_buffers = None if iter_disk else _chunk_buffers(operands, shape, chunks)
    bitmap = None
    if typed_expression and candidate_blocks is not None:
        bitmap = np.asarray(candidate_blocks, dtype=np.uint8)
        if len(shape) != 1 or bitmap.ndim != 1:
            raise ValueError("Candidate-block bitmaps require a one-dimensional expression and bitmap")
        blocks_per_chunk = -(-chunks[0] // blocks[0])
        if bitmap.size < basearr.schunk.nchunks * blocks_per_chunk:
            raise ValueError("Candidate-block bitmap is shorter than the chunk/block grid")
        if out is None:
            out = (
                np.empty(shape, dtype=dtype)
                if getitem
                else blosc2.empty(shape, chunks=chunks, blocks=blocks, dtype=dtype, **kwargs)
            )
    # Check which chunks intersect with _slice
    all_chunks = get_intersecting_chunks((), shape, chunks)  # if _slice is (), returns all chunks
    for nchunk, chunk_slice in enumerate(all_chunks):
        cslice = chunk_slice.raw
        offset = tuple(s.start for s in cslice)  # offset for the udf
        chunks_ = tuple(s.stop - s.start for s in cslice)

        candidates = None
        if bitmap is not None:
            candidates = bitmap[nchunk * blocks_per_chunk : (nchunk + 1) * blocks_per_chunk]
            if not np.any(candidates):
                if not prune_chunks:
                    out[cslice] = 0
                continue

        full_chunk = chunks_ == chunks  # slice is same as chunk
        fill_chunk_operands(
            operands,
            cslice,
            chunks_,
            full_chunk,
            nchunk,
            iter_disk,
            chunk_operands,
            # Partial chunks keep their contiguous slice reads, which UDFs may rely on
            chunk_buffers=chunk_buffers if full_chunk else None,
        )

        # Since evaluate_chunk() can return a dtype larger than the one computed in the expression,
        # we cannot take this fast path
        # if isinstance(out, np.ndarray) and not where:
        #     # Fast path: put the result straight in the output array (avoiding a memory copy)
        #     if callable(expression):
        #         expression(tuple(chunk_operands.values()), out[slice_], offset=offset)
        #     else:
        #         evaluate_chunk(expression, chunk_operands, out=out[slice_])
        #     continue
        if out is None:
            # We can enter here when using any of the compute() or __getitem__() methods
            if getitem:
                out = np.empty(shape, dtype=dtype)
            else:
                out = blosc2.empty(shape, chunks=chunks, blocks=blocks, dtype=dtype, **kwargs)
                owned_output = type(out) is blosc2.NDArray and out.urlpath is None

        if callable(expression):
            if _is_dsl_kernel_expression(expression):
                _raise_dsl_miniexpr_required(
                    "DSL kernels require the miniexpr fast path, and it was unavailable for this "
                    "evaluation. Common causes: operands with mismatched chunks/blocks or "
                    "non-contiguous/non-native-byte-order NumPy arrays, an explicit `out=` argument, "
                    "or a `where(cond, x, y)` with cardinality-changing semantics (len(where) == 1) — "
                    "all unsupported for DSL kernels."
                )
            if _in_place:
                expression(tuple(chunk_operands.values()), out, offset=offset)
                continue
            result = np.empty(chunks_, dtype=out.dtype)
            expression(tuple(chunk_operands.values()), result, offset=offset)
        else:
            if where is None:
                result = evaluate_chunk(
                    expression, chunk_operands, _optimization=optimization, **eval_kwargs
                )
            else:
                # Apply the where condition (in result)
                if len(where) == 2:
                    new_expr = f"where({expression}, _where_x, _where_y)"
                    result = evaluate_chunk(
                        new_expr, chunk_operands, _optimization=optimization, **eval_kwargs
                    )
                else:
                    # We do not support one or zero operands in the fast path yet
                    raise ValueError("Fast path: the where condition must be a tuple with two elements")

        # Store the result in the output array
        if candidates is not None and not np.all(candidates):
            result = np.array(np.broadcast_to(result, chunks_), copy=True)
            for block, candidate in enumerate(candidates):
                if not candidate:
                    result[block * blocks[0] : (block + 1) * blocks[0]] = 0
        if getitem or isinstance(out, np.ndarray):
            try:
                out[cslice] = result
            except ComplexWarning:
                # The result is complex while the destination is real; preserve
                # the established explicit destination-conversion behavior.
                result = result.real.astype(out.dtype)
                out[cslice] = result
        else:
            if behaved and result.shape == chunks_ and result.dtype == out.dtype:
                # Fast path only works for results that are full chunks
                out.schunk.update_data(nchunk, result, copy=False)
            elif (
                owned_output
                and type(result) is np.ndarray
                and result.shape == chunks_
                and result.dtype == out.dtype
                and result.flags.c_contiguous
            ):
                # Fresh private outputs have no user indexes/aliases to refresh
                # or invalidate. Avoid general assignment's proxy construction
                # and repeated storage-policy inference for every chunk.
                out.set_slice((offset, tuple(s.stop for s in cslice)), result)
            else:
                out[cslice] = result

    return out


def compute_start_index(shape, slice_obj):
    """
    Compute the index of the starting element of a slice in an n-dimensional array.

    Parameters
    ----------
    shape : tuple
        The shape of the n-dimensional array.
    slice_obj : tuple of slices
        The slice object representing the slice of the array.

    Returns
    -------
    start_index : int
        The index of the starting element of the slice.
    """
    if not isinstance(slice_obj, tuple):
        slice_obj = (slice_obj,)

    start_index = 0
    stride = 1

    for dim, sl in reversed(list(enumerate(slice_obj))):
        if isinstance(sl, slice):
            start = sl.start if sl.start is not None else 0
        elif sl is Ellipsis:
            start = 0
        else:
            start = sl

        start_index += start * stride
        stride *= shape[dim]

    return start_index


def slices_eval(  # noqa: C901
    expression: str | Callable[[tuple, np.ndarray, tuple[int]], None],
    operands: dict,
    getitem: bool,
    _slice=NDINDEX_EMPTY_TUPLE,
    shape=None,
    **kwargs,
) -> blosc2.NDArray | np.ndarray:
    """Evaluate the expression in chunks of operands.

    This function can handle operands with different chunk shapes and
    can evaluate only a slice of the output array if needed.

    This is also flexible enough to work with operands of different shapes.

    Parameters
    ----------
    expression: str or callable
        The expression or user-defined (udf) to evaluate.
    operands: dict
        A dictionary containing the operands for the expression.
    getitem: bool, optional
        Indicates whether the expression is being evaluated for a getitem operation or compute().
        Default is False.
    _slice: ndindex.Tuple sequence of slices and ints. Default = ndindex.Tuple(), optional
        If provided, only the chunks that intersect with this slice
        will be evaluated.
    shape: tuple | None
        The shape of the full (unsliced result). Typically passed on from parent LazyArray.
        If None, a guess is made from broadcasting the operands.
    kwargs: Any, optional
        Additional keyword arguments that are supported by the :func:`empty` constructor.

    Returns
    -------
    :ref:`NDArray` or np.ndarray
        The output array.
    """
    out: blosc2.NDArray | None = kwargs.pop("_output", None)
    eval_kwargs: dict = kwargs.pop("_eval_kwargs", {})
    if eval_kwargs is None:
        eval_kwargs = {}
    chunks = kwargs.get("chunks")
    where: dict | None = kwargs.pop("_where_args", None)
    use_index = kwargs.pop("_use_index", True)
    _indices = kwargs.pop("_indices", False)
    if _indices and (not where or len(where) != 1):
        raise NotImplementedError("Indices can only be used with one where condition")
    _order = kwargs.pop("_order", None)
    if _order is not None and not isinstance(_order, list):
        # Always use a list for _order
        _order = [_order]

    dtype = kwargs.pop("dtype", None)
    _in_place = kwargs.pop("in_place", False)
    shape_slice = None
    need_final_slice = False

    # keep orig_slice
    _slice = _slice.raw
    orig_slice = _slice

    # Compute the shape and chunks of the output array, including broadcasting
    if shape is None:  # lazyudf provides shape kwarg
        shape = compute_broadcast_shape(operands.values())

    if _slice != ():
        # Check whether _slice contains an integer, or any step that are not None or 1
        if any((isinstance(s, int)) for s in _slice):
            need_final_slice = True
        _slice = tuple(slice(i, i + 1, 1) if isinstance(i, int) else i for i in _slice)
        # shape_slice in general not equal to final shape:
        # dummy dims (due to ints) will be dealt with by taking final_slice
        shape_slice = ndindex.ndindex(_slice).newshape(shape)
        mask_slice = np.array([isinstance(i, int) for i in orig_slice], dtype=np.bool_)
    if out is not None:
        shape_ = shape_slice if shape_slice is not None else shape
        if shape_ != out.shape and not _in_place:
            raise ValueError("Provided output shape does not match the slice shape.")

    if chunks is None:  # Guess chunk shape
        # Either out, or operand with `chunks`, can be used to get the chunks
        operands_ = [o for o in operands.values() if hasattr(o, "chunks") and o.shape == shape]
        if out is not None and hasattr(out, "chunks"):
            chunks = out.chunks
        elif len(operands_) > 0:
            # Use the first operand with chunks to get the necessary chunking information
            chunks = operands_[0].chunks
        else:
            # Typically, we enter here when using UDFs, and out is a NumPy array.
            # Use operands to get the shape and chunks
            # operand will be a 'fake' NDArray just to get the necessary chunking information
            fp_accuracy = kwargs.pop("fp_accuracy", None)
            temp = blosc2.empty(shape, dtype=dtype)
            if fp_accuracy is not None:
                kwargs["fp_accuracy"] = fp_accuracy
            chunks = temp.chunks
            del temp

    # The starting point for the indices of the inputs
    leninputs = compute_start_index(shape, orig_slice) if orig_slice != () else 0
    lenout = 0
    behaved = False
    indices_ = None
    chunk_indices = None
    dtype_ = np.int64 if _indices else dtype
    if _order is not None:
        # Get the dtype of the array to sort
        dtype_ = operands["_where_x"].dtype
        # Now, use only the fields that are necessary for the sorting
        if dtype_.fields is not None and all(f in dtype_.fields for f in _order):
            dtype_ = np.dtype([(f, dtype_[f]) for f in _order])
        else:
            dtype_ = np.dtype(np.int64)

    # Iterate over the operands and get the chunks
    chunk_operands = {}
    # Check which chunks intersect with _slice (handles zero chunks internally)
    intersecting_chunks = get_intersecting_chunks(
        _slice, shape, chunks
    )  # if _slice is (), returns all chunks
    ratio = (
        np.ceil(np.asarray(shape) / np.asarray(chunks)).astype(np.int64)
        if 0 not in chunks
        else np.asarray(shape)
    )
    index_plan = None
    if where is not None and len(where) == 1 and use_index and _slice == ():
        from . import indexing

        _cache_array = where["_where_x"]
        _cache_tokens = [indexing.SELF_TARGET_NAME]

        # --- Ordered path ---
        if _order is not None:
            ordered_plan = indexing.plan_ordered_query(expression, operands, where, _order)
            if ordered_plan.usable:
                cached_coords = indexing.get_cached_coords(_cache_array, expression, _cache_tokens, _order)
                if cached_coords is not None:
                    return cached_coords
                ordered_positions = indexing.ordered_query_indices(expression, operands, where, _order)
                if ordered_positions is not None:
                    indexing.store_cached_coords(
                        _cache_array, expression, _cache_tokens, _order, ordered_positions
                    )
                    return ordered_positions
            elif indexing.is_expression_order(where["_where_x"], _order):
                raise ValueError("expression order requires a matching full expression index")

        # --- Argsort-only path (.argsort().compute()) ---
        if _indices and _order is None:
            cached_coords = indexing.get_cached_coords(_cache_array, expression, _cache_tokens, None)
            if cached_coords is not None:
                return cached_coords

        # --- Value-returning path (arr[cond][:]) — cache check before plan_query ---
        _cache_urlpath = getattr(_cache_array, "urlpath", None) or getattr(
            getattr(_cache_array, "ndarr", None), "urlpath", None
        )
        if not _indices and _order is None:
            cached_coords = indexing.get_cached_coords(_cache_array, expression, _cache_tokens, None)
            if cached_coords is not None:
                cached_plan = indexing.IndexPlan(
                    usable=True, reason="cache-hit", base=_cache_array, exact_positions=cached_coords
                )
                return indexing.evaluate_full_query(where, cached_plan)

        index_plan = indexing.plan_query(expression, operands, where, use_index=use_index)

        if _indices and _order is None and index_plan.usable:
            if index_plan.exact_positions is not None:
                coords = np.asarray(index_plan.exact_positions, dtype=np.int64)
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return coords
            if index_plan.bucket_masks is not None:
                _, coords = indexing.evaluate_bucket_query(
                    expression, operands, eval_kwargs, where, index_plan, return_positions=True
                )
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return coords
            if index_plan.candidate_units is not None and index_plan.segment_len is not None:
                _, coords = indexing.evaluate_segment_query(
                    expression, operands, eval_kwargs, where, index_plan, return_positions=True
                )
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return coords
        if index_plan.usable and not (_indices or _order):
            if index_plan.exact_positions is not None:
                coords = np.asarray(index_plan.exact_positions, dtype=np.int64)
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return indexing.evaluate_full_query(where, index_plan)
            if index_plan.bucket_masks is not None:
                result, coords = indexing.evaluate_bucket_query(
                    expression, operands, eval_kwargs, where, index_plan, return_positions=True
                )
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return result
            if index_plan.candidate_units is not None and index_plan.segment_len is not None:
                result, coords = indexing.evaluate_segment_query(
                    expression, operands, eval_kwargs, where, index_plan, return_positions=True
                )
                indexing.store_cached_coords(_cache_array, expression, _cache_tokens, None, coords)
                return result

    for chunk_slice in intersecting_chunks:
        # Check whether current cslice intersects with _slice
        cslice = chunk_slice.raw
        nchunk = (
            builtins.sum(c.start // chunks[i] * np.prod(ratio[i + 1 :]) for i, c in enumerate(cslice))
            if 0 not in chunks
            else 0
        )
        if cslice != () and _slice != ():
            # get intersection of chunk and target
            cslice = step_handler(cslice, _slice)
        offset = tuple(s.start for s in cslice)  # offset for the udf
        cslice_shape = tuple(s.stop - s.start for s in cslice)
        len_chunk = math.prod(cslice_shape)
        if (
            index_plan is not None
            and index_plan.usable
            and index_plan.level == "chunk"
            and not index_plan.candidate_units[nchunk]
        ):
            if _indices or _order:
                leninputs += len_chunk
            continue
        # get local index of part of out that is to be updated
        cslice_subidx = (
            ndindex.ndindex(cslice).as_subindex(_slice).raw
        )  # in the case _slice=(), just gives cslice

        get_chunk_operands(operands, cslice, chunk_operands, shape)

        if out is None:
            shape_ = shape_slice if shape_slice is not None else shape
            if where is not None and len(where) < 2:
                # The result is a linear array
                shape_ = math.prod(shape_)
            if getitem or _order:
                out = np.empty(shape_, dtype=dtype_)
                if _order:
                    indices_ = np.empty(shape_, dtype=np.int64)
            else:
                # if "chunks" not in kwargs and (where is None or len(where) == 2):
                # Let's use the same chunks as the first operand (it could have been automatic too)
                # out = blosc2.empty(shape_, chunks=chunks, dtype=dtype_, **kwargs)
                # out = blosc2.empty(shape_, dtype=dtype_, **kwargs)
                if "chunks" in kwargs and (where is not None and len(where) < 2 and len(shape_) > 1):
                    # Remove the chunks argument if the where condition is not a tuple with two elements
                    kwargs.pop("chunks")
                fp_accuracy = kwargs.pop("fp_accuracy", None)
                out = blosc2.empty(shape_, dtype=dtype_, **kwargs)
                if fp_accuracy is not None:
                    kwargs["fp_accuracy"] = fp_accuracy
                # Check if the in out partitions are well-behaved (i.e. no padding)
                behaved = blosc2.are_partitions_behaved(out.shape, out.chunks, out.blocks)
        # Evaluate the expression using chunks of operands

        if callable(expression):
            if _is_dsl_kernel_expression(expression):
                _raise_dsl_miniexpr_required(
                    "DSL kernels only support evaluating the full array (compute() or [()]) through "
                    "the miniexpr fast path; slicing a DSL computation (e.g. `lexpr[1:5]`) is not "
                    "supported."
                )
            if _in_place:  # presumably the user knows what they're doing
                # edit out in-place
                expression(tuple(chunk_operands.values()), out, offset=offset)
            else:
                result = np.empty(cslice_shape, dtype=out.dtype)  # raises error if out is None
                # cslice should be equal to cslice_subidx
                # Call the udf directly and use result as the output array
                expression(tuple(chunk_operands.values()), result, offset=offset)
                out[cslice_subidx] = result
            continue

        if _indices or _order:
            indices = np.arange(leninputs, leninputs + len_chunk, dtype=np.int64).reshape(cslice_shape)
            leninputs += len_chunk
            result, chunk_indices = _get_result(
                expression, chunk_operands, eval_kwargs, where, indices, _order
            )
        else:
            result, _ = _get_result(expression, chunk_operands, eval_kwargs, where)
        # Enforce contiguity of result (necessary to fill the out array)
        # but avoid copy if already contiguous
        result = np.require(result, requirements="C")

        if where is None or len(where) == 2:
            if behaved and result.shape == out.chunks and result.dtype == out.dtype:
                # Fast path: only use it when the output chunk index is valid
                # (operand and output may have different chunk layouts when slicing)
                if nchunk < out.schunk.nchunks:
                    out.schunk.update_data(nchunk, result, copy=False)
                else:
                    out[cslice_subidx] = result
            else:
                try:
                    out[cslice_subidx] = result
                except ComplexWarning:
                    # The result is a complex number, so we need to convert it to real.
                    # This is a workaround for rigidness of numpy with type casting.
                    result = result.real.astype(out.dtype)
                    out[cslice_subidx] = result
        elif len(where) == 1:
            lenres = len(result)
            out[lenout : lenout + lenres] = result
            if _order is not None:
                indices_[lenout : lenout + lenres] = chunk_indices
            lenout += lenres
        else:
            raise ValueError("The where condition must be a tuple with one or two elements")

    if where is not None and len(where) < 2:  # Don't need to take final_slice since filled up from 0 index
        if _order is not None:
            # argsort the result following _order
            new_order = np.argsort(out[:lenout])
            # And get the corresponding indices in array
            out = indices_[new_order]
        # Cap the output array to the actual length
        if isinstance(out, np.ndarray):
            out = out[:lenout]
        else:
            out.resize((lenout,))

    else:  # Need to take final_slice since filled up array according to slice_ for each chunk
        if need_final_slice:  # only called if out was None
            if isinstance(out, np.ndarray):
                squeeze_axis = np.where(mask_slice)[0]
                squeeze_axis = np.squeeze(squeeze_axis)  # handle 1d mask_slice
                out = np.squeeze(out, squeeze_axis)
            elif isinstance(out, blosc2.NDArray):
                # It *seems* better to choose an automatic chunks and blocks for the output array
                # out = out.slice(_slice, chunks=out.chunks, blocks=out.blocks)
                out = out.squeeze(np.where(mask_slice)[0])
            else:
                raise ValueError("The output array is not a NumPy array or a NDArray")

    return out


def slices_eval_getitem(
    expression: str,
    operands: dict,
    _slice=NDINDEX_EMPTY_TUPLE,
    **kwargs,
) -> np.ndarray:
    """Evaluate the expression in slices of operands.

    This function can handle operands with different chunk shapes and
    can evaluate only a slice of the output array if needed.

    This is a special (and much simplified) version of slices_eval() that
    only works for the case we are returning a NumPy array, where is
    either None or has two args, and expression is not callable.

    One inconvenient of this function is that it tries to evaluate
    the whole slice in one go.  For small slices, this is good, as it
    is normally way more efficient.  However, for larger slices this
    can require large amounts of memory per operand.

    Parameters
    ----------
    expression: str or callable
        The expression or user-defined (udf) to evaluate.
    operands: dict
        A dictionary containing the operands for the expression.
    _slice: ndindex.Tuple sequence of slices and ints. Default = ndindex.Tuple(), optional
        If provided, this slice will be evaluated.
    kwargs: Any, optional
        Additional keyword arguments that are supported by the :func:`empty` constructor.

    Returns
    -------
    :ref:`NDArray` or np.ndarray
        The output array.
    """
    out: np.ndarray | None = kwargs.pop("_output", None)
    eval_kwargs: dict = kwargs.pop("_eval_kwargs", {})
    _in_place = kwargs.pop("in_place", False)
    if eval_kwargs is None:
        eval_kwargs = {}
    where: dict | None = kwargs.pop("_where_args", None)

    dtype = kwargs.pop("dtype", None)
    shape = kwargs.pop("shape", None)
    if shape is None:
        if out is None:
            # Compute the shape and chunks of the output array, including broadcasting
            shape = compute_broadcast_shape(operands.values())
        else:
            shape = out.shape

    # compute the shape of the output array
    _slice = _slice.raw
    _slice_bcast = tuple(slice(i, i + 1) if isinstance(i, int) else i for i in _slice)
    slice_shape = ndindex.ndindex(_slice_bcast).newshape(shape)  # includes dummy dimensions

    # A UDF writes into an output of slice_shape, which keeps the integer-indexed
    # axes as length 1; slicing its operands with the raw index would drop those
    # axes and leave the kernel unable to write its result (e.g. `udf[:, 0]` on a
    # 2-dim array: operand (10,) into output (10, 1)). Plain expressions keep
    # the raw index; their result no longer carries an explicit UDF destination.
    op_slice = _slice_bcast if callable(expression) else _slice

    # Get the slice of each operand
    slice_operands = {}
    for key, value in operands.items():
        if np.isscalar(value):
            slice_operands[key] = value
            continue
        if value.shape == ():
            slice_operands[key] = value[()]
            continue
        if check_smaller_shape(value.shape, shape, slice_shape, _slice_bcast):
            # We need to fetch the part of the value that broadcasts with the operand
            smaller_slice = compute_smaller_slice(shape, value.shape, op_slice)
            slice_operands[key] = value[smaller_slice]
            continue

        slice_operands[key] = value[op_slice]

    # Evaluate the expression using slices of operands
    if callable(expression):
        if _is_dsl_kernel_expression(expression):
            _raise_dsl_miniexpr_required(
                "DSL kernels only support evaluating the full array (compute() or [()]) through "
                "the miniexpr fast path; sliced getitem (e.g. `lexpr[1:5]`) is not supported."
            )
        offset = tuple(0 if s is None else s.start for s in _slice_bcast)  # offset for the udf
        if _in_place:
            expression(tuple(slice_operands.values()), out, offset=offset)
            return out
        else:
            result = np.empty(slice_shape, dtype=dtype)
            expression(tuple(slice_operands.values()), result, offset=offset)
    else:
        result, _ = _get_result(expression, slice_operands, eval_kwargs, where)

    if out is None:  # avoid copying unnecessarily
        try:
            return result.astype(dtype, copy=False)
        except ComplexWarning:
            # The result is a complex number, so we need to convert it to real.
            # This is a workaround for rigidness of numpy with type casting.
            return result.real.astype(dtype, copy=False)
    else:
        # out should always have maximal shape
        out[_slice] = result
        return out


def _drop_indexed_axes(result, shape, item):
    """Reshape a ``__getitem__`` result to the shape NumPy would have produced.

    Evaluation keeps integer-indexed axes as length 1 so that kernels always
    see the array's own ndim; NumPy drops them.  Squeezing every length-1 axis
    instead also ate ones the index kept, so ask NumPy for the answer:
    ``broadcast_to`` has zero strides and allocates nothing, which makes its
    shape algebra -- Ellipsis, ``None``, negative indices and all -- free.

    See e.g. examples/ndarray/animated_plot.py
    """
    if not (isinstance(item, int) or (hasattr(item, "__iter__") and any(isinstance(i, int) for i in item))):
        return result
    try:
        newshape = np.broadcast_to(np.empty((), dtype=bool), shape)[item].shape
    except IndexError:
        # `item` does not describe `shape` at all: a full reduction consumes the
        # index while slicing its operands (see `_slice_operands_for_eager`), so
        # by now the result is 0-d and there is nothing left to drop.
        return result
    # A where() result is filtered, so its length is data-dependent and `shape`
    # says nothing about it; leave those alone.
    return result.reshape(newshape) if math.prod(newshape) == result.size else result


def _slice_operands_for_eager(operands, item):
    """Slice operands prior to eager evaluation of a full-reduction expression.

    A full reduction (e.g. ``mean(a + b)``) yields a 0-d result, so there is
    nothing to slice in it; slice the operands first instead, e.g.
    ``lazyexpr("mean(a + b)")[:10]`` means ``mean((a + b)[:10])`` (issue #457).

    An operand that only broadcasts cannot take `item` verbatim -- it has fewer
    axes than the expression, or length-1 ones the index would overrun -- so it
    gets the matching slice of itself instead.
    """
    sliceable = {
        key: value
        for key, value in operands.items()
        if not np.isscalar(value) and hasattr(value, "__getitem__") and hasattr(value, "shape")
    }
    if not sliceable:
        return operands
    # The broadcast-slice machinery below pairs each entry of the index with one
    # axis, so it only understands entries that keep an axis.  An integer or a
    # fancy component (array, list, mask) does not, and every operand then has
    # to take the index verbatim -- correct whenever the operands share a shape,
    # and NumPy's own error when one of them only broadcasts.
    if isinstance(item, tuple) and not all(isinstance(i, slice) or i is Ellipsis or i is None for i in item):
        return {key: value[item] if key in sliceable else value for key, value in operands.items()}
    shape = np.broadcast_shapes(*(value.shape for value in sliceable.values()))
    _slice = ndindex.ndindex(item).expand(shape).raw
    slice_shape = ndindex.ndindex(_slice).newshape(shape)

    sliced = {}
    for key, value in operands.items():
        if key not in sliceable:
            sliced[key] = value
        elif check_smaller_shape(value.shape, shape, slice_shape, _slice):
            sliced[key] = value[compute_smaller_slice(shape, value.shape, _slice)]
        else:
            sliced[key] = value[item]
    return sliced


def infer_reduction_dtype(dtype, operation):
    # It may change in the future, but mostly array-api compliant
    my_float = np.result_type(
        dtype, np.float32 if dtype in (np.float32, np.complex64) else blosc2.DEFAULT_FLOAT
    )
    if operation in {ReduceOp.SUM, ReduceOp.PROD, ReduceOp.CUMULATIVE_SUM, ReduceOp.CUMULATIVE_PROD}:
        if np.issubdtype(dtype, np.bool_):
            return np.int64
        if np.issubdtype(dtype, np.unsignedinteger):
            return np.result_type(dtype, np.uint64)
        return np.result_type(dtype, np.int64 if np.issubdtype(dtype, np.integer) else my_float)
    elif operation in {ReduceOp.MEAN, ReduceOp.STD, ReduceOp.VAR}:
        return my_float
    elif operation in {ReduceOp.MIN, ReduceOp.MAX}:
        return dtype
    elif operation in {ReduceOp.ANY, ReduceOp.ALL}:
        return np.bool_
    elif operation in {ReduceOp.ARGMAX, ReduceOp.ARGMIN}:
        return np.int64
    else:
        raise ValueError(f"Unsupported operation: {operation}")


def step_handler(cslice, _slice):
    out = ()
    for s1, s2 in zip(cslice, _slice, strict=True):
        s1start, s1stop = s1.start, s1.stop
        s2start, s2stop, s2step = s2.start, s2.stop, s2.step
        # assume s1step = 1
        newstart = builtins.max(s1start, s2start)
        newstop = builtins.min(s1stop, s2stop)
        rem = (newstart - s2start) % s2step
        if rem != 0:  # only pass through here if s2step is not 1
            newstart += s2step - rem
            # true_stop = start + n*step + 1 -> stop = start + n * step + 1 + residual
            # so n = (stop - start - 1) // step
            newstop = newstart + (newstop - newstart - 1) // s2step * s2step + 1
        out += (slice(newstart, newstop, s2step),)
    return out


@blosc2.jit_config.jit_execution
def reduce_slices(  # noqa: C901
    expression: str | Callable[[tuple, np.ndarray, tuple[int]], None],
    operands: dict,
    reduce_args,
    _slice=NDINDEX_EMPTY_TUPLE,
    **kwargs,
) -> blosc2.NDArray | np.ndarray:
    """Evaluate the expression in chunks of operands.

    This function can handle operands with different chunk shapes.
    Also, it can be used when only a slice of the output array is needed.

    Parameters
    ----------
    expression: str or callable
        The expression or user-defined function (udf) to evaluate.
    operands: dict
        A dictionary containing the operands for the operands.
    reduce_args: dict
        A dictionary with arguments to be passed to the reduction function.
    _slice: ndindex.Tuple sequence of slices and ints. Default = ndindex.Tuple(), optional
        If provided, only the chunks that intersect with this slice
        will be evaluated.
    kwargs: Any, optional
        Additional keyword arguments supported by the :func:`empty` constructor.

    Returns
    -------
    :ref:`NDArray` or np.ndarray
        The resulting output array.
    """
    global try_miniexpr

    # Use a local copy so we don't modify the global
    use_miniexpr = try_miniexpr and not (typed_evaluator_enabled() or _NUMPY_VALUE_PROMOTION)

    if blosc2.IS_WASM:
        # Reduction miniexpr on wasm is currently unstable for scalar reductions (axis=None).
        # Keep wasm reduction evaluation on the regular chunked path until stabilized.
        use_miniexpr = False

    out = kwargs.pop("_output", None)
    res_out_ = None  # temporary required to store max/min for argmax/argmin
    eval_kwargs: dict = kwargs.pop("_eval_kwargs", {})
    if eval_kwargs is None:
        eval_kwargs = {}
    fp_accuracy = kwargs.pop("fp_accuracy", blosc2.FPAccuracy.DEFAULT)
    # Scalar native reductions cannot use elementwise DSL JIT output buffers.
    kwargs.pop("jit", None)
    kwargs.pop("jit_backend", None)
    optimization = kwargs.pop("_optimization", "moderate")
    where: dict | None = kwargs.pop("_where_args", None)
    reduce_op = reduce_args.pop("op")
    reduce_op_str = reduce_args.pop("op_str", None)
    axis = reduce_args["axis"]
    keepdims = reduce_args.get("keepdims", False)
    include_initial = reduce_args.pop("include_initial", False)
    dtype = reduce_args.get("dtype", None)
    if dtype is None:
        dtype = kwargs.pop("dtype", None)
        dtype = infer_reduction_dtype(dtype, reduce_op)
    else:
        del kwargs["dtype"]

    # Compute the shape and chunks of the output array, including broadcasting
    shape = compute_broadcast_shape(operands.values())

    # Validate axis against operand dimensions before any computation.
    if axis is not None and not np.isscalar(axis):
        ndim = len(shape)
        for ax in axis:
            if ax < -ndim or ax >= ndim:
                raise np.exceptions.AxisError(ax, ndim)

    _slice = _slice.raw
    shape_slice = shape
    mask_slice = np.array([isinstance(i, int) for i in _slice], dtype=np.bool_)
    if out is None and _slice != ():
        _slice = tuple(slice(i, i + 1, 1) if isinstance(i, int) else i for i in _slice)
        shape_slice = ndindex.ndindex(_slice).newshape(shape)
        # shape_slice in general not equal to final shape:
        # dummy dims (due to ints) will be dealt with by taking final_slice

    # after slicing, we reduce to calculate shape of output
    if axis is None:
        axis = tuple(range(len(shape_slice)))
    elif np.isscalar(axis):
        axis = (axis,)
    axis = tuple(a if a >= 0 else a + len(shape_slice) for a in axis)
    if np.any(mask_slice):
        add_idx = np.cumsum(mask_slice)
        axis = tuple(a + add_idx[a] for a in axis)  # axis now refers to new shape with dummy dims
    if reduce_args["axis"] is not None:
        # conserve as integer if was not tuple originally
        reduce_args["axis"] = axis[0] if np.isscalar(reduce_args["axis"]) else axis
    if reduce_op in {ReduceOp.CUMULATIVE_SUM, ReduceOp.CUMULATIVE_PROD}:
        reduced_shape = (np.prod(shape_slice),) if reduce_args["axis"] is None else shape_slice
        # if reduce_args["axis"] is None, have to have 1D input array; otherwise, ensure positive scalar
        reduce_args["axis"] = 0 if reduce_args["axis"] is None else axis[0]
        if include_initial:
            reduced_shape = tuple(
                s + 1 if i == reduce_args["axis"] else s for i, s in enumerate(shape_slice)
            )
    else:
        if keepdims:
            reduced_shape = tuple(1 if i in axis else s for i, s in enumerate(shape_slice))
        else:
            reduced_shape = tuple(s for i, s in enumerate(shape_slice) if i not in axis)
            mask_slice = mask_slice[[i for i in range(len(mask_slice)) if i not in axis]]

    if out is not None and reduced_shape != out.shape:
        raise ValueError("Provided output shape does not match the reduced shape.")

    # Choose the array with the largest shape as the reference for chunks
    # Note: we could have expr = blosc2.lazyexpr('numpy_array + 1') (i.e. no choice for chunks)
    blosc2_arrs = tuple(o for o in operands.values() if hasattr(o, "chunks"))
    fast_path = False
    all_ndarray = False
    any_persisted = False
    chunks = None
    blocks = None
    if blosc2_arrs:  # fast path only relevant if there are blosc2 arrays
        operand = max(blosc2_arrs, key=lambda x: len(x.shape))

        # Check if the partitions are aligned (i.e. all operands have the same shape,
        # chunks and blocks, and have no padding). This will allow us to take the fast path.
        same_shape = all(operand.shape == o.shape for o in operands.values() if hasattr(o, "shape"))
        same_chunks = all(operand.chunks == o.chunks for o in operands.values() if hasattr(o, "chunks"))
        same_blocks = all(operand.blocks == o.blocks for o in operands.values() if hasattr(o, "blocks"))
        fast_path = same_shape and same_chunks and same_blocks and (0 not in operand.chunks)
        iter_disk = False
        if fast_path:
            chunks = operand.chunks
            blocks = operand.blocks
            # Check that all operands are NDArray for fast path
            all_ndarray = all(
                isinstance(value, blosc2.NDArray) and value.shape != () for value in operands.values()
            )
            # Check that there is some NDArray that is persisted in the disk
            any_persisted = any(
                (
                    isinstance(value, blosc2.NDArray)
                    and value.shape != ()
                    and value.schunk.urlpath is not None
                )
                for value in operands.values()
            )
            if not blosc2.IS_WASM:
                iter_disk = all_ndarray and any_persisted
                # Experiments say that iter_disk is faster than the regular path for reductions
                # even when all operands are in memory, so no need to check any_persisted
                # New benchmarks are saying the contrary (> 10% slower), so this needs more
                # investigation
                # iter_disk = all_ndarray
            else:
                # WebAssembly does not support threading, so we cannot use the iter_disk option
                iter_disk = False
        else:
            for arr in blosc2_arrs:
                if arr.shape == shape:
                    chunks = arr.chunks
                    break
    if chunks is None:  # have to calculate chunks (this is cheap as empty just creates a thin metalayer)
        temp = blosc2.empty(shape, dtype=dtype)
        chunks = temp.chunks
        del temp

    if (
        typed_evaluator_enabled()
        and try_miniexpr
        and isinstance(expression, str)
        and not _is_dsl_kernel_expression(expression)
        and fast_path
        and all_ndarray
        and reduced_shape == ()
        and _slice == ()
        and out is None
        and not np.any(mask_slice)
        and not eval_kwargs
        and "initial" not in reduce_args
        and fp_accuracy == blosc2.FPAccuracy.DEFAULT
        and (where is None or len(where) == 2)
    ):
        typed_source = f"where({expression}, _where_x, _where_y)" if where is not None else expression
        result = compute_typed_reduction(
            typed_source,
            operands,
            reduce_op=reduce_op,
            reduce_op_str=reduce_op_str,
            explicit_dtype=reduce_args.get("dtype"),
            optimization=optimization,
        )
        if result is not None:
            return result

    # miniexpr reduction path only supported for some cases so far
    if not (fast_path and all_ndarray and reduced_shape == () and _slice == ()):
        use_miniexpr = False

    # Some reductions are not supported yet in miniexpr
    if reduce_op in (ReduceOp.ARGMAX, ReduceOp.ARGMIN, ReduceOp.CUMULATIVE_PROD, ReduceOp.CUMULATIVE_SUM):
        use_miniexpr = False

    # Check whether we can use miniexpr
    if use_miniexpr and isinstance(expression, str):
        if _miniexpr_integer_atan2(expression, operands):
            use_miniexpr = False
        tree = _parse_expression(expression)
        if _miniexpr_inexact_int_literal(expression) or (
            tree is not None and any(isinstance(node, ast.Compare) for node in ast.walk(tree))
        ):
            # Legacy scalar reductions type intermediate conditions using the
            # accumulator dtype, losing float32 rounding and int64 precision.
            # The chunk evaluator retains the condition's own NumPy semantics.
            use_miniexpr = False
        has_complex = any(
            isinstance(op, blosc2.NDArray) and blosc2.isdtype(op.dtype, "complex floating")
            for op in operands.values()
        )
        if has_complex and any(tok in expression for tok in ("!=", "==", "<=", ">=", "<", ">")):
            use_miniexpr = False
        if where is not None and len(where) != 2:
            use_miniexpr = False

    if use_miniexpr:
        cparams = kwargs.pop("cparams", None)
        if cparams is None:
            # Experiments say that not splitting is best (at least on Apple Silicon M4 Pro)
            cparams = blosc2.CParams(splitmode=blosc2.SplitMode.NEVER_SPLIT)
            _restore_code_unit_shuffle(cparams, dtype)
        # Create a fake NDArray just to drive the miniexpr evaluation (values won't be used)
        res_eval = blosc2.uninit(shape, dtype, chunks=chunks, blocks=blocks, cparams=cparams, **kwargs)
        # Compute the number of blocks in the result
        nblocks = res_eval.schunk.nbytes // res_eval.blocksize
        # Initialize aux_reduc based on the reduction operation
        # Padding blocks won't be written, so initial values matter for the final reduction
        if reduce_op in {ReduceOp.SUM, ReduceOp.ANY, ReduceOp.CUMULATIVE_SUM}:
            aux_reduc = np.zeros(nblocks, dtype=dtype)
        elif reduce_op in {ReduceOp.PROD, ReduceOp.ALL, ReduceOp.CUMULATIVE_PROD}:
            aux_reduc = np.ones(nblocks, dtype=dtype)
        elif reduce_op == ReduceOp.MIN:
            # Bool is not an np.integer, and -inf/inf would both be True
            if dtype == np.bool_:
                aux_reduc = np.ones(nblocks, dtype=dtype)
            elif np.issubdtype(dtype, np.integer):
                aux_reduc = np.full(nblocks, np.iinfo(dtype).max, dtype=dtype)
            else:
                aux_reduc = np.full(nblocks, np.inf, dtype=dtype)
        elif reduce_op == ReduceOp.MAX:
            if dtype == np.bool_:
                aux_reduc = np.zeros(nblocks, dtype=dtype)
            elif np.issubdtype(dtype, np.integer):
                aux_reduc = np.full(nblocks, np.iinfo(dtype).min, dtype=dtype)
            else:
                aux_reduc = np.full(nblocks, -np.inf, dtype=dtype)
        else:
            # For other operations, zeros should be safe
            aux_reduc = np.zeros(nblocks, dtype=dtype)
        prefilter_set = False
        expression_miniexpr = None
        try:
            if where is not None:
                expression_miniexpr = f"{reduce_op_str}(where({expression}, _where_x, _where_y))"
            else:
                expression_miniexpr = f"{reduce_op_str}({expression})"
            # Keep reductions as native scalar expressions. A DSL return
            # broadcasts a reduced value across the output block, whereas this
            # prefilter supplies only one accumulator slot per block. Explicit
            # JIT_ON also auto-lifts plain expressions in the native compiler,
            # so use the scalar interpreter until reduction JIT has a separate
            # output-cardinality contract.
            res_eval._set_pref_expr(expression_miniexpr, operands, fp_accuracy, aux_reduc, jit=False)
            prefilter_set = True
            # print("expr->miniexpr:", expression, reduce_op, fp_accuracy)
            # Data won't even try to be compressed, so buffers can be unitialized and reused
            data = np.empty(res_eval.schunk.chunksize, dtype=np.uint8)
            chunk_data = np.empty(res_eval.schunk.chunksize + blosc2.MAX_OVERHEAD, dtype=np.uint8)
            # Exercise prefilter for each chunk
            # The prefilter reads the operands' super-chunks from C, outside their methods
            operand_locks = blosc2.blosc2_ext.HandleLocks(operands.values())
            for nchunk in range(res_eval.schunk.nchunks):
                with operand_locks:
                    res_eval.schunk._prefilter_data(nchunk, data, chunk_data)
        except Exception as e:
            if blosc2.jit_config.execution_options()["math_backend"] is not None:
                raise
            if callable(expression) and _is_dsl_kernel_expression(expression):
                reason = "miniexpr compilation or execution failed for this DSL kernel."
                backend_error = str(e)
                parse_hint = None
                if isinstance(expression_miniexpr, str):
                    parse_hint = _format_dsl_parse_error_hint(expression_miniexpr, backend_error)
                reason = f"{reason}\nBackend error: {backend_error}"
                if parse_hint is not None:
                    reason = f"{reason}\n{parse_hint}"
                raise RuntimeError(_dsl_miniexpr_required_message(reason)) from e
            if prefilter_set:
                raise
            use_miniexpr = False
        finally:
            if prefilter_set:
                res_eval.schunk.remove_prefilter("miniexpr")

        if not use_miniexpr:
            # If miniexpr failed, fallback to regular evaluation
            # (continue to the manual chunked evaluation below)
            pass
        else:
            if reduce_op in {ReduceOp.ANY, ReduceOp.ALL}:
                result = reduce_op.value(aux_reduc, **reduce_args)
            else:
                # The accumulator is always 1-D (one slot per output block).
                # The original axis may refer to dimensions that no longer
                # exist after per-block reduction.  Use axis=0 to combine
                # all block results.
                result = reduce_op.value.reduce(aux_reduc, axis=0)
            return result

    # Iterate over the operands and get the chunks
    chunk_operands = {}
    # Check which chunks intersect with _slice
    if np.isscalar(reduce_args["axis"]):  # iterate over chunks incrementing along reduction axis
        intersecting_chunks = get_intersecting_chunks(_slice, shape, chunks, axis=reduce_args["axis"])
    else:  # iterate over chunks incrementing along last axis
        intersecting_chunks = get_intersecting_chunks(_slice, shape, chunks)
    out_init = False
    res_out_init = False
    # Flat chunk index = sum(chunk coordinate * stride) over the chunk grid
    chunk_strides = []
    if 0 not in chunks:
        nchunks_dim, _ = get_chunks_idx(shape, chunks)
        chunk_strides = [math.prod(nchunks_dim[i + 1 :]) for i in range(len(nchunks_dim))]
    chunk_buffers = (
        _chunk_buffers(operands, shape, chunks) if fast_path and not iter_disk and _slice == () else None
    )

    for chunk_slice in intersecting_chunks:
        cslice = chunk_slice.raw
        nchunk = (
            builtins.sum(c.start // chunks[i] * chunk_strides[i] for i, c in enumerate(cslice))
            if 0 not in chunks
            else 0
        )
        # Check whether current cslice intersects with _slice
        if cslice != () and _slice != ():
            # get intersection of chunk and target
            cslice = step_handler(cslice, _slice)
        offset = tuple(s.start for s in cslice)  # offset for the udf
        starts = [s.start if s.start is not None else 0 for s in cslice]
        unit_steps = builtins.all(s.step == 1 for s in cslice)
        cslice_shape = tuple(s.stop - s.start for s in cslice)
        # get local index of part of out that is to be updated (with no _slice, that is cslice)
        cslice_subidx = cslice if _slice == () else ndindex.ndindex(cslice).as_subindex(_slice).raw
        if _slice == () and fast_path and unit_steps:
            # Fast path
            full_chunk = cslice_shape == chunks
            fill_chunk_operands(
                operands,
                cslice,
                cslice_shape,
                full_chunk,
                nchunk,
                iter_disk,
                chunk_operands,
                reduc=True,
                axis=reduce_args["axis"] if np.isscalar(reduce_args["axis"]) else None,
                chunk_buffers=chunk_buffers,
            )
        else:
            get_chunk_operands(operands, cslice, chunk_operands, shape)

        if reduce_op in {ReduceOp.CUMULATIVE_PROD, ReduceOp.CUMULATIVE_SUM}:
            reduced_slice = (
                tuple(
                    slice(sl.start + 1, sl.stop + 1, sl.step) if i == reduce_args["axis"] else sl
                    for i, sl in enumerate(cslice_subidx)
                )
                if include_initial
                else cslice_subidx
            )
        else:
            reduced_slice = (
                tuple(slice(None) if i in axis else sl for i, sl in enumerate(cslice_subidx))
                if keepdims
                else tuple(sl for i, sl in enumerate(cslice_subidx) if i not in axis)
            )

        # Evaluate and reduce the expression using chunks of operands

        if callable(expression):
            if _is_dsl_kernel_expression(expression):
                _raise_dsl_miniexpr_required(
                    "DSL kernels do not support reductions (e.g. sum()/mean() over an axis); write "
                    "the reduction outside the kernel, over its computed result."
                )
            # TODO: Implement the reductions for UDFs (and test them)
            result = np.empty(cslice_shape, dtype=out.dtype)
            expression(tuple(chunk_operands.values()), result, offset=offset)
            # Reduce the result
            result = reduce_op.value.reduce(result, **reduce_args)
            # Update the output array with the result
            out[reduced_slice] = reduce_op.value(out[reduced_slice], result)
            continue

        if optimization != "moderate":
            eval_kwargs = {**eval_kwargs, "_optimization": optimization}
        result, _ = _get_result(expression, chunk_operands, eval_kwargs, where)
        # Enforce contiguity of result (necessary to fill the out array)
        # but avoid copy if already contiguous
        result = np.require(result, requirements="C")

        # Reduce the result
        if result.shape == ():
            if reduce_op == ReduceOp.SUM and result[()] == 0:
                # Avoid a reduction when result is a zero scalar. Faster for sparse data.
                continue
            # Note that cslice_shape refers to slice of operand chunks, not reduced_slice
            result = np.full(cslice_shape, result[()])
        if reduce_op in {ReduceOp.ANY, ReduceOp.ALL, ReduceOp.CUMULATIVE_SUM, ReduceOp.CUMULATIVE_PROD}:
            result = reduce_op.value(result, **reduce_args)
        elif reduce_op in {ReduceOp.ARGMAX, ReduceOp.ARGMIN}:
            # offset for start of slice
            slice_ref = (
                starts
                if _slice == ()
                else [
                    (s - sl.start - np.sign(sl.step)) // sl.step + 1
                    for s, sl in zip(starts, _slice, strict=True)
                ]
            )
            result_idx = reduce_op.value(result, **reduce_args)
            if reduce_args["axis"] is None:  # indexing into flattened array
                result = result[np.unravel_index(result_idx, shape=result.shape)]
                idx_within_cslice = np.unravel_index(result_idx, shape=cslice_shape)
                result_idx = np.ravel_multi_index(
                    tuple(o + i for o, i in zip(slice_ref, idx_within_cslice, strict=True)), shape_slice
                )
            else:  # axis is an integer
                result = np.take_along_axis(
                    result,
                    np.expand_dims(result_idx, axis=reduce_args["axis"]) if not keepdims else result_idx,
                    axis=reduce_args["axis"],
                )
                result = result if keepdims else result.squeeze(axis=reduce_args["axis"])
                result_idx += slice_ref[reduce_args["axis"]]
        else:
            result = reduce_op.value.reduce(result, **reduce_args)

        if not out_init:
            # if cumsum/cumprod and arrays large, return blosc2 array with same chunks
            chunks_out = (
                chunks
                if np.prod(reduced_shape) * np.dtype(dtype).itemsize > 4 * blosc2.MAX_FAST_PATH_SIZE
                else None
            )
            chunks_out = chunks_out if _slice == () else None
            out_ = convert_none_out(result.dtype, reduce_op, reduced_shape, chunks=chunks_out)
            if out is not None:
                out[:] = out_
                del out_
            else:
                out = out_
            behaved = (
                False
                if not hasattr(out, "chunks")
                else blosc2.are_partitions_behaved(out.shape, out.chunks, out.blocks)
            )
            out_init = True

        # res_out only used be argmin/max and cumulative_sum/prod which only accept axis=int argument
        if (not res_out_init) or (
            np.isscalar(reduce_args["axis"]) and cslice_subidx[reduce_args["axis"]].start == 0
        ):  # starting reduction again along axis
            res_out_ = _get_res_out(result.shape, reduce_args["axis"], dtype, reduce_op)
            res_out_init = True

        # Update the output array with the result
        if reduce_op == ReduceOp.ANY:
            out[reduced_slice] += result
        elif reduce_op == ReduceOp.ALL:
            out[reduced_slice] *= result
        elif res_out_ is not None:
            # need lowest index for which optimum attained
            if reduce_op in {ReduceOp.ARGMAX, ReduceOp.ARGMIN}:
                cond = (res_out_ == result) & (result_idx < out[reduced_slice])
                cond |= res_out_ < result if reduce_op == ReduceOp.ARGMAX else res_out_ > result
                out[reduced_slice] = np.where(cond, result_idx, out[reduced_slice])
                res_out_ = np.where(cond, result, res_out_)
            else:  # CUMULATIVE_SUM or CUMULATIVE_PROD
                idx_lastval = tuple(
                    slice(-1, None) if i == reduce_args["axis"] else slice(None, None)
                    for i, c in enumerate(reduced_slice)
                )
                if reduce_op == ReduceOp.CUMULATIVE_SUM:
                    result += res_out_
                else:  # CUMULATIVE_PROD
                    result *= res_out_
                res_out_ = result[idx_lastval]
                if behaved and result.shape == out.chunks and result.dtype == out.dtype and _slice == ():
                    # Fast path
                    # TODO: Check this only works when slice is () as nchunk is incorrect  for out otherwise
                    out.schunk.update_data(nchunk, result, copy=False)
                else:
                    out[reduced_slice] = result
        else:
            out[reduced_slice] = reduce_op.value(out[reduced_slice], result)

    # No longer need res_out_
    del res_out_

    if out is None:
        if reduce_op in (ReduceOp.MIN, ReduceOp.MAX, ReduceOp.ARGMIN, ReduceOp.ARGMAX):
            raise ValueError("zero-size array in (arg-)min/max reduction operation is not supported")
        if dtype is None:
            # We have no hint here, so choose a default dtype
            dtype = np.float64
        out = convert_none_out(dtype, reduce_op, reduced_shape)

    if reduced_shape == ():
        # convert_none_out() may allocate shape (1,) as an internal buffer for scalar reductions.
        # Collapse it to a numpy scalar while handling both 0-d and 1-d singleton arrays.
        if isinstance(out, np.ndarray):
            out = out[()] if out.ndim == 0 else out[0]
        else:
            out = out[()]
    final_mask = tuple(np.where(mask_slice)[0])
    if np.any(mask_slice):  # remove dummy dims
        out = np.squeeze(out, axis=final_mask)
    # Check if the output array needs to be converted into a blosc2.NDArray
    if kwargs != {} and not np.isscalar(out):
        out = blosc2.asarray(out, **kwargs)
    return out


def _get_res_out(reduced_shape, axis, dtype, reduce_op):
    reduced_shape = (1,) if reduced_shape == () else reduced_shape
    # Get res_out to hold running sums along axes for chunks when doing cumulative sums/prods with axis not None
    if reduce_op in {ReduceOp.CUMULATIVE_SUM, ReduceOp.CUMULATIVE_PROD}:
        temp_shape = tuple(1 if i == axis else s for i, s in enumerate(reduced_shape))
        res_out_ = (
            np.zeros(temp_shape, dtype=dtype)
            if reduce_op == ReduceOp.CUMULATIVE_SUM
            else np.ones(temp_shape, dtype=dtype)
        )
    elif reduce_op in {ReduceOp.ARGMIN, ReduceOp.ARGMAX}:
        temp_shape = reduced_shape
        res_out_ = np.ones(temp_shape, dtype=dtype)
        if np.issubdtype(dtype, np.integer):
            res_out_ *= np.iinfo(dtype).max if reduce_op == ReduceOp.ARGMIN else np.iinfo(dtype).min
        elif np.issubdtype(dtype, np.bool):
            res_out_ = res_out_ if reduce_op == ReduceOp.ARGMIN else np.zeros(temp_shape, dtype=dtype)
        else:
            res_out_ *= np.inf if reduce_op == ReduceOp.ARGMIN else -np.inf
    else:
        res_out_ = None
    return res_out_


def convert_none_out(dtype, reduce_op, reduced_shape, chunks=None):
    reduced_shape = (1,) if reduced_shape == () else reduced_shape
    # out will be a proper numpy.ndarray
    if reduce_op in {ReduceOp.SUM, ReduceOp.CUMULATIVE_SUM, ReduceOp.PROD, ReduceOp.CUMULATIVE_PROD}:
        if reduce_op in (ReduceOp.CUMULATIVE_SUM, ReduceOp.CUMULATIVE_PROD) and chunks is not None:
            out = (
                blosc2.zeros(reduced_shape, dtype=dtype, chunks=chunks)
                if reduce_op == ReduceOp.CUMULATIVE_SUM
                else blosc2.ones(reduced_shape, dtype=dtype, chunks=chunks)
            )
        else:
            out = (
                np.zeros(reduced_shape, dtype=dtype)
                if reduce_op in {ReduceOp.SUM, ReduceOp.CUMULATIVE_SUM}
                else np.ones(reduced_shape, dtype=dtype)
            )
    elif reduce_op == ReduceOp.MIN:
        # Bool is not an np.integer, and inf * bool would be float64
        if dtype == np.bool_:
            out = np.ones(reduced_shape, dtype=dtype)
        elif np.issubdtype(dtype, np.integer):
            out = np.iinfo(dtype).max * np.ones(reduced_shape, dtype=dtype)
        else:
            out = np.inf * np.ones(reduced_shape, dtype=dtype)
    elif reduce_op == ReduceOp.MAX:
        if dtype == np.bool_:
            out = np.zeros(reduced_shape, dtype=dtype)
        elif np.issubdtype(dtype, np.integer):
            out = np.iinfo(dtype).min * np.ones(reduced_shape, dtype=dtype)
        else:
            out = -np.inf * np.ones(reduced_shape, dtype=dtype)
    elif reduce_op == ReduceOp.ANY:
        out = np.zeros(reduced_shape, dtype=np.bool_)
    elif reduce_op == ReduceOp.ALL:
        out = np.ones(reduced_shape, dtype=np.bool_)
    elif reduce_op in {ReduceOp.ARGMIN, ReduceOp.ARGMAX}:
        out = np.zeros(reduced_shape, dtype=blosc2.DEFAULT_INDEX)
    return out


def _validate_chunked_eval_inputs(operands: dict, out, shape, reduce_args: dict) -> bool:
    if operands:
        _, _, _, fast_path = validate_inputs(operands, out, reduce=reduce_args != {})
        return fast_path
    if shape is None and out is None:
        raise ValueError(
            "For UDFs with no inputs, provide `shape` (or an output array) to indicate result shape"
        )
    return False


def _eval_zero_input_dsl_if_needed(
    expression,
    operands: dict,
    where,
    getitem: bool,
    item,
    shape,
    jit,
    jit_backend,
    kwargs: dict,
):
    use_zero_input_dsl_fast_eval = (
        not operands
        and isinstance(expression, DSLKernel)
        and expression.dsl_source is not None
        and where is None
    )
    if not use_zero_input_dsl_fast_eval:
        return False, None

    full_res = fast_eval(
        expression,
        operands,
        getitem=False,
        shape=shape,
        jit=jit,
        jit_backend=jit_backend,
        **kwargs,
    )
    if getitem:
        return True, full_res[item.raw]
    return True, full_res


@blosc2.jit_config.jit_execution
def chunked_eval(  # noqa: C901
    expression: str | Callable[[tuple, np.ndarray, tuple[int]], None], operands: dict, item=(), **kwargs
):
    """
    Evaluate the expression in chunks of operands.

    This chooses the best algorithm exploring different paths depending on the input operands.

    Parameters
    ----------
    expression: str or callable
        The expression or user-defined function (udf) to evaluate.
    operands: dict
        A dictionary containing the operands for the expression.
    item: int, sequence of ints, slice, sequence of slices or None, optional
        The slice(s) of the operands to be used in computation. Note that step parameter is not honored yet.
        Item is used to slice the operands PRIOR to computation.
    kwargs: Any, optional
        Additional keyword arguments supported by the :func:`empty` constructor.  In addition,
        the following keyword arguments are supported:
        _getitem: bool, optional
            Indicates whether the expression is being evaluated for a getitem operation.
            Default is False.
        _output: blosc2.Array, optional
            The output array to store the result.
        _eval_kwargs: dict, optional
            Expression evaluation options, validated independently of backend.
        _where_args: dict, optional
            Additional arguments for conditional evaluation.
    """
    reader = _ChunkReadState()
    token = _chunk_read_state.set(reader)
    try:
        # standardise slice to be ndindex.Tuple
        item = () if item == slice(None, None, None) else item
        item = item if isinstance(item, tuple) else (item,)
        item = tuple(
            slice(s.start, s.stop, 1 if s.step is None else s.step) if isinstance(s, slice) else s
            for s in item
        )
        item = ndindex.ndindex(item)
        shape = kwargs.pop("shape", None)
        if item.raw != () and shape is not None:
            item = item.expand(shape)  # converts to standard tuple form

        getitem = kwargs.pop("_getitem", False)
        out = kwargs.get("_output")
        # Execution policy for miniexpr JIT paths only; never forward to array constructors.
        jit = kwargs.pop("jit", None)
        jit_backend = kwargs.pop("jit_backend", None)
        optimization = kwargs.pop("_optimization", "moderate")

        where: dict | None = kwargs.get("_where_args")
        if where:
            # Make the where arguments part of the operands
            operands = {**operands, **where}

        reduce_args = kwargs.pop("_reduce_args", {})
        # Resolve the JS backend: explicit jit_backend="js", or prefer-js-with-fallback under
        # WebAssembly when the user left jit_backend unset (see _maybe_js_backend).
        expression, jit, jit_backend = _maybe_js_backend(
            expression, jit, jit_backend, reduce_args, operands, kwargs, shape=shape
        )

        fast_path = _validate_chunked_eval_inputs(operands, out, shape, reduce_args)

        # Activate last read cache for NDField instances
        for op in operands:
            if isinstance(operands[op], blosc2.NDField):
                operands[op].ndarr.keep_last_read = True

        if reduce_args:
            # Eval and reduce the expression in a single step
            return reduce_slices(
                expression,
                operands,
                reduce_args=reduce_args,
                _slice=item,
                jit=jit,
                jit_backend=jit_backend,
                _optimization=optimization,
                **kwargs,
            )

        handled, result = _eval_zero_input_dsl_if_needed(
            expression, operands, where, getitem, item, shape, jit, jit_backend, kwargs
        )
        if handled:
            return result

        full_slice = is_full_slice(item.raw)
        if not full_slice or (where is not None and len(where) < 2):
            # The fast path is possible under a few conditions
            if getitem and (where is None or len(where) == 2):
                # Compute the size of operands for the fast path
                unit_steps = np.all([s.step == 1 for s in item.raw if isinstance(s, slice)])
                # shape of slice, if non-unit steps have to decompress full array into memory
                shape_operands = item.newshape(shape) if unit_steps else shape
                _dtype = np.dtype(kwargs.get("dtype", np.float64))
                size_operands = math.prod(shape_operands) * len(operands) * _dtype.itemsize
                # Only take the fast path if the size of operands is relatively small
                if size_operands < blosc2.MAX_FAST_PATH_SIZE:
                    return slices_eval_getitem(expression, operands, _slice=item, shape=shape, **kwargs)
            return slices_eval(expression, operands, getitem=getitem, _slice=item, shape=shape, **kwargs)

        fast_path = full_slice and fast_path
        if not fast_path and full_slice and _is_dsl_kernel_expression(expression) and operands:
            # All-NumPy DSL operands: validate_inputs only sees NDinputs, so it never
            # sets fast_path for this case; reroute it here instead.  Scalar operands
            # (e.g. a Python int/float parameter) don't participate in the shape/grid
            # check, mirroring validate_inputs' own raw_inputs filtering.
            raw_ops = [v for v in operands.values() if not _isscalar(v)]
            if (
                raw_ops
                and all(isinstance(v, np.ndarray) and v.ndim > 0 for v in raw_ops)
                and len({v.shape for v in raw_ops}) == 1
            ):
                fast_path = True

        if fast_path:  # necessarily item is ()
            if getitem:
                # When using getitem, taking the fast path is always possible
                return fast_eval(
                    expression,
                    operands,
                    getitem=True,
                    jit=jit,
                    jit_backend=jit_backend,
                    _optimization=optimization,
                    shape=shape,
                    **kwargs,
                )
            elif (kwargs.get("chunks") is None and kwargs.get("blocks") is None) and (
                out is None or isinstance(out, (blosc2.NDArray, np.ndarray))
            ):
                # If not, the conditions to use the fast path are a bit more restrictive
                # e.g. the user cannot specify chunks or blocks here.
                return fast_eval(
                    expression,
                    operands,
                    getitem=False,
                    jit=jit,
                    jit_backend=jit_backend,
                    _optimization=optimization,
                    shape=shape,
                    **kwargs,
                )
            elif _is_dsl_kernel_expression(expression) and (out is None or isinstance(out, blosc2.NDArray)):
                # DSL kernels require miniexpr and must not fall back to Python execution.
                return fast_eval(
                    expression,
                    operands,
                    getitem=False,
                    jit=jit,
                    jit_backend=jit_backend,
                    _optimization=optimization,
                    shape=shape,
                    **kwargs,
                )

        # End up here by default
        return slices_eval(expression, operands, getitem=getitem, _slice=item, shape=shape, **kwargs)

    finally:
        # Close this invocation's producer even on failure; nested evaluations
        # restore their caller's still-live reader rather than consuming it.
        try:
            reader.close()
        finally:
            _chunk_read_state.reset(token)


def fuse_operands(operands1, operands2):
    new_operands = {}
    dup_operands = {}
    new_pos = len(operands1)
    operand_to_key = {id(v): k for k, v in operands1.items()}
    for k2, v2 in operands2.items():
        try:
            k1 = operand_to_key[id(v2)]
            # The operand is duplicated; keep track of it
            dup_operands[k2] = k1
        except KeyError:
            # The value is not among operands1, so rebase it
            new_op = f"o{new_pos}"
            new_pos += 1
            new_operands[new_op] = v2
    return new_operands, dup_operands


def fuse_expressions(expr, new_base, dup_op):
    new_expr = ""
    skip_to_char = 0
    old_base = 0
    prev_pos = {}
    for i, expr_i in enumerate(expr):
        if i < skip_to_char:
            continue
        if expr_i == "o":
            if i > 0 and expr[i - 1] not in {" ", "("}:
                # Not a variable
                new_expr += expr_i
                continue
            # This is a variable.  Find the end of it.
            j = i + 1
            for k in range(len(expr[j:])):
                if expr[j + k] in " )[,":  # Added comma to the list of delimiters
                    j = k
                    break
            if expr[i + j] == ")":
                j -= 1
            # Extract only the numeric part, handling cases where there might be a comma
            operand_str = expr[i + 1 : i + j + 1]
            # Split by comma and take the first part (the operand index)
            operand_num_str = operand_str.split(",")[0]
            old_pos = int(operand_num_str)
            old_op = f"o{old_pos}"
            if old_op not in dup_op:
                if old_pos in prev_pos:
                    # Keep track of duplicated old positions inside expr
                    new_pos = prev_pos[old_pos]
                else:
                    new_pos = old_base + new_base
                    old_base += 1
                new_expr += f"o{new_pos}"
                prev_pos[old_pos] = new_pos
            else:
                new_expr += dup_op[old_op]
            skip_to_char = i + j + 1
        else:
            new_expr += expr_i
    return new_expr


def check_dtype(op, value1, value2):
    if op in ("contains", "startswith", "endswith"):
        return np.dtype(np.bool_)

    v1_dtype = blosc2.result_type(value1)
    v2_dtype = v1_dtype if value2 is None else blosc2.result_type(value2)
    if op in not_complex_ops and (v1_dtype == np.complex128 or v2_dtype == np.complex128):
        # Ensure that throw exception for functions which don't support complex args
        raise ValueError(f"Invalid operand type for {op}: {v1_dtype, v2_dtype}")
    if op in relational_ops:
        return np.dtype(np.bool_)
    if op in logical_ops:
        # Ensure that both operands are booleans or ints
        if v1_dtype not in (np.bool_, np.int32, np.int64):
            raise ValueError(f"Invalid operand type for {op}: {v1_dtype}")
        if v2_dtype not in (np.bool_, np.int32, np.int64):
            raise ValueError(f"Invalid operand type for {op}: {v2_dtype}")

    if op == "/" and v1_dtype == np.int32 and v2_dtype == np.int32:
        return blosc2.float32

    if typed_evaluator_enabled():
        result = binary_result_dtype(op, value1, value2)
        if result is not None:
            return result

    if op == "/" and np.issubdtype(v1_dtype, np.integer) and np.issubdtype(v2_dtype, np.integer):
        return blosc2.float64

    if op == "arctan2":
        return np.arctan2(np.empty(0, v1_dtype), np.empty(0, v2_dtype)).dtype

    if (v1_dtype.kind in "Mm" or v2_dtype.kind in "Mm") and op in _datetime_binops:
        # result_type describes promotion, not operator semantics, and the two
        # part ways for datetimes: subtracting two datetime64s gives a
        # timedelta64, and adding a timedelta64 to one gives a datetime64.
        # Ask NumPy on empty operands, which costs nothing.
        with contextlib.suppress(TypeError, ValueError):
            return _datetime_binops[op](np.empty(0, v1_dtype), np.empty(0, v2_dtype)).dtype

    # Follow NumPy rules for scalar-array operations
    return blosc2.result_type(value1, value2)


def result_type(
    *arrays_and_dtypes: blosc2.NDArray | int | float | complex | bool | str | blosc2.dtype,
) -> blosc2.dtype:
    """
    Returns the dtype that results from applying type promotion rules (see Type Promotion Rules) to the arguments.

    Parameters
    ----------
    arrays_and_dtypes: Sequence[NDarray | int | float | complex | bool | blosc2.dtype])
        An arbitrary number of input arrays, scalars, and/or dtypes.

    Returns
    -------
    out: blosc2.dtype
        The dtype resulting from an operation involving the input arrays, scalars, and/or dtypes.
    """
    # Follow NumPy rules for scalar-array operations
    # Create small arrays with the same dtypes and let NumPy's type promotion determine the result type
    arrs = [
        (np.array(value).dtype if isinstance(value, str | bytes) else value)
        if (
            np.isscalar(value)
            or not hasattr(value, "dtype")
            or (isinstance(value, np.ndarray) and value.ndim == 0)
        )
        else np.array([0], dtype=convert_dtype(value.dtype))
        for value in arrays_and_dtypes
    ]
    return np.result_type(*arrs)


def _arithmetic_recipe_text(expression, operands):
    """Canonical operand text for an eligible binary arithmetic expression.

    Returns ``None`` unless every operand is an exact expression name and the
    graph is plain binary arithmetic with ASCII names. Canonical text comes from
    the shared syntax tree, so no graph lowering is needed.
    """
    names = arithmetic_names(expression)
    if (
        names is None
        or len(names) != len(operands)
        or not all(type(name) is str for name in operands)
        or names != tuple(sorted(operands))
    ):
        return None
    tree, _ = expression_syntax(expression)
    if not isinstance(tree.body, ast.BinOp) or not all(name.isascii() for name in names):
        return None
    return ast.unparse(tree.body)


def can_cast(from_: blosc2.dtype | blosc2.NDArray, to: blosc2.dtype) -> bool:
    """
    Determines if one data type can be cast to another data type according to (NumPy) type promotion rules.

    Parameters
    ----------
    from_: dtype | NDArray
        Input data type or array from which to cast.

    to: dtype
    Desired data type.

    Returns
    -------
    out:bool
        True if the cast can occur according to type promotion rules; otherwise, False.
    """
    arrs = np.array([0], dtype=from_.dtype) if hasattr(from_, "shape") else from_
    return np.result_type(arrs)


class LazyExpr(LazyArray):
    """Class for hosting lazy expressions.

    This is not meant to be called directly from user space.

    Once the lazy expression is created, it can be evaluated via :func:`LazyExpr.compute`.
    """

    @expression_constructor
    def __init__(self, new_op):  # noqa: C901
        if new_op is None:
            self.expression = ""
            self.operands = {}
            return
        value1, op, value2 = new_op
        value1 = value1._raw_col if hasattr(value1, "_raw_col") else value1
        value2 = value2._raw_col if hasattr(value2, "_raw_col") else value2
        dtype_ = check_dtype(op, value1, value2)  # perform some checks
        # Check that operands are proper Operands, LazyArray or scalars; if not, convert to NDArray objects
        value1 = (
            blosc2.SimpleProxy(value1)
            if not (isinstance(value1, blosc2.Operand | np.ndarray) or np.isscalar(value1))
            else value1
        )
        # Keep numeric NumPy scalars strongly typed; normalize only other scalars.
        value1 = (
            value1.item()
            if np.isscalar(value1) and hasattr(value1, "item") and not _is_typed_numeric_scalar(value1)
            else value1
        )
        if value2 is None:
            if isinstance(value1, LazyExpr):
                self.expression = value1.expression if op is None else f"{op}({value1.expression})"
                # handle constructors which can give empty operands
                self._dtype = (
                    value1.dtype
                    if op is None
                    else _numpy_eval_expr(f"{op}(o0)", {"o0": value1}, prefer_blosc=False).dtype
                )
                self.operands = value1.operands
            else:
                if np.isscalar(value1):
                    value1 = evaluate_chunk(f"{op}({value1!r})")
                    op = None
                self.operands = {"o0": value1}
                self.expression = "o0" if op is None else f"{op}(o0)"
                if op is None and isinstance(value1, blosc2.NDArray):
                    # A bare array (as the NDArray reductions build): no need to infer the dtype
                    self._dtype = value1.dtype
            return
        value2 = (
            blosc2.SimpleProxy(value2)
            if not (isinstance(value2, blosc2.Operand | np.ndarray) or np.isscalar(value2))
            else value2
        )

        # Numeric NumPy scalars are strong operands, even when their value fits
        # in a Python scalar. Normalizing them changes NumPy 2 promotion rules.
        if (
            np.isscalar(value2)
            and hasattr(value2, "item")
            and not _is_typed_numeric_scalar(value2)
            and np.dtype(type(value2)).itemsize < 8
        ):
            value2 = value2.item()

        # Non-finite Python floats repr as bare names ("nan", "inf") that no
        # expression evaluator defines; retype them so they take the
        # typed-scalar branches below and ride as named operands instead of
        # expression text.
        def _retype_nonfinite(v):
            if isinstance(v, float) and not math.isfinite(v):
                return np.float64(v)
            return v

        value1 = _retype_nonfinite(value1)
        value2 = _retype_nonfinite(value2)

        if isinstance(value1, LazyExpr) or isinstance(value2, LazyExpr):
            if isinstance(value1, LazyExpr):
                newexpr = value1.update_expr(new_op)
            else:
                newexpr = value2.update_expr(new_op)
            self.expression = newexpr.expression
            self.operands = newexpr.operands
            self._dtype = newexpr.dtype
            return
        elif op in funcs_2args:
            if np.isscalar(value1) and np.isscalar(value2):
                self.expression = "o0"
                self.operands = {
                    "o0": evaluate_chunk(f"{op}(o0, o1)", {"o0": value1, "o1": value2})
                }  # eager evaluation, preserving strong scalar dtypes
            elif np.isscalar(value2):
                if _is_typed_numeric_scalar(value2):
                    self.operands = {"o0": value1, "o1": value2}
                    self.expression = f"{op}(o0, o1)"
                else:
                    self.operands = {"o0": value1}
                    self.expression = f"{op}(o0, {format_expr_scalar(value2)})"
            elif np.isscalar(value1):
                if _is_typed_numeric_scalar(value1):
                    self.operands = {"o0": value2, "o1": value1}
                    self.expression = f"{op}(o1, o0)"
                else:
                    self.operands = {"o0": value2}
                    self.expression = f"{op}({format_expr_scalar(value1)}, o0)"
            else:
                self.operands = {"o0": value1, "o1": value2}
                self.expression = f"{op}(o0, o1)"
            return

        self._dtype = dtype_
        if np.isscalar(value1) and np.isscalar(value2):
            self.expression = "o0"
            self.operands = {"o0": evaluate_chunk(f"(o0 {op} o1)", {"o0": value1, "o1": value2})}
        elif np.isscalar(value2):
            if hasattr(value2, "dtype"):  # typed numpy scalar — keep as named operand
                self.operands = {"o0": value1, "o1": value2}
                self.expression = f"(o0 {op} o1)"
            else:
                self.operands = {"o0": value1}
                self.expression = f"(o0 {op} {value2!r})"
        elif hasattr(value2, "shape") and value2.shape == () and not _is_typed_numeric_scalar(value2):
            self.operands = {"o0": value1}
            self.expression = f"(o0 {op} {value2[()]})"
        elif np.isscalar(value1):
            if hasattr(value1, "dtype"):  # typed numpy scalar — keep as named operand
                self.operands = {"o0": value2, "o1": value1}
                self.expression = f"(o1 {op} o0)"
            else:
                self.operands = {"o0": value2}
                self.expression = f"({value1!r} {op} o0)"
        elif hasattr(value1, "shape") and value1.shape == () and not _is_typed_numeric_scalar(value1):
            self.operands = {"o0": value2}
            self.expression = f"({value1[()]} {op} o0)"
        else:
            if value1 is value2:
                self.operands = {"o0": value1}
                self.expression = f"(o0 {op} o0)"
            else:
                # This is the very first time that a LazyExpr is formed from two operands
                # that are not LazyExpr themselves
                self.operands = {"o0": value1, "o1": value2}
                self.expression = f"(o0 {op} o1)"

    @expression_method
    def update_expr(self, new_op):
        # Operand deduplication uses identity; never change global equality
        # behavior while other threads may be constructing expressions.
        value1, op, value2 = new_op
        value1 = value1._raw_col if hasattr(value1, "_raw_col") else value1
        value2 = value2._raw_col if hasattr(value2, "_raw_col") else value2
        dtype_ = check_dtype(op, value1, value2)  # conserve dtype
        # The new expression and operands
        expression = None
        new_operands = {}
        # where() handling requires evaluating the expression prior to merge.
        # This is different from reductions, where the expression is evaluated
        # and returned a NumPy array (for usability convenience).
        # We do things like this to enable the fusion of operations like
        # `a.where(0, 1).sum()`.
        # Another possibility would have been to always evaluate where() and produce
        # an NDArray, but that would have been less efficient for the case above.
        if hasattr(value1, "_where_args"):
            value1 = value1.compute()
        if hasattr(value2, "_where_args"):
            value2 = value2.compute()

        if not isinstance(value1, LazyExpr) and not isinstance(value2, LazyExpr):
            # We converted some of the operands to NDArray (where() handling above)
            new_operands = {"o0": value1, "o1": value2}
            expression = "op(o0, o1)" if op in funcs_2args else f"(o0 {op} o1)"
            return self._new_expr(expression, new_operands, guess=False, out=None, where=None)
        elif isinstance(value1, LazyExpr) and isinstance(value2, LazyExpr):
            # Expression fusion
            # Fuse operands in expressions and detect duplicates
            new_operands, dup_op = fuse_operands(value1.operands, value2.operands)
            # Take expression 2 and rebase the operands while removing duplicates
            new_expr = fuse_expressions(value2.expression, len(value1.operands), dup_op)
            expression = (
                f"{op}({value1.expression}, {new_expr})"
                if op in funcs_2args
                else f"({value1.expression} {op} {new_expr})"
            )
            def_operands = value1.operands
        elif isinstance(value1, LazyExpr):
            if np.isscalar(value2) and not _is_typed_numeric_scalar(value2):
                v2 = format_expr_scalar(value2)
            elif hasattr(value2, "shape") and value2.shape == () and not _is_typed_numeric_scalar(value2):
                v2 = format_expr_scalar(value2[()])
            else:
                operand_to_key = {id(v): k for k, v in value1.operands.items()}
                try:
                    v2 = operand_to_key[id(value2)]
                except KeyError:
                    v2 = f"o{len(value1.operands)}"
                    new_operands = {v2: value2}
            if op == "~":
                expression = f"({op}{value1.expression})"
            else:
                expression = (
                    f"{op}({value1.expression}, {v2})"
                    if op in funcs_2args
                    else f"({value1.expression} {op} {v2})"
                )
            def_operands = value1.operands
        else:
            if np.isscalar(value1) and not _is_typed_numeric_scalar(value1):
                v1 = format_expr_scalar(value1)
            elif hasattr(value1, "shape") and value1.shape == () and not _is_typed_numeric_scalar(value1):
                v1 = format_expr_scalar(value1[()])
            else:
                operand_to_key = {id(v): k for k, v in value2.operands.items()}
                try:
                    v1 = operand_to_key[id(value1)]
                except KeyError:
                    v1 = f"o{len(value2.operands)}"
                    new_operands = {v1: value1}
            if op == "[]":  # syntactic sugar for slicing
                expression = f"({v1}[{value2.expression}])"
            else:
                expression = (
                    f"{op}({v1}, {value2.expression})"
                    if op in funcs_2args
                    else f"({v1} {op} {value2.expression})"
                )
                def_operands = value2.operands
        # Return a new expression
        operands = def_operands | new_operands
        expr = self._new_expr(expression, operands, guess=False, out=None, where=None)
        expr._dtype = dtype_  # override dtype with preserved dtype
        return expr

    def _miniexpr_string_dtype(self):
        """Width of a string-valued result, as inferred by miniexpr itself.

        Only miniexpr knows the width its kernels produce: concat adds operand
        widths, and case mapping can expand (numpy's ``result_type`` models
        neither).  Allocating the output container from numpy's answer makes the
        kernel silently truncate, so ask miniexpr whenever a string operand is
        involved.  Returns None when no string is involved or miniexpr cannot
        compile the expression, leaving the numpy path in charge.
        """
        try:
            operands = self.operands
            if not operands or any(v is None for v in operands.values()):
                return None
            dtypes = {}
            for k, v in operands.items():
                dt = getattr(v, "dtype", None)
                if dt is None:
                    return None
                dtypes[k] = dt
            if not any(np.dtype(dt).kind in "US" for dt in dtypes.values()):
                return None
            # The width follows the operand dtypes, not just the expression text, so
            # both go in the key: rebinding the same expression to wider operands
            # must not be answered from the narrower build's cache.  Collecting the
            # dtypes is cheap; what the key protects is the miniexpr compile below.
            key = (self.expression, tuple((k, str(dt)) for k, dt in dtypes.items()))
            cached = getattr(self, "_me_str_dtype_", None)
            if cached is not None and self._me_str_key_ == key:
                return cached[0]
            from blosc2 import blosc2_ext

            out = blosc2_ext.me_output_dtype(self.expression, dtypes)
        except Exception:
            return None
        if out is not None and np.dtype(out).kind not in "US":
            out = None
        self._me_str_dtype_ = (out,)
        self._me_str_key_ = key
        return out

    @property
    @expression_method
    def dtype(self):
        # miniexpr owns string widths; see _miniexpr_string_dtype.
        string_dtype = self._miniexpr_string_dtype()
        if string_dtype is not None:
            return string_dtype
        # Honor self._dtype; it can be set during the building of the expression
        if hasattr(self, "_dtype"):
            # In some situations, we already know the dtype
            return self._dtype
        if (
            hasattr(self, "_dtype_")
            and hasattr(self, "_expression_")
            and self._expression_ == self.expression
        ):
            # Use the cached dtype
            return self._dtype_

        # Return None if there is a missing operand (e.g. a removed file on disk)
        if any(v is None for v in self.operands.values()):
            return None

        _out = _numpy_eval_expr(self.expression, self.operands, prefer_blosc=False)
        self._dtype_ = _out.dtype
        self._expression_ = self.expression
        return self._dtype_

    @property
    def ndim(self) -> int:
        return len(self.shape)

    @property
    @expression_method
    def shape(self):
        # Honor self._shape; it can be set during the building of the expression
        if hasattr(self, "_shape"):
            return self._shape
        if (
            hasattr(self, "_shape_")
            and hasattr(self, "_expression_")
            and self._expression_ == self.expression
        ):
            # Use the cached shape
            return self._shape_

        # Return None if there is a missing operand (e.g. a removed file on disk)
        if any(v is None for v in self.operands.values()):
            return None

        # Operands shape can change, so we always need to recompute this
        if _has_any_constructor_call(self.expression):
            # might have an expression with pure constructors
            opshapes = {k: v if not hasattr(v, "shape") else v.shape for k, v in self.operands.items()}
            _shape = infer_shape(self.expression, opshapes)  # infer shape, includes constructors
        else:
            _shape, chunks, blocks, fast_path = validate_inputs(self.operands, getattr(self, "_out", None))
            if fast_path:
                # fast_path ensure that all the operands have the same partitions
                self._chunks = chunks
                self._blocks = blocks

        self._shape_ = _shape
        self._expression_ = self.expression
        return _shape

    @property
    @expression_method
    def chunks(self):
        if hasattr(self, "_chunks"):
            return self._chunks
        shape, self._chunks, self._blocks, fast_path = validate_inputs(
            self.operands, getattr(self, "_out", None)
        )
        if not hasattr(self, "_shape"):
            self._shape = shape
        if self._shape != shape:  # validate inputs only works for elementwise funcs so returned shape might
            fast_path = False  # be incompatible with true output shape
        if not fast_path:
            # Not using the fast path, so we need to compute the chunks/blocks automatically
            self._chunks, self._blocks = compute_chunks_blocks(self.shape, None, None, dtype=self.dtype)
        return self._chunks

    @property
    @expression_method
    def blocks(self):
        if hasattr(self, "_blocks"):
            return self._blocks
        shape, self._chunks, self._blocks, fast_path = validate_inputs(
            self.operands, getattr(self, "_out", None)
        )
        if not hasattr(self, "_shape"):
            self._shape = shape
        if self._shape != shape:  # validate inputs only works for elementwise funcs so returned shape might
            fast_path = False  # be incompatible with true output shape
        if not fast_path:
            # Not using the fast path, so we need to compute the chunks/blocks automatically
            self._chunks, self._blocks = compute_chunks_blocks(self.shape, None, None, dtype=self.dtype)
        return self._blocks

    @expression_method
    def where(self, value1=None, value2=None):
        """
        Select value1 or value2 values based on the condition of the current expression.

        Parameters
        ----------
        value1: array_like, optional
            The value to select when the condition is True.
        value2: array_like, optional
            The value to select when the condition is False.

        Returns
        -------
        out: LazyExpr
            A new expression with the where condition applied.
        """
        if evaluation_mode() == "safe":
            validate_operands({"value1": value1, "value2": value2})
        if not np.issubdtype(self.dtype, np.bool_):
            raise ValueError("where() can only be used with boolean expressions")
        # This just acts as a 'decorator' for the existing expression
        if value1 is not None and value2 is not None:
            # Guess the outcome dtype for value1 and value2
            dtype = blosc2.result_type(value1, value2)
            args = {"_where_x": value1, "_where_y": value2}
        elif value1 is not None:
            if hasattr(value1, "dtype"):
                dtype = value1.dtype
            else:
                dtype = np.asarray(value1).dtype
            args = {"_where_x": value1}
        elif value2 is not None:
            raise ValueError("where() requires value1 when using value2")
        else:
            args = {}
            dtype = None

        # Create a new expression
        new_expr = blosc2.LazyExpr(new_op=(self, None, None))
        new_expr.expression = self.expression
        new_expr.operands = self.operands
        new_expr._where_args = args
        new_expr._dtype = dtype
        if evaluation_mode() == "safe":
            record_expression_metadata(new_expr)
        return new_expr

    @staticmethod
    def _normalize_where(where):
        if where is None:
            return None
        if evaluation_mode() == "safe":
            validate_operands({"where": where})
        raw_col = getattr(where, "_raw_col", None)
        if raw_col is not None:
            where = raw_col
        if isinstance(where, np.ndarray) and where.dtype == np.bool_:
            where = blosc2.asarray(where)
        if not (
            isinstance(where, (blosc2.NDArray, blosc2.LazyExpr))
            and getattr(where, "dtype", None) == np.bool_
        ):
            raise TypeError(f"Expected boolean blosc2.NDArray or LazyExpr, got {type(where).__name__}")
        return where

    def _where_selected(self, where):
        where = self._normalize_where(where)
        return self if where is None else where.where(self)

    def _where_identity_expr(self, where, identity):
        where = self._normalize_where(where)
        return self if where is None else where.where(self, identity)

    def _reduction_identity(self, op):
        dtype = np.dtype(self.dtype)
        if dtype.kind == "b":
            return op == "min"
        if dtype.kind in "iu":
            info = np.iinfo(dtype)
            return info.max if op == "min" else info.min
        if dtype.kind == "f":
            return np.inf if op == "min" else -np.inf
        raise TypeError(f"where= for {op} is not supported for dtype {dtype!r}")

    @expression_method
    def sum(
        self,
        axis=None,
        dtype=None,
        keepdims=False,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        if where is not None:
            return self._where_identity_expr(where, 0).sum(
                axis=axis, dtype=dtype, keepdims=keepdims, fp_accuracy=fp_accuracy, **kwargs
            )
        reduce_args = {
            "op": ReduceOp.SUM,
            "op_str": "sum",
            "axis": axis,
            "dtype": dtype,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def prod(
        self,
        axis=None,
        dtype=None,
        keepdims=False,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        if where is not None:
            return self._where_identity_expr(where, 1).prod(
                axis=axis, dtype=dtype, keepdims=keepdims, fp_accuracy=fp_accuracy, **kwargs
            )
        reduce_args = {
            "op": ReduceOp.PROD,
            "op_str": "prod",
            "axis": axis,
            "dtype": dtype,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    def get_num_elements(self, axis, item, fp_accuracy=None, **execution_kwargs):
        if hasattr(self, "_where_args") and len(self._where_args) == 1:
            # We have a where condition, so we need to count the number of elements
            # fulfilling the condition
            orig_where_args = self._where_args
            self._where_args = {"_where_x": blosc2.ones(self.shape, dtype=np.int8)}
            try:
                num_elements = self.sum(
                    axis=axis, dtype=np.int64, item=item, fp_accuracy=fp_accuracy, **execution_kwargs
                )
            finally:
                self._where_args = orig_where_args
            return num_elements
        # Compute the number of elements in the array
        shape = self.shape
        if np.isscalar(axis):
            axis = (axis,)
        if item != ():
            # Compute the shape of the slice
            shape = ndindex.ndindex(item).newshape(shape)
        axis = tuple(range(len(shape))) if axis is None else axis
        axis = tuple(a if a >= 0 else a + len(shape) for a in axis)  # handle negative indexing
        return math.prod([shape[i] for i in axis])

    @expression_method
    def mean(
        self,
        axis=None,
        dtype=None,
        keepdims=False,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        execution_kwargs = blosc2.jit_config.pop_execution_options(kwargs)
        where = self._normalize_where(where)
        expr = self if where is None else where.where(self, 0)
        item = kwargs.pop("item", ())
        total_sum = expr.sum(
            axis=axis,
            dtype=dtype,
            keepdims=keepdims,
            item=item,
            fp_accuracy=fp_accuracy,
            **execution_kwargs,
        )
        num_elements = (
            self.get_num_elements(axis, item, fp_accuracy=fp_accuracy, **execution_kwargs)
            if where is None
            else where.where(blosc2.ones(self.shape, dtype=np.int64), 0).sum(
                axis=axis, dtype=np.int64, fp_accuracy=fp_accuracy, **execution_kwargs
            )
        )
        if np.isscalar(num_elements) and num_elements == 0:
            raise ValueError("mean of an empty array is not defined")
        out = total_sum / num_elements
        # NumPy's dtype for a floating `dtype` or input: NumPy 1.x makes a float32 scalar over a
        # Python int float64 (and an array over an int above 65535), and the int64 counts of
        # `where` make it float64 with any NumPy
        mean_dtype = np.dtype(self.dtype if dtype is None else dtype)
        if mean_dtype.kind in "fc" and isinstance(out, (np.ndarray, np.generic)):
            out = out.astype(mean_dtype, copy=False)
        out2 = kwargs.pop("out", None)
        if out2 is not None:
            out2[:] = out
            return out2
        if kwargs != {} and not np.isscalar(out):
            out = blosc2.asarray(out, **kwargs)
        return out

    def _can_full_var(self, dtype):
        """Whether _full_var computes the variance in `dtype`: for float32/float64 operands, where
        miniexpr evaluates it without per-element conversions, into their own dtype (the inlined
        mean would not make the deviations of float32 operands float64)."""
        own = np.dtype(self.dtype)
        return own.kind == "f" and own.itemsize in (4, 8) and (dtype is None or np.dtype(dtype) == own)

    def _full_var(self, dtype, keepdims, fp_accuracy, execution_kwargs):
        """Variance (ddof=0) over all the elements, as two full reductions over the operands.

        The mean goes into the second pass as a Python scalar, which gets inlined into the
        expression; a (1, ..., 1) array would be an operand to broadcast, and keep that reduction
        off its fast paths.  d * d rather than d ** 2 spares a pow() per element.  Only for
        float32/float64 into the same dtype (see _can_full_var).
        """
        mean_value = np.asarray(self.mean(dtype=dtype, fp_accuracy=fp_accuracy, **execution_kwargs)).item()
        # Fold the sign into the operator: miniexpr reductions mis-evaluate a negative literal on
        # the right of a binary operator, as in "(o0 - -0.5)"
        dev = self + (-mean_value) if math.copysign(1.0, mean_value) < 0 else self - mean_value
        out = (dev * dev).mean(dtype=dtype, fp_accuracy=fp_accuracy, **execution_kwargs)
        # Evaluators other than miniexpr may compute against the Python scalar in float64
        out = np.dtype(self.dtype if dtype is None else dtype).type(out)
        return np.reshape(out, (1,) * self.ndim) if keepdims else out

    def _var(self, axis, dtype, keepdims, ddof, where, fp_accuracy, kwargs, finish=None):
        """The variance, as var() returns it; std() passes np.sqrt as `finish`."""
        execution_kwargs = blosc2.jit_config.pop_execution_options(kwargs)
        where = self._normalize_where(where)
        item = kwargs.pop("item", ())
        if item == () and axis is None and where is None and self._can_full_var(dtype):
            out = self._full_var(dtype, keepdims, fp_accuracy, execution_kwargs)
        else:
            if item == ():  # fast path
                mean_value = self.mean(
                    axis=axis,
                    dtype=dtype,
                    keepdims=True,
                    where=where,
                    fp_accuracy=fp_accuracy,
                    **execution_kwargs,
                )
                expr = (self - mean_value) ** 2
            else:
                mean_value = self.mean(
                    axis=axis,
                    dtype=dtype,
                    keepdims=True,
                    where=where,
                    item=item,
                    fp_accuracy=fp_accuracy,
                    **execution_kwargs,
                )
                # TODO: Not optimal because we load the whole slice in memory. Would have to write
                #  a bespoke var function that executed within slice_eval to avoid this probably.
                expr = (self.compute(item, fp_accuracy=fp_accuracy, **execution_kwargs) - mean_value) ** 2
            out = expr.mean(
                axis=axis,
                dtype=dtype,
                keepdims=keepdims,
                where=where,
                fp_accuracy=fp_accuracy,
                **execution_kwargs,
            )
        if ddof != 0:
            num_elements = (
                self.get_num_elements(axis, item, fp_accuracy=fp_accuracy, **execution_kwargs)
                if where is None
                else where.where(blosc2.ones(self.shape, dtype=np.int64), 0).sum(
                    axis=axis, dtype=np.int64, fp_accuracy=fp_accuracy, **execution_kwargs
                )
            )
            # Keep the dtype of the variance: with NumPy 1.x, a float32 scalar times a Python int
            # becomes float64, and so does a float32 array times an int above 65535
            out = (out * num_elements / (num_elements - ddof)).astype(np.asarray(out).dtype, copy=False)
        if finish is not None:
            out = finish(out)
        out2 = kwargs.pop("out", None)
        if out2 is not None:
            out2[:] = out
            return out2
        if kwargs != {} and not np.isscalar(out):
            out = blosc2.asarray(out, **kwargs)
        return out

    @expression_method
    def std(
        self,
        axis=None,
        dtype=None,
        keepdims=False,
        ddof=0,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        return self._var(axis, dtype, keepdims, ddof, where, fp_accuracy, kwargs, np.sqrt)

    @expression_method
    def var(
        self,
        axis=None,
        dtype=None,
        keepdims=False,
        ddof=0,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        return self._var(axis, dtype, keepdims, ddof, where, fp_accuracy, kwargs)

    @expression_method
    def min(
        self,
        axis=None,
        keepdims=False,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        if where is not None:
            identity = self._reduction_identity("min")
            return self._where_identity_expr(where, identity).min(
                axis=axis, keepdims=keepdims, fp_accuracy=fp_accuracy, **kwargs
            )
        reduce_args = {
            "op": ReduceOp.MIN,
            "op_str": "min",
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def max(
        self,
        axis=None,
        keepdims=False,
        where=None,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        if where is not None:
            identity = self._reduction_identity("max")
            return self._where_identity_expr(where, identity).max(
                axis=axis, keepdims=keepdims, fp_accuracy=fp_accuracy, **kwargs
            )
        reduce_args = {
            "op": ReduceOp.MAX,
            "op_str": "max",
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def any(
        self,
        axis=None,
        keepdims=False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.ANY,
            "op_str": "any",
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def all(
        self,
        axis=None,
        keepdims=False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.ALL,
            "op_str": "all",
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def argmax(
        self,
        axis=None,
        keepdims=False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.ARGMAX,
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    @expression_method
    def argmin(
        self,
        axis=None,
        keepdims=False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.ARGMIN,
            "axis": axis,
            "keepdims": keepdims,
        }
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    def cumulative_sum(
        self,
        axis=None,
        include_initial: bool = False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.CUMULATIVE_SUM,
            "axis": axis,
            "include_initial": include_initial,
        }
        if self.ndim != 1 and axis is None:
            raise ValueError("axis must be specified for cumulative_sum of non-1D array.")
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    def cumulative_prod(
        self,
        axis=None,
        include_initial: bool = False,
        fp_accuracy: blosc2.FPAccuracy | None = None,
        **kwargs,
    ):
        reduce_args = {
            "op": ReduceOp.CUMULATIVE_PROD,
            "axis": axis,
            "include_initial": include_initial,
        }
        if self.ndim != 1 and axis is None:
            raise ValueError("axis must be specified for cumulative_prod of non-1D array.")
        return self.compute(_reduce_args=reduce_args, fp_accuracy=fp_accuracy, **kwargs)

    def _eval_constructor(self, expression, constructor, operands):
        """Evaluate a constructor function inside a string expression."""

        def find_args(expr):
            idx = expr.find("(") + 1
            count = 1
            for i, c in enumerate(expr[idx:], start=idx):
                if c == "(":
                    count += 1
                elif c == ")":
                    count -= 1
                if count == 0:
                    return expr[idx:i], i + 1
            raise ValueError("Unbalanced parenthesis in expression")

        # Find the index of the first constructor call.
        match = _find_constructor_call(expression, constructor)
        if match is None:
            raise ValueError(f"Constructor '{constructor}' not found in expression: {expression}")
        idx = match.start()
        # Find the arguments of the constructor function
        try:
            args, idx2 = find_args(expression[idx + len(constructor) :])
        except ValueError as err:
            raise ValueError(f"Unbalanced parenthesis in expression: {expression}") from err
        idx2 = idx + len(constructor) + idx2

        # Give a chance to a possible .reshape() method
        if expression[idx2 : idx2 + len(".reshape(")] == ".reshape(":
            args2, idx3 = find_args(expression[idx2 + len("reshape(") :])
            # Remove a possible shape= from the reshape call (due to rewriting the expression
            # via extract_numpy_scalars(), other variants like .reshape(shape = shape_) work too)
            args2 = args2.replace("shape=", "")
            args = f"{args}, shape={args2}"
            idx2 += len(".reshape") + idx3

        # Evaluate the constructor function
        constructor_func = getattr(blosc2, constructor)
        _globals = {constructor: constructor_func}
        # Add the blosc2 constructors and dtype symbols to the globals
        _globals |= {k: getattr(blosc2, k) for k in constructors}
        _globals |= dtype_symbols
        evalcons = f"{constructor}({args})"

        # Constructor results that read operands are values, not immutable
        # plans. Rebuild them on each safe evaluation, even if metadata did not
        # change. Constant-only constructors may keep their existing cache.
        cacheable = evaluation_mode() == "full" or not parse_expression(evalcons).names

        # Internal constructors will be cached for avoiding multiple computations
        if not hasattr(self, "cons_cache"):
            self.cons_cache = {}
        if cacheable and evalcons in self.cons_cache:
            value = self.cons_cache[evalcons]
            if evaluation_mode() == "safe":
                validate_operands({"constructor": value})
            return value, expression[idx:idx2]
        _globals["blosc2"] = blosc2
        value = evaluate_expression(evalcons, _globals, operands)
        if cacheable:
            self.cons_cache[evalcons] = value

        return value, expression[idx:idx2]

    @staticmethod
    def _is_full_slice(lazy_item):
        """Return True if *lazy_item* is a no-op full slice (() or slice(None))."""
        if isinstance(lazy_item, slice):
            return lazy_item == slice(None)
        if isinstance(lazy_item, tuple):
            return lazy_item == () or all(isinstance(s, slice) and s == slice(None) for s in lazy_item)
        return False

    @staticmethod
    def _collect_flat_indices_from_bool_ndarray(bool_ndarray):
        """Collect flat indices of True positions from a compressed boolean NDArray.

        Uses :meth:`~blosc2.NDArray.iterchunks_info` to skip chunks that are
        special values (e.g. all-False ``ZERO``), avoiding decompression and
        scanning for those chunks.

        Parameters
        ----------
        bool_ndarray: blosc2.NDArray
            A 1D NDArray with boolean dtype.

        Returns
        -------
        np.ndarray
            Flat indices of True positions (int64).
        """
        chunk_len = bool_ndarray.chunks[0]
        nitems = bool_ndarray.shape[0]
        all_indices = []

        for info in bool_ndarray.iterchunks_info():
            offset = info.nchunk * chunk_len
            # Items of this chunk inside the array: the last chunk's padding is not data, and it
            # can hold anything (e.g. the fill value of a blosc2.full() array)
            nvalid = builtins.min(chunk_len, nitems - offset)
            # Skip special-value chunks that are entirely False
            if info.special == blosc2.SpecialValue.ZERO:
                continue
            if info.special == blosc2.SpecialValue.VALUE:
                if not bool(info.repeated_value):  # repeated_value is False/0
                    continue
                # repeated_value is True: all elements in this chunk are True
                all_indices.append(np.arange(offset, offset + nvalid, dtype=np.int64))
                continue

            # Normal chunk: decompress and scan for True positions
            raw = bool_ndarray.schunk.decompress_chunk(info.nchunk)
            arr = np.frombuffer(raw, dtype=np.bool_)[:nvalid]
            idx = np.flatnonzero(arr)
            if len(idx) > 0:
                all_indices.append(idx + offset)

        if not all_indices:
            return np.array([], dtype=np.int64)
        return np.concatenate(all_indices)

    def _where_getitem_fastpath(self, item, kwargs):
        """Fast path for where(cond, x) full-slice getitem calls.

        Returns ``None`` when the fast path does not apply.
        """
        from . import indexing

        simple_operand_expr = self.expression.strip("() ") in self.operands
        if not (
            hasattr(self, "_where_args")
            and len(self._where_args) == 1
            and not hasattr(self, "_indices")
            and not hasattr(self, "_order")
            and "_reduce_args" not in kwargs
            and isinstance(self._where_args["_where_x"], blosc2.NDArray)
            and self._is_full_slice(item)
            and not simple_operand_expr
        ):
            return None

        # Preserve index/caching behavior for indexed queries.
        if kwargs.get("_use_index", True) and indexing.will_use_index(self):
            return None

        cond_expr = blosc2.LazyExpr._new_expr(self.expression, self.operands, guess=False)
        if not blosc2.isdtype(cond_expr.dtype, "bool"):
            return None

        target = self._where_args["_where_x"]
        if cond_expr.ndim != 1 or target.ndim != 1:
            return None

        cache_tokens = [indexing.SELF_TARGET_NAME]
        cached_coords = indexing.get_cached_coords(target, self.expression, cache_tokens, None)
        if cached_coords is not None:
            cached_plan = indexing.IndexPlan(
                usable=True, reason="cache-hit", base=target, exact_positions=cached_coords
            )
            return indexing.evaluate_full_query(self._where_args, cached_plan)

        # Evaluate the condition using the miniexpr prefilter (fastest first pass)
        mask = cond_expr.compute((), cparams=_TRANSIENT_MASK_CPARAMS)

        # Collect flat indices by iterating the compressed bool chunks,
        # avoiding a full-mask decompression + count_nonzero + flatnonzero.
        flat_indices = self._collect_flat_indices_from_bool_ndarray(mask)
        indexing.store_cached_coords(target, self.expression, cache_tokens, None, flat_indices)
        plan = indexing.IndexPlan(usable=True, reason="mask-scan", base=target, exact_positions=flat_indices)
        return indexing.evaluate_full_query(self._where_args, plan)

    def _compute_expr(self, item, kwargs):  # noqa: C901
        output = kwargs.get("_output")
        if (
            type(output) is np.ndarray
            and output.dtype.kind == "c"
            and type(item) is tuple
            and not item
            and not any(name in kwargs for name in ("_where_args", "_indices", "_order", "_reduce_args"))
        ):
            root = parse_expression(self.expression).root
            if (
                root[0] == "call"
                and root[1] == "complex"
                and not root[3]
                and all(node[0] == "name" for node in root[2])
            ):
                casting = (kwargs.get("_eval_kwargs") or {}).get("casting", "same_kind")
                if not np.can_cast(np.dtype("complex128"), output.dtype, casting=casting):
                    raise TypeError("Cannot cast complex construction into destination")
                return safe_numpy_globals["complex"](
                    *(self.operands[node[1]] for node in root[2]), out=output
                )
        if (
            (
                (type(output) is np.ndarray and not output.flags.c_contiguous)
                or any(type(value) is np.ndarray and value.size == 0 for value in self.operands.values())
            )
            and (output is None or type(output) is np.ndarray)
            and type(item) is tuple
            and not item
            and not any(name in kwargs for name in ("_where_args", "_indices", "_order", "_reduce_args"))
            and all(type(value) is np.ndarray or np.isscalar(value) for value in self.operands.values())
        ):
            # Layout is a destination contract, not a reason to select NumExpr.
            # Until native sinks support strided writes, the approved NumPy graph
            # supplies semantics; copyto preserves the caller's layout and identity.
            result = parse_expression(self.expression).evaluate(self.operands, prefer_blosc=False)
            if output is None:
                return np.asarray(result)
            np.copyto(output, result, casting=(kwargs.get("_eval_kwargs") or {}).get("casting", "same_kind"))
            return output
        if any(method in self.expression for method in eager_funcs):
            # We have reductions in the expression (probably coming from a string lazyexpr)
            # Also includes slice
            _globals = get_expr_globals(self.expression)
            operands = self.operands
            # Test the type before the value: `item` can be an array (fancy
            # indexing), and `==` against a slice would broadcast instead of
            # answering yes or no.
            is_sliced = isinstance(item, slice) or (
                isinstance(item, tuple) and any(isinstance(i, slice) for i in item)
            )
            # Match chunked_eval: a bare full slice is a no-op.
            if isinstance(item, slice) and item == slice(None, None, None):
                item, is_sliced = (), False
            if (
                is_sliced
                and self.shape == ()
                # `.slice()` already carries its own index; do not apply ours twice
                and ".slice(" not in self.expression
            ):
                # A full reduction yields a 0-d result, so there is nothing to slice
                # in it; slice the operands first instead, e.g.
                # lazyexpr("mean(a + b)")[:10] means mean((a + b)[:10]).
                operands = _slice_operands_for_eager(operands, item)
                item = ()
            lazy_expr = evaluate_expression(self.expression, _globals, operands)
            if not isinstance(lazy_expr, blosc2.LazyExpr):
                key, mask = process_key(item, lazy_expr.shape)
                # An immediate evaluation happened (e.g. all operands are numpy arrays)
                if hasattr(self, "_where_args"):
                    # We need to apply the where() operation
                    if len(self._where_args) == 1:
                        # We have a single argument
                        where_x = self._where_args["_where_x"]
                        return (where_x[:][lazy_expr])[key]
                    if len(self._where_args) == 2:
                        # We have two arguments
                        where_x = self._where_args["_where_x"]
                        where_y = self._where_args["_where_y"]
                        return np.where(lazy_expr, where_x, where_y)[key]
                out = kwargs.get("_output", None)
                if out is not None:
                    # This is not exactly optimized, but it works for now
                    out[...] = lazy_expr[key]
                    return out
                arr = lazy_expr[key]
                if builtins.sum(mask) > 0:
                    # Correct shape to adjust to NumPy convention.
                    new_shape = tuple(arr.shape[i] for i in range(len(mask)) if not mask[i])
                    arr = np.reshape(arr, new_shape)
                return arr

            return chunked_eval(lazy_expr.expression, lazy_expr.operands, item, **kwargs)

        if _has_any_constructor_call(self.expression):
            expression = self.expression
            newexpr = expression
            newops = self.operands.copy()
            # We have constructors in the expression (probably coming from a string lazyexpr)
            # Let's replace the constructors with the actual NDArray objects
            for constructor in constructors:
                if not _has_constructor_call(newexpr, constructor):
                    continue
                while _has_constructor_call(newexpr, constructor):
                    # Get the constructor function and replace it by an NDArray object in the operands
                    # Find the constructor call and its arguments
                    value, constexpr = self._eval_constructor(newexpr, constructor, newops)
                    # Add the new operand to the operands; its name will be temporary
                    newop = f"_c{len(newops)}"
                    newops[newop] = value
                    # Replace the constructor call by the new operand
                    newexpr = newexpr.replace(constexpr, newop)

            _globals = get_expr_globals(newexpr)
            lazy_expr = evaluate_expression(newexpr, _globals, newops)
            if isinstance(lazy_expr, blosc2.NDArray | np.ndarray):
                # Almost done (probably the expression is made of only constructors)
                # We only have to define the trivial expression ("o0")
                lazy_expr = blosc2.LazyExpr(new_op=(lazy_expr, None, None))

            return chunked_eval(lazy_expr.expression, lazy_expr.operands, item, **kwargs)

        # Optimization: for where(cond, x) (1-arg) with a boolean condition,
        # stream matching values chunk-by-chunk without materializing the full mask.
        fastpath_result = self._where_getitem_fastpath(item, kwargs)
        if fastpath_result is not None:
            return fastpath_result

        return chunked_eval(self.expression, self.operands, item, **kwargs)

    # TODO: argsort and sort are repeated in LazyUDF; refactor
    def argsort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        if self.dtype.fields is None:
            raise NotImplementedError("argsort() can only be used with structured arrays")
        if not hasattr(self, "_where_args") or len(self._where_args) != 1:
            raise ValueError("argsort() can only be used with conditions")
        # Build a new lazy array
        lazy_expr = copy.copy(self)
        # ... and assign the new attributes
        lazy_expr._indices = True
        if order:
            lazy_expr._order = order
        # dtype changes to int64
        lazy_expr._dtype = np.dtype(np.int64)
        return lazy_expr

    def sort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        if self.dtype.fields is None:
            raise NotImplementedError("sort() can only be used with structured arrays")
        if not hasattr(self, "_where_args") or len(self._where_args) != 1:
            raise ValueError("sort() can only be used with conditions")
        # Build a new lazy expression
        lazy_expr = copy.copy(self)
        # ... and assign the new attributes
        if order:
            lazy_expr._order = order
        return lazy_expr

    def will_use_index(self) -> bool:
        """Return whether the current lazy query can use an index."""
        from . import indexing

        return indexing.will_use_index(self)

    def explain(self) -> dict:
        """Explain how this lazy query will be executed.

        Returns a dictionary describing the planner decision for the current
        query. Typical fields include whether an index will be used, the chosen
        index kind and level, candidate counts, and the lookup path selected
        for ``full`` indexes.

        Returns:
            dict: Query planning metadata for the current expression.

        Examples:
            >>> import numpy as np
            >>> import blosc2
            >>> arr = blosc2.asarray(np.arange(10))
            >>> _ = arr.create_index(kind=blosc2.IndexKind.FULL)
            >>> expr = blosc2.lazyexpr("(a >= 3) & (a < 6)", {"a": arr}).where(arr)
            >>> info = expr.explain()
            >>> info["will_use_index"]
            True
            >>> info["kind"]
            'full'
        """
        from . import indexing

        return indexing.explain_query(self)

    @expression_method
    @blosc2.jit_config.math_execution
    def compute(  # noqa: C901 -- native-first/strict dispatch plus legacy output policies
        self,
        item=(),
        fp_accuracy: blosc2.FPAccuracy | None = None,
        jit=None,
        jit_backend: str | None = None,
        math_backend: str | None = None,
        _require_native=None,
        _native_tile_items=1024,
        **kwargs,
    ) -> blosc2.NDArray:
        self.__dict__.pop("_native_execution_report", None)
        if "ne_args" in kwargs:
            if "eval_kwargs" in kwargs:
                raise TypeError("Pass only one of 'eval_kwargs' and the legacy 'ne_args' alias")
            kwargs["eval_kwargs"] = kwargs.pop("ne_args")
        if "eval_kwargs" in kwargs:
            kwargs["_eval_kwargs"] = kwargs.pop("eval_kwargs")
        if _require_native:
            from .native_graph import compute_native_graph

            if jit_backend is not None or fp_accuracy is not None:
                raise ValueError(
                    "Native-required Menudet execution does not accept acceleration/accuracy overrides"
                )
            return compute_native_graph(self, item, tile_items=_native_tile_items, jit=jit is True, **kwargs)
        jit, jit_backend = _jit_from_env(jit, jit_backend)
        if _require_native is None:
            from .native_graph import (
                compute_native_graph,
                compute_native_prefilter_if_eligible,
                compute_resident_if_eligible,
                prepare_native_first,
            )

            # Legacy chunked execution resolves inherited policy in its JIT
            # decorator. Automatic dispatch must respect that same policy
            # before choosing a route that cannot honor backend/accuracy
            # overrides. Keep the original kwargs for legacy resolution.
            policy = blosc2.jit_config.execution_options()
            native_jit = policy["jit"] if jit is None else jit
            native_backend = policy["jit_backend"] if jit_backend is None else jit_backend
            native_accuracy = fp_accuracy
            if native_accuracy is None and policy["fp_accuracy"] != blosc2.FPAccuracy.DEFAULT:
                native_accuracy = policy["fp_accuracy"]

            resident = (
                compute_resident_if_eligible(
                    self,
                    item,
                    jit=native_jit,
                    jit_backend=native_backend,
                    fp_accuracy=native_accuracy,
                    options=kwargs,
                )
                if _native_tile_items == 1024
                else None
            )
            if resident is not None:
                return resident

            stored = compute_native_prefilter_if_eligible(
                self,
                item,
                jit=native_jit,
                jit_backend=native_backend,
                fp_accuracy=native_accuracy,
                options=kwargs,
            )
            if stored is not None:
                return stored

            native_options = dict(kwargs)
            if hasattr(self, "_output"):
                native_options.setdefault("out", self._output)
            if type(native_options.get("out")) is np.ndarray:
                native_options["_getitem"] = True

            prepared = prepare_native_first(
                self,
                item,
                jit=native_jit,
                jit_backend=native_backend,
                fp_accuracy=native_accuracy,
                options=native_options,
            )
            if prepared is not None:
                return compute_native_graph(
                    self,
                    tile_items=_native_tile_items,
                    prepared=prepared,
                    parallel_reductions=True,
                    **native_options,
                )
        # When NumPy ufuncs are called, the user may add an `out` parameter to kwargs
        if "out" in kwargs:  # use provided out preferentially
            kwargs["_output"] = kwargs.pop("out")
        elif hasattr(self, "_output"):
            kwargs["_output"] = self._output

        if "_eval_kwargs" not in kwargs and hasattr(self, "_eval_kwargs"):
            kwargs["_eval_kwargs"] = self._eval_kwargs
        if hasattr(self, "_where_args"):
            kwargs["_where_args"] = self._where_args
        if hasattr(self, "_optimization"):
            kwargs.setdefault("_optimization", self._optimization)
        kwargs.setdefault("fp_accuracy", fp_accuracy)
        if jit is not None:
            kwargs["jit"] = jit
        if jit_backend is not None:
            kwargs["jit_backend"] = jit_backend
        kwargs["dtype"] = self.dtype
        kwargs["shape"] = self.shape
        if hasattr(self, "_indices"):
            kwargs["_indices"] = self._indices
        if hasattr(self, "_order"):
            kwargs["_order"] = self._order
        result = self._compute_expr(item, kwargs)
        if "_order" in kwargs and "_indices" not in kwargs:
            # We still need to apply the index in result
            x = self._where_args["_where_x"]
            result = x[result]  # always a numpy array; TODO: optimize this for _getitem not in kwargs
        if (
            "_getitem" not in kwargs
            and "_output" not in kwargs
            and "_reduce_args" not in kwargs
            and not isinstance(result, blosc2.NDArray)
        ):
            # Get rid of all the extra kwargs that are not accepted by blosc2.asarray
            kwargs_not_accepted = {
                "_where_args",
                "_indices",
                "_order",
                "_eval_kwargs",
                "_use_index",
                "_optimization",
                "dtype",
                "shape",
                "fp_accuracy",
            }
            kwargs = {key: value for key, value in kwargs.items() if key not in kwargs_not_accepted}
            result = blosc2.asarray(result, **kwargs)
        return result

    def native_kernel(self):
        """Export the eligible elementwise safe graph as an immutable native Menudet 0.1 beta plan.

        Unsupported syntax/signatures reject; no Python numerical fallback. Root
        logical reduction options are separate from this elementwise artifact.
        This explicit API uses Menudet's NumPy-2-style numerical semantics even
        when the installed NumPy is older than 2.
        """
        from .native_graph import lower_native_graph

        plan, _, reduction = lower_native_graph(self)
        if reduction:
            raise ValueError("Root logical reductions require native compute, not an elementwise export")
        return blosc2.MenudetKernel.from_json(plan.map_json())

    def __getitem__(self, item):
        safe = evaluation_mode() == "safe" or getattr(self, "_evaluation", "full") == "safe"
        # Use admitted pre-read geometry for axis removal. A remote refresh may
        # invalidate the handle after its read completed; do not re-enter that
        # dependency merely to reshape the already independent result.
        shape = self.shape if safe else None
        kwargs = {"_getitem": True}
        result = self.compute(item, **kwargs)
        return _drop_indexed_axes(result, shape if safe else self.shape, item)

    def slice(self, item):
        return self.compute(item)  # should do a slice since _getitem = False

    def __str__(self):
        return f"{self.expression}"

    @property
    def info(self):
        return InfoReporter(self)

    @property
    def info_items(self):
        items = []
        items += [("type", f"{self.__class__.__name__}")]
        items += [("expression", self.expression)]
        opsinfo = {}
        for key, value in self.operands.items():
            if isinstance(value, blosc2.RemoteArray):
                urlpath = value.urlpath
                opsinfo[key] = urlpath if isinstance(urlpath, str) else str(value)
                continue
            schunk = getattr(value, "schunk", None)
            if schunk is not None:
                urlpath = getattr(schunk, "urlpath", None)
                opsinfo[key] = str(value) if urlpath is None else urlpath
            else:
                # C2Array is a remote reference without a local SChunk.
                opsinfo[key] = getattr(value, "urlpath", str(value))
        items += [("operands", opsinfo)]
        items += [("shape", self.shape)]
        items += [("dtype", self.dtype)]
        return items

    def save(self, urlpath=None, **kwargs):
        if urlpath is None:
            raise ValueError("To save a LazyArray you must provide an urlpath")

        kwargs["urlpath"] = urlpath
        kwargs["mode"] = "w"  # always overwrite the file in urlpath
        self._to_b2object_carrier(**kwargs)

    def to_cframe(self) -> bytes:
        return self._to_b2object_carrier().to_cframe()

    @expression_method
    def _expression_recipe(self):
        expression = self.expression_tosave if hasattr(self, "expression_tosave") else self.expression
        operands_ = self.operands_tosave if hasattr(self, "operands_tosave") else self.operands
        validate_expr(expression)
        return expression, operands_

    def _to_b2object_carrier(self, **kwargs):
        expression, operands_ = self._expression_recipe()
        validate_expr(expression)

        payload = {"kind": "lazyexpr", "version": 1, "expression": expression, "operands": {}}
        carrier_urlpath = kwargs.get("urlpath")
        carrier_parent = Path(carrier_urlpath).parent if carrier_urlpath is not None else None
        for key, value in operands_.items():
            if type(value) is blosc2.NDField:
                payload["operands"][key] = encode_operand_reference(value, base_path=carrier_parent)
                continue
            if isinstance(value, blosc2.C2Array):
                payload["operands"][key] = encode_b2object_payload(value)
                continue
            if isinstance(value, blosc2.RemoteArray):
                payload["operands"][key] = blosc2.Ref.from_object(value).to_dict()
                continue
            if isinstance(value, blosc2.Proxy):
                value = value._cache
            ref = getattr(value, "_blosc2_ref", None)
            if isinstance(ref, blosc2.Ref):
                payload["operands"][key] = ref.to_dict()
                continue
            if not hasattr(value, "schunk"):
                raise ValueError("To save a LazyArray, all operands must be persistent Blosc2 array objects")
            if value.schunk.urlpath is None:
                raise ValueError("To save a LazyArray, all operands must be stored on disk/network")
            operand_urlpath = Path(value.schunk.urlpath)
            if carrier_parent is not None and not operand_urlpath.is_absolute():
                ref_urlpath = operand_urlpath.as_posix()
            elif carrier_parent is not None:
                try:
                    ref_urlpath = operand_urlpath.relative_to(carrier_parent).as_posix()
                except ValueError:
                    ref_urlpath = operand_urlpath.as_posix()
            else:
                ref_urlpath = operand_urlpath.as_posix()
            payload["operands"][key] = {"kind": "urlpath", "version": 1, "urlpath": ref_urlpath}
        array = make_b2object_carrier(
            "lazyexpr",
            self.shape,
            self.dtype,
            chunks=self.chunks,
            blocks=self.blocks,
            **kwargs,
        )
        write_b2object_payload(array, payload)
        write_b2object_user_vlmeta(array, self._get_user_vlmeta())
        return array

    @classmethod
    def _new_expr(cls, expression, operands, guess, out=None, where=None, eval_kwargs=None):  # noqa: C901
        native_metadata = (
            not _NUMPY_VALUE_PROMOTION
            and guess
            and type(expression) is str
            and type(operands) is dict
            and operands
            and out is None
            and where is None
            and eval_kwargs is None
            and evaluation_mode() == "full"
        )
        text = _arithmetic_recipe_text(expression, operands) if native_metadata else None
        if text is None or "#" in expression or _blacklist_re.search(expression):
            validate_expr(expression)
        if native_metadata:
            from .native_graph import (
                _native_first_array,
                _native_first_syntax,
                _native_plan_cache_key,
            )

            if all(_native_first_array(value) for value in operands.values()):
                graph = None
                renamed = bindings = None
                if text is None:
                    try:
                        graph = parse_expression(expression)
                    except (exceptions.UnsafeDeserializationError, ValueError):
                        graph = (
                            None  # Trusted expressions outside the reviewed grammar keep legacy preparation.
                        )
                    if (
                        graph is not None
                        and graph.names == operands.keys()
                        and (graph.arithmetic or _native_first_syntax(expression))
                    ):
                        tree, nodes = expression_syntax(expression)
                        if (
                            graph.root[0] == "binary"
                            and all(name.isascii() for name in graph.names)
                            and (graph.arithmetic or not any(isinstance(node, ast.Call) for node in nodes))
                        ):
                            text = graph.text
                        else:
                            renamed, bindings = conserve_functions(
                                expression, operands, dict(operands), tree=tree
                            )
                if text is not None:
                    bindings, aliases = {}, {}

                    def rebase(match):
                        name = match[0]
                        if name not in operands:
                            return name
                        value = operands[name]
                        key = aliases.get(id(value))
                        if key is None:
                            key = aliases[id(value)] = f"o{len(bindings)}"
                            bindings[key] = value
                        return key

                    # Canonical numeric text has no quoted strings or attribute names to rewrite.
                    renamed = _IDENTIFIER_RE.sub(rebase, text)
                if renamed is not None:
                    root_kind = "binary" if text is not None else graph.root[0]
                    result = cls(None)
                    result.expression = f"({renamed})"
                    result.operands = bindings
                    result.expression_tosave = expression
                    result.operands_tosave = operands
                    result._eval_kwargs = eval_kwargs
                    result._evaluation = "full"
                    policy = blosc2.jit_config.execution_options()
                    native_jit, native_backend = _jit_from_env(policy["jit"], policy["jit_backend"])
                    if (
                        native_backend is None
                        and policy["fp_accuracy"] == blosc2.FPAccuracy.DEFAULT
                        and root_kind in {"binary", "unary", "compare"}
                        and not re.search(r"\bcopy\s*\(", expression)
                    ):
                        try:
                            from .graph_plan import NativeGraph
                            from .native_graph import native_weak_scalars_eligible, prepare_resident

                            # The reviewed arithmetic subset can get metadata from its execution plan.
                            inputs = result.operands
                            resident = prepare_resident(result.expression, inputs, jit=native_jit)
                            if resident is not None:
                                result._resident_native = resident
                                _, plan, schedule = resident
                                info = {"dtype": plan.inferred_dtype, "shape": resident[0][2]}
                            else:
                                plan = NativeGraph.from_expression(
                                    result.expression,
                                    {name: value.dtype.name for name, value in inputs.items()},
                                    jit=native_jit,
                                )
                                plan._frontend = "native-expression"
                                if not native_weak_scalars_eligible(plan, result.expression, inputs):
                                    raise NotImplementedError(
                                        "Checked scalar metadata requires legacy preparation"
                                    )
                                schedule = plan.specialize(
                                    {name: (value.dtype, value.shape) for name, value in inputs.items()}
                                )
                                info = schedule.info()
                            if plan.stages == 1 and info["dtype"].kind in "biuf":
                                result._dtype = info["dtype"]
                                result._shape = info["shape"]
                                key = _native_plan_cache_key(
                                    result,
                                    native_jit,
                                    {"_getitem": True},
                                    configuration=None if resident is None else resident[0][-1][0],
                                )
                                prepared = (key, (plan, tuple(inputs), False))
                                if all(type(value) is np.ndarray for value in inputs.values()):
                                    result._prepared_native = prepared
                                else:
                                    # Compressed inputs must still pass execution/layout admission before reuse.
                                    result._metadata_native = prepared
                                return result
                        except (NotImplementedError, blosc2.MenudetError, TypeError, ValueError):
                            pass
                    if graph is None:
                        graph = parse_expression(expression)
                    shape = graph.infer_shape(operands)
                    dtype = graph.infer_dtype(operands)
                    if shape is not None and dtype is not None:
                        # Reviewed metadata avoids evaluating synthetic operands.
                        result._dtype = dtype
                        result._shape = shape
                        return result
        graph_shape, graph_dtype = None, None
        if evaluation_mode() == "safe":
            graph = parse_expression(expression)
            operands = normalize_operands(operands)
            validate_operands(operands)
            graph_shape = graph.infer_shape(operands)
            graph_dtype = graph.infer_dtype(operands)
            binding = graph.bind_root_reduction(operands)
            if binding is not None:
                normalized, root_shape, graph_dtype = binding
                graph_shape = root_shape if root_shape is not None else graph_shape
                expression = normalized or expression
        expression = convert_to_slice(expression)
        chunks, blocks = None, None
        if guess:
            # The expression has been validated, so we can evaluate it
            # in guessing mode to avoid computing reductions
            # Extract possible numpy scalars
            _expression, local_vars = extract_numpy_scalars(expression)
            _operands = operands | local_vars
            # Check that operands are proper Operands, LazyArray or scalars; if not, convert to NDArray objects
            for op, val in _operands.items():
                if not (isinstance(val, blosc2.Operand | np.ndarray) or np.isscalar(val)):
                    _operands[op] = blosc2.SimpleProxy(val)
            # for scalars just return value (internally converts to () if necessary)
            opshapes = {k: v if not hasattr(v, "shape") else v.shape for k, v in _operands.items()}
            _shape = graph_shape if graph_shape is not None else infer_shape(_expression, opshapes)
            # substitutes with dummy operands (cheap for reductions) and
            # defaults to blosc2 functions (cheap for constructors)
            if graph_shape is not None and graph_dtype is not None:
                # Data-free graph rules supplied metadata. Do not
                # execute that reduction on all-one dummies (ddof may exceed
                # their size even when the real input is perfectly valid).
                new_expr = np.empty((), dtype=graph_dtype)
            else:
                # Handle slices before dummy evaluation: a[10] cannot index a
                # synthetic array of shape (1, 1).
                desliced_expr, desliced_ops = extract_and_replace_slices(_expression, _operands)
                new_expr = _numpy_eval_expr(desliced_expr, desliced_ops, prefer_blosc=True)
            _dtype = (
                graph_dtype
                if graph_dtype is not None
                else (new_expr.dtype if hasattr(new_expr, "dtype") else np.dtype(type(new_expr)))
            )
            if isinstance(new_expr, blosc2.LazyExpr):
                # DO NOT restore the original expression and operands
                # Instead rebase operands and restore only constructors
                expression_, operands_ = conserve_functions(
                    _expression, _operands, new_expr.operands | local_vars
                )
            elif _shape == () and not _operands:  # passed scalars
                expression_ = "o0"
                operands_ = {"o0": evaluate_chunk(_expression)}
            else:
                # An immediate evaluation happened
                # (e.g. all operands are numpy arrays or constructors)
                # or passed "a", "a[:10]", 'sum(a)'
                expression_, operands_ = conserve_functions(_expression, _operands, local_vars)
                if hasattr(new_expr, "chunks") and new_expr.chunks != (1,) * len(_shape):
                    # for constructors with chunks in kwargs, chunks will be specified
                    # for general expression new_expr is just with dummy scalar variables (so ignore)
                    chunks = new_expr.chunks
                    blocks = new_expr.blocks
            new_expr = cls(None)
            new_expr._evaluation = evaluation_mode()
            new_expr.expression = f"({expression_})"  # force parenthesis
            new_expr.operands = operands_
            new_expr.expression_tosave = expression
            new_expr.operands_tosave = operands
            # Cache the dtype and shape (should be immutable)
            new_expr._dtype = _dtype
            new_expr._shape = _shape
            if chunks is not None and blocks is not None:
                new_expr._chunks, new_expr._blocks = chunks, blocks
        else:
            # Create a new LazyExpr object
            new_expr = cls(None)
            new_expr.expression = expression
            new_expr.operands = operands
        if out is not None:
            new_expr._output = out
        if where is not None:
            new_expr._where_args = where
        new_expr._eval_kwargs = eval_kwargs
        new_expr._evaluation = evaluation_mode()
        if evaluation_mode() == "safe":
            record_expression_metadata(new_expr)
        return new_expr


def _align_dsl_operand_grids(inputs):
    """Put every NDArray operand of a Menudet kernel on a single chunks/blocks grid.

    Blocks are sized in bytes, so same-shaped operands of different itemsize get
    different grids by default (float32 vs int64 over 1M elements: blocks of
    31250 vs 15625 elements).  miniexpr needs one common grid, and a DSL kernel
    has no slow path to fall back on, so evaluation would fail outright with a
    confusing "slicing is not supported" error.  Copy the odd operands onto the
    grid of the widest dtype: its blocks hold the fewest elements, so every
    operand still fits within the cache budget the heuristic aimed at.

    The copies happen once, at construction, and only when the grids actually
    disagree -- whether they do depends on the array size and on the platform's
    cache detection, which is why this used to fail only on some CI runners.
    """
    nd = [x for x in inputs if isinstance(x, blosc2.NDArray) and x.ndim > 0]
    if len(nd) < 2 or len({(x.shape, x.chunks, x.blocks) for x in nd}) < 2:
        return inputs
    ref = max(nd, key=lambda x: x.dtype.itemsize)
    aligned = []
    for x in inputs:
        misaligned = (
            isinstance(x, blosc2.NDArray)
            and x.ndim > 0
            and x.shape == ref.shape
            and (x.chunks, x.blocks) != (ref.chunks, ref.blocks)
        )
        aligned.append(x.copy(chunks=ref.chunks, blocks=ref.blocks) if misaligned else x)
    return aligned


def _dsl_kernel_string_dtype(func, inputs):
    """Output dtype of a string-returning Menudet kernel, per miniexpr.

    Returns None when the kernel is not string-valued or miniexpr cannot type
    it, leaving the existing dtype handling in charge.
    """
    try:
        params = list(getattr(func, "input_names", None) or [])
        if not params or len(params) != len(inputs):
            return None
        dtypes = {}
        for name, arr in zip(params, inputs, strict=True):
            dt = getattr(arr, "dtype", None)
            if dt is None:
                return None
            dtypes[name] = dt
        if not any(np.dtype(dt).kind in "US" for dt in dtypes.values()):
            return None

        from blosc2 import blosc2_ext

        out = blosc2_ext.me_output_dtype(func.dsl_source, dtypes)
    except Exception:
        return None
    if out is None or np.dtype(out).kind not in "US":
        return None
    return np.dtype(out)


def _guard_utf8_udf_inputs(inputs) -> None:
    """Reject variable-length utf8 operands in a UDF, naming the conversion."""
    from blosc2._utf8_array import UTF8Array, utf8_compute_error

    for operand in inputs or ():
        raw = getattr(operand, "raw", operand)  # a CTable Column exposes its container here
        if not isinstance(raw, UTF8Array):
            continue
        name = getattr(operand, "_col_name", None)
        source = f"t[{name!r}]" if name else "arr"
        raise NotImplementedError(
            utf8_compute_error(
                (
                    f"Column {name!r} is a variable-length utf8 column and cannot be a UDF operand."
                    if name
                    else "A variable-length UTF8Array cannot be a UDF operand."
                ),
                source=source,
                compute="blosc2.lazyudf(kernel, (fixed,)).compute()[:]",
                assignable=name is not None,
            )
        )


class LazyUDF(LazyArray):
    def __init__(
        self, func, inputs, dtype, shape=None, chunked_eval=True, jit=None, jit_backend=None, **kwargs
    ):
        # A utf8 operand only duck-types as an array: convert_inputs() would wrap
        # it in a SimpleProxy widened to a fixed <Un, and the output container is
        # then allocated from a StringDType the NDArray dtype round-trip cannot
        # parse -- an obscure "malformed node" ValueError, on every evaluation,
        # whatever the kernel returns.  Refuse it here, where the operand is
        # still recognizable, and name the conversion instead.
        _guard_utf8_udf_inputs(inputs)
        # After this, all the inputs should be np.ndarray or NDArray objects
        self.inputs = convert_inputs(inputs)
        if isinstance(func, DSLKernel):
            self.inputs = _align_dsl_operand_grids(self.inputs)
        # Get res shape
        if shape is None:
            self._shape = compute_broadcast_shape(self.inputs)
            if self._shape is None:
                raise ValueError(
                    "If all inputs are scalars, pass a `shape` argument to indicate the output shape"
                )
        else:
            self._shape = shape

        if dtype is None and isinstance(func, DSLKernel) and func.dsl_source is not None:
            # A string-returning DSL kernel needs miniexpr's own width inference:
            # the output container is allocated before evaluation, and nothing on
            # the Python side can predict a concat/case-mapping width.
            dtype = _dsl_kernel_string_dtype(func, self.inputs) or dtype

        self.kwargs = kwargs
        self.kwargs["dtype"] = dtype
        self.kwargs["shape"] = self._shape
        self.kwargs["jit"] = jit
        self.kwargs["jit_backend"] = jit_backend
        in_place = kwargs.get("in_place", False)
        self.kwargs["in_place"] = in_place
        self._dtype = dtype
        self.func = func
        if isinstance(self.func, DSLKernel) and self.func.dsl_error is not None:
            udf_name = getattr(self.func.func, "__name__", self.func.__name__)
            raise DSLSyntaxError(f"Invalid DSL kernel '{udf_name}'.\n{self.func.dsl_error}") from None

        # Prepare internal array for __getitem__
        # Deep copy the kwargs to avoid modifying them
        kwargs_getitem = copy.deepcopy(self.kwargs)
        # Cannot use multithreading when applying a postfilter, dparams['nthreads'] ignored
        dparams = kwargs_getitem.get("dparams", {})
        if isinstance(dparams, dict):
            dparams["nthreads"] = 1
        else:
            raise TypeError("dparams should be a dictionary")
        kwargs_getitem["dparams"] = dparams

        if isinstance(self.func, DSLKernel) and self.func.input_names:
            # DSL kernels are using input names that are extracted from params as a list,
            # and we need to use them for matching variables in miniexpr
            # (instead of the 'o{%d}' notation).
            names = self.func.input_names
            if len(names) != len(self.inputs):
                # Otherwise this surfaces as a bare "zip() argument 2 is longer
                # than argument 1", which names neither the kernel nor the counts.
                udf_name = getattr(self.func.func, "__name__", self.func.__name__)
                raise ValueError(
                    f"DSL kernel {udf_name!r} takes {len(names)} operand(s) "
                    f"({', '.join(names)}), but {len(self.inputs)} were passed."
                )
            self.inputs_dict = dict(zip(names, self.inputs, strict=True))
        else:
            self.inputs_dict = {f"o{i}": obj for i, obj in enumerate(self.inputs)}

    @property
    def dtype(self):
        return self._dtype

    @property
    def nbytes(self):
        return math.prod(self.shape) * np.dtype(self.dtype).itemsize

    @property
    def ndim(self) -> int:
        return len(self.shape)

    @property
    def shape(self):
        return self._shape

    @property
    def info(self):
        return InfoReporter(self)

    @property
    def info_items(self):
        inputs = {}
        for key, value in self.inputs_dict.items():
            if isinstance(value, blosc2.Array):
                inputs[key] = f"<{value.__class__.__name__}> {value.shape} {value.dtype}"
            else:
                inputs[key] = str(value)
        return [
            ("type", f"{self.__class__.__name__}"),
            ("inputs", inputs),
            ("shape", self.shape),
            ("dtype", self.dtype),
        ]

    @property
    def chunks(self):
        if hasattr(self, "_chunks"):
            return self._chunks
        if not self.inputs_dict:
            req_chunks = self.kwargs.get("chunks")
            req_blocks = self.kwargs.get("blocks")
            self._chunks, self._blocks = compute_chunks_blocks(
                self.shape, req_chunks, req_blocks, dtype=self.dtype
            )
            return self._chunks
        shape, self._chunks, self._blocks, fast_path = validate_inputs(
            self.inputs_dict, getattr(self, "_out", None)
        )
        if not hasattr(self, "_shape"):
            self._shape = shape
        if self._shape != shape:  # validate inputs only works for elementwise funcs so returned shape might
            fast_path = False  # be incompatible with true output shape
        if not fast_path:
            # Not using the fast path, so we need to compute the chunks/blocks automatically
            self._chunks, self._blocks = compute_chunks_blocks(self.shape, None, None, dtype=self.dtype)
        return self._chunks

    @property
    def blocks(self):
        if hasattr(self, "_blocks"):
            return self._blocks
        if not self.inputs_dict:
            req_chunks = self.kwargs.get("chunks")
            req_blocks = self.kwargs.get("blocks")
            self._chunks, self._blocks = compute_chunks_blocks(
                self.shape, req_chunks, req_blocks, dtype=self.dtype
            )
            return self._blocks
        shape, self._chunks, self._blocks, fast_path = validate_inputs(
            self.inputs_dict, getattr(self, "_out", None)
        )
        if not hasattr(self, "_shape"):
            self._shape = shape
        if self._shape != shape:  # validate inputs only works for elementwise funcs so returned shape might
            fast_path = False  # be incompatible with true output shape
        if not fast_path:
            # Not using the fast path, so we need to compute the chunks/blocks automatically
            self._chunks, self._blocks = compute_chunks_blocks(self.shape, None, None, dtype=self.dtype)
        return self._blocks

    # TODO: argsort and sort are repeated in LazyExpr; refactor
    def argsort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        if self.dtype.fields is None:
            raise NotImplementedError("argsort() can only be used with structured arrays")
        if not hasattr(self, "_where_args") or len(self._where_args) != 1:
            raise ValueError("argsort() can only be used with conditions")
        # Build a new lazy array
        lazy_expr = copy.copy(self)
        # ... and assign the new attributes
        lazy_expr._indices = True
        if order:
            lazy_expr._order = order
        # dtype changes to int64
        lazy_expr._dtype = np.dtype(np.int64)
        return lazy_expr

    def sort(self, order: str | list[str] | None = None) -> blosc2.LazyArray:
        if self.dtype.fields is None:
            raise NotImplementedError("sort() can only be used with structured arrays")
        if not hasattr(self, "_where_args") or len(self._where_args) != 1:
            raise ValueError("sort() can only be used with conditions")
        # Build a new lazy expression
        lazy_expr = copy.copy(self)
        # ... and assign the new attributes
        if order:
            lazy_expr._order = order
        return lazy_expr

    def compute(
        self,
        item=(),
        fp_accuracy: blosc2.FPAccuracy | None = None,
        jit=None,
        jit_backend=None,
        **kwargs,
    ):
        # Get kwargs
        if kwargs is None:
            kwargs = {}
        # Do copy to avoid modifying the original parameters
        aux_kwargs = copy.deepcopy(self.kwargs)

        # Update is not recursive
        aux_cparams = aux_kwargs.get("cparams", {})
        if isinstance(aux_cparams, blosc2.CParams):
            # Convert to dictionary
            aux_cparams = asdict(aux_cparams)
        cparams = kwargs.get("cparams", {})
        if isinstance(cparams, blosc2.CParams):
            # Convert to dictionary
            cparams = asdict(cparams)
        aux_cparams.update(cparams)
        if aux_cparams:
            # Only when something was actually asked for: passing an empty dict
            # still materializes CParams' defaults, whose all-zero filters_meta
            # overrides the dtype-aware shuffle width (4 for <U, the UCS4 code
            # unit) that the container would otherwise pick for itself.
            aux_kwargs["cparams"] = aux_cparams

        aux_dparams = aux_kwargs.get("dparams", {})
        if isinstance(aux_dparams, blosc2.DParams):
            # Convert to dictionary
            aux_dparams = asdict(aux_dparams)
        dparams = kwargs.get("dparams", {})
        if isinstance(dparams, blosc2.DParams):
            # Convert to dictionary
            dparams = asdict(dparams)
        aux_dparams.update(dparams)
        aux_kwargs["dparams"] = aux_dparams

        _ = kwargs.pop("cparams", None)
        _ = kwargs.pop("dparams", None)
        if jit is not None:
            aux_kwargs["jit"] = jit
        if jit_backend is not None:
            aux_kwargs["jit_backend"] = jit_backend
        if fp_accuracy is not None:
            aux_kwargs["fp_accuracy"] = fp_accuracy
        urlpath = kwargs.get("urlpath")
        if urlpath is not None and urlpath == aux_kwargs.get(
            "urlpath",
        ):
            raise ValueError("Cannot use the same urlpath for LazyArray and eval NDArray")
        _ = aux_kwargs.pop("urlpath", None)

        if "out" in kwargs:  # use provided out preferentially
            aux_kwargs["_output"] = kwargs.pop("out")
        elif hasattr(self, "_output"):
            aux_kwargs["_output"] = self._output
        aux_kwargs.update(kwargs)

        # aux_kwargs includes self.shape and self.dtype
        from .dsl_execution import evaluate_dsl_udf

        handled, result = evaluate_dsl_udf(self, item, getitem=False, options=aux_kwargs)
        if handled:
            return result
        return chunked_eval(self.func, self.inputs_dict, item, _getitem=False, **aux_kwargs)

    def __getitem__(self, item):
        from .dsl_execution import evaluate_dsl_udf

        handled, result = evaluate_dsl_udf(self, item, getitem=True, options=self.kwargs)
        if handled:
            return result
        result = chunked_eval(self.func, self.inputs_dict, item, _getitem=True, **self.kwargs)
        return _drop_indexed_axes(result, self.shape, item)

    def save(self, urlpath=None, **kwargs):
        """
        Save the :ref:`LazyUDF` on disk.

        Parameters
        ----------
        urlpath: str
            The path to the file where the LazyUDF will be stored.
        kwargs: Any, optional
            Keyword arguments that are supported by the :func:`empty` constructor.

        Returns
        -------
        out: None

        Notes
        -----
        * All operands must be :ref:`NDArray` or :ref:`C2Array` objects stored on
          disk or a remote server (i.e. they must have a ``urlpath``).
        * Internally normalized source kernels validate as Menudet
          0.1 before saving. Python UDFs and noncompliant kernels reject before
          writing. Block-scalar kernels require the explicit Menudet API.
          Historical source-backed files are unsupported under all loading
          policies; materialize them in a previous release before upgrading.
        """
        if urlpath is None:
            raise ValueError("To save a LazyArray you must provide an urlpath")

        from blosc2.menudet_lazy import menudet_from_lazyudf

        menudet_result = menudet_from_lazyudf(self)
        menudet_result.save(urlpath, **kwargs)
        self.array, self.schunk = menudet_result.array, menudet_result.schunk

    def to_cframe(self) -> bytes:
        return self._to_b2object_carrier().to_cframe()

    def _to_b2object_carrier(self, **kwargs):
        payload = encode_b2object_payload(self)
        if payload is None:
            raise TypeError("Persistent Blosc2 object payload is not supported for this LazyUDF")

        carrier_urlpath = kwargs.get("urlpath")
        carrier_parent = Path(carrier_urlpath).parent if carrier_urlpath is not None else None
        for operand_payload in payload["operands"].values():
            if operand_payload["kind"] not in {"urlpath", "dictstore_key"}:
                continue
            operand_urlpath = Path(operand_payload["urlpath"])
            if carrier_parent is not None and not operand_urlpath.is_absolute():
                ref_urlpath = operand_urlpath.as_posix()
            elif carrier_parent is not None:
                try:
                    ref_urlpath = operand_urlpath.relative_to(carrier_parent).as_posix()
                except ValueError:
                    ref_urlpath = operand_urlpath.as_posix()
            else:
                ref_urlpath = operand_urlpath.as_posix()
            operand_payload["urlpath"] = ref_urlpath

        from blosc2.msgpack_utils import msgpack_packb

        msgpack_packb(payload)
        msgpack_packb(self._get_user_vlmeta())
        array = make_b2object_carrier(
            "menudet",
            self.shape,
            self.dtype,
            chunks=self.chunks,
            blocks=self.blocks,
            **kwargs,
        )
        write_b2object_payload(array, payload)
        write_b2object_user_vlmeta(array, self._get_user_vlmeta())
        return array


def _numpy_eval_expr(expression, operands, prefer_blosc=False):
    npops = {
        key: np.ones(np.ones(len(value.shape), dtype=int), dtype=value.dtype)
        if hasattr(value, "shape")
        else value
        for key, value in operands.items()
    }
    if prefer_blosc:
        # convert blosc arrays to small dummies
        ops = {
            key: blosc2.ones((1,) * len(value.shape), dtype=value.dtype)
            if hasattr(value, "chunks")
            else value  # some of these could be numpy arrays
            for key, value in operands.items()
        }
        # change numpy arrays
        ops = {
            key: np.ones((1,) * len(value.shape), dtype=value.dtype)
            if isinstance(value, np.ndarray)
            else value
            for key, value in ops.items()
        }
    else:  # wasm pathway assumes numpy arrs
        ops = npops

    # Create a globals dict with blosc2 version of functions preferentially
    # (default to numpy func if not implemented in blosc2)
    if prefer_blosc:
        _globals = get_expr_globals(expression)
        _globals |= dtype_symbols
        if all(type(value) is np.ndarray or np.isscalar(value) for value in ops.values()):
            # Blosc2's bare where/copy expect lazy or stored receivers, while
            # these synthetic operands represent ordinary resident NumPy values.
            _globals.update(where=np.where, copy=np.copy)
    else:
        _globals = safe_numpy_globals
    try:
        # Dummy values are only for shape/dtype inference. Their artificial
        # domain boundaries must not emit diagnostics for the actual operands.
        with np.errstate(all="ignore"):
            _out = _numpy_eval_datetime_aware(expression, _globals, ops)
    except RuntimeWarning:
        # Sometimes, numpy gets a RuntimeWarning when evaluating expressions
        # with synthetic operands (1's). Try the native/NumPy chunk evaluator.
        # about this.
        ops = npops if blosc2.IS_WASM else ops
        _out = evaluate_chunk(expression, local_dict=ops)
    return _out


def lazyudf(
    func: Callable[[tuple, np.ndarray, tuple[int]], None],
    inputs: Sequence[Any] | None,
    dtype: np.dtype | None = None,
    shape: tuple | list | None = None,
    chunked_eval: bool = True,
    jit: bool | None = None,
    jit_backend: str | None = None,
    **kwargs: Any,
) -> LazyUDF:
    """
    Get a LazyUDF from a python user-defined function.

    Parameters
    ----------
    func: Python function
        The user-defined function to apply to each block. This function will
        always receive the following parameters:

        - `inputs_tuple`: A tuple containing the corresponding slice for the block of each input
          in :paramref:`inputs`.
        - `output`: The buffer to be filled as a multidimensional numpy.ndarray.
        - `offset`: The multidimensional offset corresponding to the start of the block
          being computed. Example signature::

            def myudf(inputs_tuple, output, offset):
                x, y = inputs_tuple
                ...
                output[:] = result
    inputs: Sequence[Any] or None
        The sequence of inputs. Besides objects compliant with the blosc2.Array protocol,
        any other object is supported too, and it will be passed as-is to the
        user-defined function. If not needed, this can be empty, but `shape` must
        be provided.
    dtype: np.dtype
        The resulting ndarray dtype in NumPy format. Required.
    shape: tuple, optional
        The shape of the resulting array. If None, the shape will be guessed from inputs.
    chunked_eval: bool, optional
        Whether to evaluate the function in chunks or not (blocks).
    jit: bool or None, optional
        JIT policy for miniexpr-backed execution:
        ``None`` inherits configured defaults (built-in DSL defaults try JIT),
        ``True`` prefers JIT, ``False`` disables JIT.
    jit_backend: {"tcc", "cc", "js"} or None, optional
        JIT backend selection. ``None`` uses backend defaults (miniexpr "tcc"), except under
        WebAssembly where — unless ``jit=False`` — it *prefers* ``"js"`` for transpilable
        float DSL kernels and falls back to miniexpr otherwise (``jit=True`` prefers ``"js"``
        too, since it is JIT-compiled by the JS engine). ``"tcc"`` selects bundled
        libtcc without a disk cache, ``"cc"`` selects an installed C compiler with
        persistent caching, and ``"js"`` is reserved for internal source-kernel
        transpilation to JavaScript (browser/Pyodide only; raises elsewhere). Native JIT requests
        remain best effort and use the interpreter if compilation or loading fails.
        See :ref:`JITOptions` for requirements, diagnostics, and environment settings.
    kwargs: Any, optional
        Keyword arguments that are supported by the :func:`empty` constructor.
        These arguments will be used by the :meth:`LazyArray.__getitem__` and
        :meth:`LazyArray.compute` methods. The
        last one will ignore the `urlpath` parameter passed in this function.
        In addition, one may provide ``in_place``, a bool (default False), which indicates whether
        the function should modify the output directly (rather than chunks of the output, which
        are later written to output). Example::

            def inplace_udf(inputs_tuple, output, offset):
                x, y = inputs_tuple
                ...
                out[3] += 1

    Returns
    -------
    out: :ref:`LazyUDF`
        A :ref:`LazyUDF` is returned.

    Notes
    -----
    Menudet functions and kernels are not accepted by this constructor. Call a
    decorated function as ``function(*inputs)``, or bind a specialized kernel
    with ``kernel.lazy({name: operand, ...})``. See
    https://blosc.org/python-blosc2/guides/migrating_to_menudet.html.

    Examples
    --------
    >>> import blosc2
    >>> import numpy as np
    >>> dtype = np.float64
    >>> shape = [3, 3]
    >>> size = shape[0] * shape[1]
    >>> a = np.linspace(0, 10, num=size, dtype=dtype).reshape(shape)
    >>> b = np.linspace(10, 20, num=size, dtype=dtype).reshape(shape)
    >>> a1 = blosc2.asarray(a)
    >>> b1 = blosc2.asarray(b)
    >>> # Define a user-defined function that will be applied to each block of data
    >>> def my_function(inputs_tuple, output, offset):
    >>>     a, b = inputs_tuple
    >>>     output[:] = a + b
    >>> # Create a LazyUDF object using the user-defined function
    >>> lazy_udf = blosc2.lazyudf(my_function, [a1, b1], dtype)
    >>> type(lazy_udf)
    <class 'blosc2.lazyexpr.LazyUDF'>
    >>> f"Result of LazyUDF evaluation: {lazy_udf[:]}"
    Result of LazyUDF evaluation:
            [[10.  12.5 15. ]
            [17.5 20.  22.5]
            [25.  27.5 30. ]]
    """
    if isinstance(func, blosc2.MenudetFunction):
        raise TypeError(
            "lazyudf() does not accept a MenudetFunction; call function(*inputs) directly. "
            "See https://blosc.org/python-blosc2/guides/migrating_to_menudet.html"
        )
    if isinstance(func, blosc2.MenudetKernel):
        raise TypeError(
            "lazyudf() does not accept a MenudetKernel; use kernel.lazy({name: operand, ...}). "
            "See https://blosc.org/python-blosc2/guides/migrating_to_menudet.html"
        )
    if isinstance(func, DSLKernel) and func.dsl_error is not None:
        udf_name = getattr(func.func, "__name__", func.__name__)
        raise DSLSyntaxError(f"Invalid DSL kernel '{udf_name}'.\n{func.dsl_error}") from None
    # Ahead of the dtype inference below, which a StringDType operand fails with
    # a bare NumPy promotion error naming neither the column nor the way out.
    _guard_utf8_udf_inputs(inputs)
    if dtype is None:
        if isinstance(func, DSLKernel):
            dep_dtypes = [arr.dtype for arr in (inputs or []) if hasattr(arr, "dtype")]
            if not dep_dtypes:
                raise TypeError(
                    "Cannot infer dtype for DSL kernel with no array inputs; pass dtype= explicitly."
                )
            # A string-returning kernel is not a promotion of its inputs: only
            # miniexpr knows the concat/case-mapping width bound.
            dtype = _dsl_kernel_string_dtype(func, inputs) or np.result_type(*dep_dtypes)
        else:
            raise TypeError("dtype is required for non-DSL UDFs.")
    return LazyUDF(func, inputs, dtype, shape, chunked_eval, jit, jit_backend, **kwargs)


def seek_operands(names, local_dict=None, global_dict=None, _frame_depth: int = 2):
    """
    Get the arguments based on the names.
    """
    call_frame = sys._getframe(_frame_depth)

    clear_local_dict = False
    if local_dict is None:
        local_dict = call_frame.f_locals
        clear_local_dict = True
    try:
        frame_globals = call_frame.f_globals
        if global_dict is None:
            global_dict = frame_globals

        # If `call_frame` is the top frame of the interpreter we can't clear its
        # `local_dict`, because it is actually the `global_dict`.
        clear_local_dict = clear_local_dict and frame_globals is not local_dict

        op_dict = {}
        for name in names:
            try:
                a = local_dict[name]
            except KeyError:
                a = global_dict[name]
            op_dict[name] = a
    finally:
        # If we generated local_dict via an explicit reference to f_locals,
        # clear the dict to prevent creating extra ref counts in the caller's scope
        if clear_local_dict and hasattr(local_dict, "clear"):
            local_dict.clear()

    return op_dict


def _resolve_eval_kwargs(eval_kwargs, ne_args):
    """Normalize the public legacy option name without changing caller frames."""
    if ne_args is None:
        return eval_kwargs
    if eval_kwargs is not None:
        raise TypeError("Pass only one of 'eval_kwargs' and the legacy 'ne_args' alias")
    return ne_args


def lazyexpr(
    expression: str | bytes | LazyArray | blosc2.NDArray,
    operands: dict | None = None,
    out: blosc2.Array = None,
    where: tuple | list | None = None,
    local_dict: dict | None = None,
    global_dict: dict | None = None,
    eval_kwargs: dict | None = None,
    _frame_depth: int = 2,
    *,
    evaluation: str | None = None,
    ne_args: dict | None = None,
) -> LazyExpr:
    """
    Get a LazyExpr from an expression.

    Parameters
    ----------
    expression: str or bytes or LazyExpr or NDArray
        The expression to evaluate, using supported numerical and array operations.
        If a LazyExpr is passed, the expression will be
        updated with the new operands.
    operands: dict[blosc2.Array], optional
        The dictionary with operands. Supported values are Python scalars,
        or any instance that is blosc2.Array compliant.
        If None, the operands will be seeked in the local and global dictionaries.
    out: blosc2.Array, optional
        The output array where the result will be stored. If not provided,
        a new NumPy array will be created and returned.
        Eligible one-dimensional compressed inputs use the miniexpr prefilter
        to write directly into this new NumPy allocation, without storing an
        intermediate Blosc2 result. A supplied NumPy output uses bounded chunk
        scratch instead. Other layouts retain the regular evaluation paths.
    where: tuple, list, optional
        A sequence of arguments for the where clause in the expression.
    local_dict: dict, optional
        The local dictionary to use when looking for operands in the expression.
        If not provided, the local dictionary of the caller will be used.
    global_dict: dict, optional
        The global dictionary to use when looking for operands in the expression.
        If not provided, the global dictionary of the caller will be used.
    eval_kwargs: dict, optional
        Expression evaluation options, validated independently of backend.
    ne_args: dict, optional
        Compatibility alias for ``eval_kwargs``. Do not pass both names.
    _frame_depth: int, optional
        The depth of the frame to use when looking for operands in the expression.
        The default value is 2.


    Returns
    -------
    out: :ref:`LazyExpr`
        A :ref:`LazyExpr` is returned.

    Examples
    --------
    >>> import blosc2
    >>> import numpy as np
    >>> dtype = np.float64
    >>> shape = [3, 3]
    >>> size = shape[0] * shape[1]
    >>> a = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
    >>> b = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
    >>> a1 = blosc2.asarray(a)
    >>> a1[:]
    [[0.    0.625 1.25 ]
    [1.875 2.5   3.125]
    [3.75  4.375 5.   ]]
    >>> b1 = blosc2.asarray(b)
    >>> expr = 'a * b + 2'
    >>> operands = { 'a': a1, 'b': b1 }
    >>> lazy_expr = blosc2.lazyexpr(expr, operands=operands)
    >>> f"Lazy expression created: {lazy_expr}"
    Lazy expression created: a * b + 2
    >>> lazy_expr[:]
    [[ 2.        2.390625  3.5625  ]
    [ 5.515625  8.25     11.765625]
    [16.0625   21.140625 27.      ]]
    """
    eval_kwargs = _resolve_eval_kwargs(eval_kwargs, ne_args)
    if evaluation is not None:
        with expression_evaluation(evaluation):
            return lazyexpr(
                expression,
                operands,
                out,
                where,
                local_dict,
                global_dict,
                eval_kwargs,
                _frame_depth=_frame_depth + 1,
            )
    if isinstance(expression, str) and evaluation_mode() == "safe":
        parse_expression(expression)
    if operands is not None and isinstance(expression, str):
        # A UTF8Array is variable-width, so it cannot be an expression operand.
        # It only duck-types as one: LazyExpr would wrap it in a SimpleProxy,
        # which converts it to a fixed-width <Un NumPy array, and evaluation
        # would land in slices_eval -- correct-looking values down a path that
        # never reaches miniexpr, ignores the span budget, and loses the utf8
        # container.  Route it through the span driver instead.
        from blosc2._utf8_array import UTF8Array, UTF8LazyExpr

        if any(isinstance(v, UTF8Array) for v in operands.values()):
            if out is not None or where is not None:
                raise NotImplementedError(
                    "'out' and 'where' are not supported for expressions over a bare "
                    "UTF8Array; use a CTable column, which supports both."
                )
            return UTF8LazyExpr(expression, operands, eval_kwargs=eval_kwargs)

    if isinstance(expression, LazyExpr):
        if operands is not None:
            expression.operands.update(operands)
        if out is not None:
            expression._output = out
        expression._eval_kwargs = eval_kwargs
        if where is not None:
            where_args = {"_where_x": where[0], "_where_y": where[1]}
            expression._where_args = where_args
        return expression
    elif isinstance(expression, blosc2.NDArray):
        operands = {"o0": expression}
        return LazyExpr._new_expr("o0", operands, guess=False, out=out, where=where, eval_kwargs=eval_kwargs)

    if operands is None:
        # Try to get operands from variables in the stack
        operand_set = get_expr_operands(expression)
        # If no operands are found, raise an error
        if operand_set:
            # Look for operands in the stack
            operands = seek_operands(operand_set, local_dict, global_dict, _frame_depth=_frame_depth)
        else:
            # No operands found in the expression. Maybe a constructor?
            constructor = _has_any_constructor_call(expression)
            if not constructor and parse_expression(expression).names:
                # Approved constant-only numerical expressions are valid too;
                # parsing, rather than Python eval, decides whether to admit them.
                raise ValueError("No operands nor constructors found in the expression")
            # _new_expr will take care of the constructor, but needs an empty dict in operands
            operands = {}

    return LazyExpr._new_expr(
        expression, operands, guess=True, out=out, where=where, eval_kwargs=eval_kwargs
    )


def _reconstruct_lazyudf(expr, lazyarray, operands_dict, array):
    """Recognize the retired source recipe without executing Python."""
    raise blosc2.UnsupportedLegacyRecipeError()


def open_lazyarray(array):
    from blosc2.deserialization import DeserializeMode, get_deserialize
    from blosc2.exceptions import UnsafeDeserializationError

    value = array.schunk.meta["LazyArray"]
    if value == LazyArrayEnum.UDF.value:
        raise blosc2.UnsupportedLegacyRecipeError()
    policy = get_deserialize(array)
    if policy is not DeserializeMode.FULL:
        raise UnsafeDeserializationError("legacy LazyArray")
    lazyarray = array.schunk.vlmeta["_LazyArray"]
    if value == LazyArrayEnum.Expr.value:
        expr = lazyarray["expression"]
    else:
        raise ValueError("Argument `array` is not LazyExpr or LazyUDF instance.")

    operands = lazyarray["operands"]
    parent_path = Path(array.schunk.urlpath).parent
    operands_dict = {}
    missing_ops = {}
    for key, v in operands.items():
        if isinstance(v, str):
            v = parent_path / v
            try:
                op = blosc2.open(v, mode="r", deserialize=policy)
            except FileNotFoundError:
                missing_ops[key] = v
            else:
                operands_dict[key] = op
        elif isinstance(v, dict):
            # C2Array
            operands_dict[key] = blosc2.C2Array(
                pathlib.Path(v["path"]).as_posix(),
                urlbase=v["urlbase"],
            )
        else:
            raise TypeError("Error when retrieving the operands")

    if missing_ops:
        exc = exceptions.MissingOperands(expr, missing_ops)
        exc.expr = expr
        exc.missing_ops = missing_ops
        raise exc

    # LazyExpr
    if value == LazyArrayEnum.Expr.value:
        new_expr = LazyExpr._new_expr(expr, operands_dict, guess=True, out=None, where=None)

    # Make the array info available for the user (only available when opened from disk)
    new_expr.array = array
    # We want to expose schunk too, so that .info() can be used on the LazyArray
    new_expr.schunk = array.schunk
    new_expr._set_user_vlmeta(read_b2object_user_vlmeta(array), sync=False)
    return new_expr


# NumExpr-style convenience interface with backend-independent contracts.
@dataclass(frozen=True, slots=True)
class _EvaluateRecipe:
    """Operand-free construction metadata and optional immutable resident schedule."""

    expression: str
    bindings: tuple
    dtype: np.dtype
    shape: tuple
    chunks: tuple | None
    blocks: tuple | None
    resident: tuple | None = None


_evaluate_recipe_cache = OrderedDict()
_evaluate_recipe_lock = threading.Lock()
_EVALUATE_RECIPE_CACHE_SIZE = 128


@lru_cache(maxsize=128)
def _evaluate_recipe_names(expression):
    """Restrict caching to reviewed elementwise syntax with literal constants."""
    if type(expression) is not str:
        return None
    names = arithmetic_names(expression)
    if names is not None:
        return names or None
    try:
        graph = parse_expression(expression)
        if graph.arithmetic:
            return tuple(sorted(graph.names)) or None
        tree, nodes = expression_syntax(expression)
    except (exceptions.UnsafeDeserializationError, ValueError, SyntaxError):
        return None
    allowed = (
        ast.Expression,
        ast.Name,
        ast.Load,
        ast.Constant,
        ast.BinOp,
        ast.UnaryOp,
        ast.Compare,
        ast.Add,
        ast.Sub,
        ast.Mult,
        ast.Div,
        ast.FloorDiv,
        ast.Mod,
        ast.Pow,
        ast.LShift,
        ast.RShift,
        ast.UAdd,
        ast.USub,
        ast.Invert,
        ast.BitAnd,
        ast.BitOr,
        ast.BitXor,
        ast.Eq,
        ast.NotEq,
        ast.Lt,
        ast.LtE,
        ast.Gt,
        ast.GtE,
    )
    from .native_graph import NATIVE_ELEMENTWISE_CALLS, REDUCERS

    calls = {
        **NATIVE_ELEMENTWISE_CALLS,
        **dict.fromkeys(REDUCERS, 1),
        "complex": 2,
        "ones_like": 1,
        "contains": 2,
    }
    for node in nodes:
        if isinstance(node, ast.Call):
            if (
                not isinstance(node.func, ast.Name)
                or node.func.id not in calls
                or node.keywords
                or len(node.args) != calls[node.func.id]
            ):
                return None
        elif not isinstance(node, allowed):
            return None
    return tuple(sorted(graph.names)) or None


def _prepare_cached_evaluate(expression, local_dict, global_dict, optimization="aggressive"):
    if type(expression) is not str or len(expression) > 65536:
        return None
    names = _evaluate_recipe_names(expression)
    if names is None:
        return None
    # seek_operands -> this helper -> evaluate -> user; preserve evaluate's
    # ordinary caller-local/global resolution, including explicitly supplied dicts.
    inputs = seek_operands(names, local_dict, global_dict, _frame_depth=3)
    if any(
        type(value) not in (np.ndarray, blosc2.NDArray)
        or value.dtype.kind not in "biufcS"
        or not value.dtype.isnative
        or value.dtype.metadata is not None
        for value in inputs.values()
    ) or len({id(value) for value in inputs.values()}) != len(inputs):
        # Avoid ambiguous alias-to-name mappings and scalar capture semantics.
        return lazyexpr(expression, operands=inputs, eval_kwargs=None)
    validate_operands(inputs)
    mode = evaluation_mode()
    signature = tuple(
        (
            name,
            type(value),
            value.dtype,
            tuple(value.shape),
            value.chunks if type(value) is blosc2.NDArray else None,
            value.blocks if type(value) is blosc2.NDArray else None,
        )
        for name, value in inputs.items()
    )
    key = (expression, signature, mode, optimization, blosc2.jit_config.execution_options()["math_backend"])
    with _evaluate_recipe_lock:
        recipe = _evaluate_recipe_cache.get(key)
        if recipe is not None:
            _evaluate_recipe_cache.move_to_end(key)
    from .native_graph import prepare_resident

    policy = blosc2.jit_config.execution_options()
    native_jit, native_backend = _jit_from_env(policy["jit"], policy["jit_backend"])
    resident = (
        prepare_resident(
            expression,
            inputs,
            jit=native_jit,
            jit_backend=native_backend,
            cached=recipe.resident if recipe is not None else None,
            optimization=optimization,
        )
        if not _NUMPY_VALUE_PROMOTION and policy["fp_accuracy"] == blosc2.FPAccuracy.DEFAULT
        else None
    )
    if resident is not None and (recipe is None or resident is not recipe.resident):
        # Division, comparisons and mixed inputs can produce a different dtype from every operand.
        info = resident[2].info()
        recipe = _EvaluateRecipe(
            expression,
            tuple((name, name) for name in inputs),
            info["dtype"],
            info["shape"],
            None,
            None,
            resident,
        )
        with _evaluate_recipe_lock:
            _evaluate_recipe_cache[key] = recipe
            _evaluate_recipe_cache.move_to_end(key)
            while len(_evaluate_recipe_cache) > _EVALUATE_RECIPE_CACHE_SIZE:
                _evaluate_recipe_cache.popitem(last=False)
    elif recipe is None:
        expr = lazyexpr(expression, operands=inputs, eval_kwargs=None)
        # Match constructor-renamed bindings to original names without retaining
        # arrays in either the cache key or recipe. Aliased inputs were excluded.
        source_names = {id(value): name for name, value in inputs.items()}
        if any(id(value) not in source_names for value in expr.operands.values()):
            return expr
        recipe = _EvaluateRecipe(
            expr.expression,
            tuple((name, source_names[id(value)]) for name, value in expr.operands.items()),
            np.dtype(expr.dtype),
            tuple(expr.shape),
            tuple(expr._chunks) if hasattr(expr, "_chunks") else None,
            tuple(expr._blocks) if hasattr(expr, "_blocks") else None,
        )
        with _evaluate_recipe_lock:
            _evaluate_recipe_cache[key] = recipe
            _evaluate_recipe_cache.move_to_end(key)
            while len(_evaluate_recipe_cache) > _EVALUATE_RECIPE_CACHE_SIZE:
                _evaluate_recipe_cache.popitem(last=False)
        return expr
    if resident is not None:
        return resident, inputs
    expr = LazyExpr(None)
    expr.expression = recipe.expression
    expr.operands = {name: inputs[source] for name, source in recipe.bindings}
    expr.expression_tosave = expression
    expr.operands_tosave = dict(inputs)
    expr._dtype, expr._shape = recipe.dtype, recipe.shape
    if recipe.chunks is not None:
        expr._chunks, expr._blocks = recipe.chunks, recipe.blocks
    expr._eval_kwargs = None
    expr._evaluation = mode
    if mode == "safe":
        record_expression_metadata(expr)
    return expr


def validate_evaluate_options(options):
    """Validate public options before choosing a numerical backend."""
    unknown = options.keys() - {"order", "casting", "optimization"}
    if unknown:
        raise ValueError(f"Unknown keyword argument {sorted(unknown)[0]!r}")
    order = options.get("order", "K")
    if not isinstance(order, str) or order.upper() not in {"C", "F", "A", "K"}:
        raise ValueError("order must be one of 'C', 'F', 'A', or 'K'")
    if options.get("optimization", "aggressive") not in ("none", "moderate", "aggressive"):
        raise ValueError("optimization must be 'none', 'moderate', or 'aggressive'")
    # Ask NumPy to validate the casting spelling even when no output was supplied.
    np.can_cast(np.dtype("float64"), np.dtype("float64"), casting=options.get("casting", "same_kind"))


def _evaluate_ordered_output(expr, order):
    """Allocate using NumPy's broadcast iteration order without reading operands."""
    arrays = [value for value in expr.operands.values() if type(value) is np.ndarray]
    if order == "C" or not arrays:
        return np.empty(expr.shape, dtype=expr.dtype, order="F" if order == "F" else "C")
    try:
        broadcast_shape = np.broadcast_shapes(*(value.shape for value in arrays))
    except ValueError:
        broadcast_shape = None  # Reduced intermediates may broadcast even when inputs do not.
    if broadcast_shape == expr.shape:
        with np.nditer(
            [*arrays, None],
            flags=["zerosize_ok", "refs_ok"],
            op_flags=[["readonly"] for _ in arrays] + [["writeonly", "allocate"]],
            op_dtypes=[None for _ in arrays] + [expr.dtype],
            order=order,
        ) as iterator:
            return iterator.operands[-1]
    # Reductions/shape-changing expressions do not share the input iteration domain.
    fortran = order == "F" or (order in {"A", "K"} and all(a.flags.f_contiguous for a in arrays))
    return np.empty(expr.shape, dtype=expr.dtype, order="F" if fortran else "C")


def _array_owner(value):
    while True:
        base = value.obj if isinstance(value, memoryview) else getattr(value, "base", None)
        if base is None:
            return value
        value = base


@remember_evaluation
@blosc2.jit_config.math_execution
def evaluate(
    ex: str,
    local_dict: dict | None = None,
    global_dict: dict | None = None,
    out: blosc2.Array = None,
    *,
    math_backend: str | None = None,
    **kwargs: Any,
) -> blosc2.Array:
    """
    Evaluate a string expression using the Blosc2 compute engine.

    This provides a NumExpr-style expression interface using native miniexpr
    execution and explicit NumPy fallbacks, without importing NumExpr. It allows:

    1) Use additional NumPy/Blosc2 expression functionality.
    2) Follow casting rules of NumPy more closely.
    3) Use both NumPy arrays and Blosc2 NDArrays in the same expression.

    As NDArrays can be on-disk, the expression can be evaluated without loading
    the whole array into memory (i.e. using an out-of-core approach).

    Repeated array-only reviewed arithmetic, math and reduction expressions
    without extra options reuse a bounded, operand-free preparation recipe.
    Current inputs and any supplied output are rebound on every call; otherwise
    a fresh NumPy output is allocated. Neither operand/output arrays nor numerical
    results are retained in the cache.

    Aligned C-contiguous native numeric maps with matching operand shapes bind
    directly to immutable native schedules, avoiding general lazy/storage dispatch.
    Large partitionable maps retain parallel execution with the current thread count.

    Eligible numeric arithmetic and elementwise math calls use the native
    Menudet kernels, including explicit NumPy or Blosc2 destinations. Compressed
    destinations retain bounded input tiles; matching floating storage grids use
    the compression prefilter. Unsupported signatures, aliasing and explicit
    accuracy policies retain the existing dispatch rules. Explicit compiler options
    on eligible resident maps use the option-aware Menudet compiler without
    routing through general chunk execution.

    Eligible expressions default to native interpretation through the shared
    native structural policy (single-return expression versus program), also used
    by Menudet kernels and graph-generated maps. Explicit JIT settings from
    :func:`blosc2.set_jit_options`, :func:`blosc2.jit_options` or ``ME_DSL_JIT``
    retain their existing precedence. For example, use
    ``with blosc2.jit_options(jit=True):`` to opt into best-effort JIT execution.

    Parameters
    ----------
    ex: str
        The expression to evaluate.
    local_dict: dict, optional
        The local dictionary to use when looking for operands in the expression.
        If not provided, the local dictionary of the caller will be used.
    global_dict: dict, optional
        The global dictionary to use when looking for operands in the expression.
        If not provided, the global dictionary of the caller will be used.
    out: blosc2.Array, optional
        The output array where the result will be stored. If not provided,
        a new NumPy array will be created and returned.
    math_backend: str, optional
        Math library: ``"system"``, ``"sleef"`` or ``"accelerate"``. None inherits
        the current Python/native defaults. Explicit choices override the native
        environment default and require a build supporting the requested library.
        Accelerate is macOS-only. Calls requiring its vector math retain tiled
        interpretation; arithmetic and safely lowered powers can use JIT.
        Prepared plans are cached separately for each policy.
    kwargs: Any, optional
        Accepted options are ``order``, ``casting`` and ``optimization``.
        ``optimization`` defaults to ``"aggressive"``, matching NumExpr's default.
        Constant real floating-point squares use multiplication. Aggressive optimization allows
        native multiplication chains for constant integer powers, including negative
        exponents. These can change rounding and floating-point status, but do not
        enable global fast-math or alter integer/complex base semantics. Explicit
        ``"moderate"`` or ``"none"`` retains general power for other exponents;
        constant squares still use multiplication.
        ``casting`` defaults to ``"same_kind"`` and controls conversion into an
        explicit destination, not arithmetic precision.
        ``order`` controls newly allocated NumPy output: ``"C"`` or ``"F"``
        requests contiguous row-major or column-major storage, ``"A"`` follows
        Fortran-contiguous operands when possible, and ``"K"`` (default)
        follows operand iteration order. An explicit output retains its layout
        and identity, including when it is empty. Blosc2 consumes ``order`` as
        an allocation policy; it is not forwarded to NumExpr. Resident strided
        outputs use native destination descriptors when supported. Unsupported
        operations use an explicit NumPy fallback.
        The legacy ``truediv``, ``sanitize`` and ``disable_cache`` options are no
        longer accepted. Division follows NumPy semantics, validation follows
        the expression evaluation policy, and preparation caches are automatic.

    Returns
    -------
    out: blosc2.Array
        The result of the expression evaluation.  If out is provided, the result
        will be stored in out and returned at the same time.

    Examples
    --------
    >>> import blosc2
    >>> import numpy as np
    >>> dtype = np.float64
    >>> shape = [3, 3]
    >>> size = shape[0] * shape[1]
    >>> a = np.linspace(0, 5, num=size, dtype=dtype).reshape(shape)
    >>> b = blosc2.linspace(0, 5, num=size, dtype=dtype, shape=shape)
    >>> expr = 'a * b + 2'
    >>> out = blosc2.evaluate(expr)
    >>> out
    [[ 2.        2.390625  3.5625  ]
    [ 5.515625  8.25     11.765625]
    [16.0625   21.140625 27.      ]]
    """
    if kwargs:
        validate_evaluate_options(kwargs)
    optimization = kwargs.pop("optimization", "aggressive")
    order = kwargs.pop("order", "K")
    order = order.upper()
    lexpr = _prepare_cached_evaluate(ex, local_dict, global_dict, optimization) if not kwargs else None
    if isinstance(lexpr, tuple):
        from .native_graph import _native_cached_output_ok, execute_resident

        resident, inputs = lexpr
        if order in {"C", "A", "K"} and (
            out is None
            or (
                type(out) is np.ndarray
                and out.flags.c_contiguous
                and getattr(blosc2.blosc2_ext, "native_graph_output_available", lambda: False)()
                and _native_cached_output_ok(inputs, resident[2], out)
                and not any(_array_owner(value) is _array_owner(out) for value in inputs.values())
            )
        ):
            # Admission and policy were resolved for these current arrays; execution never falls back.
            return execute_resident(resident, inputs, out=out)[0]
        # Layout/casting/storage requests retain the public output preflight and the same native plan.
        lexpr = LazyExpr(None)
        lexpr.expression = ex
        lexpr.operands = inputs
        lexpr.expression_tosave, lexpr.operands_tosave = ex, dict(inputs)
        info = resident[2].info()
        lexpr._dtype, lexpr._shape = info["dtype"], info["shape"]
        lexpr._eval_kwargs, lexpr._evaluation = None, evaluation_mode()
        lexpr._resident_native = resident
        if lexpr._evaluation == "safe":
            record_expression_metadata(lexpr)
    if lexpr is None:
        lexpr = lazyexpr(
            ex,
            local_dict=local_dict,
            global_dict=global_dict,
            out=out,
            eval_kwargs=kwargs or None,
            _frame_depth=3,
        )
    lexpr._optimization = optimization
    if out is None and (
        order == "F"
        or (
            order in {"A", "K"}
            and any(
                type(value) is np.ndarray and not value.flags.c_contiguous
                for value in lexpr.operands.values()
            )
        )
    ):
        out = _evaluate_ordered_output(lexpr, order)
    if out is not None:
        if type(out) is np.ndarray:
            if not out.flags.writeable:
                raise ValueError("output array is read-only")
            casting = kwargs.get("casting", "same_kind")
            if not np.can_cast(lexpr.dtype, out.dtype, casting=casting):
                raise TypeError(
                    f"Cannot cast result from {lexpr.dtype} to {out.dtype} with casting={casting!r}"
                )
            if np.broadcast_shapes(lexpr.shape, out.shape) != out.shape:
                raise ValueError("output shape cannot hold the expression result")
            # Snapshot overlapping inputs before any writes, including shifted
            # views. NumExpr's copy opcode itself is not overlap-safe.
            lexpr.operands = {
                name: value.copy()
                if type(value) is np.ndarray
                and (_array_owner(value) is _array_owner(out) or np.shares_memory(value, out))
                else value
                for name, value in lexpr.operands.items()
            }
        lexpr._output = out
        # The user specified an output array
        result = lexpr.compute()
        if type(out) is np.ndarray and out.size == 0 and np.shape(result) == out.shape:
            return out
        return result
    # The user did not specify an output array, so return a NumPy array
    return lexpr[()]


if __name__ == "__main__":
    from time import time

    # Create initial containers
    na1 = np.linspace(0, 10, 10_000_000, dtype=np.float64)
    a1 = blosc2.asarray(na1)
    na2 = np.copy(na1)
    a2 = blosc2.asarray(na2)
    na3 = np.copy(na1)
    a3 = blosc2.asarray(na3)
    na4 = np.copy(na1)
    a4 = blosc2.asarray(na4)
    # Interesting slice
    # sl = None
    sl = slice(0, 10_000)
    # Create a simple lazy expression
    expr = a1 + a2
    print(expr)
    t0 = time()
    nres = na1 + na2
    print(f"Elapsed time (numpy, [:]): {time() - t0:.3f} s")
    t0 = time()
    nres = evaluate_chunk("na1 + na2")
    print(f"Elapsed time (native/NumPy, [:]): {time() - t0:.3f} s")
    nres = nres[sl] if sl is not None else nres
    t0 = time()
    res = expr.compute(item=sl)
    print(f"Elapsed time (evaluate): {time() - t0:.3f} s")
    res = res[sl] if sl is not None else res[:]
    t0 = time()
    res2 = expr[sl]
    print(f"Elapsed time (getitem): {time() - t0:.3f} s")
    np.testing.assert_allclose(res, nres)
    np.testing.assert_allclose(res2, nres)

    # Complex lazy expression
    expr = blosc2.tan(a1) * (blosc2.sin(a2) * blosc2.sin(a2) + blosc2.cos(a3)) + (blosc2.sqrt(a4) * 2)
    # expr = blosc2.sin(a1) + 2 * a1 + 1
    expr += 2
    print(expr)
    t0 = time()
    nres = np.tan(na1) * (np.sin(na2) * np.sin(na2) + np.cos(na3)) + (np.sqrt(na4) * 2) + 2
    # nres = np.sin(na1[:]) + 2 * na1[:] + 1 + 2
    print(f"Elapsed time (numpy, [:]): {time() - t0:.3f} s")
    t0 = time()
    nres = evaluate_chunk("tan(na1) * (sin(na2) * sin(na2) + cos(na3)) + (sqrt(na4) * 2) + 2")
    print(f"Elapsed time (native/NumPy, [:]): {time() - t0:.3f} s")
    nres = nres[sl] if sl is not None else nres
    t0 = time()
    res = expr.compute(sl)
    print(f"Elapsed time (evaluate): {time() - t0:.3f} s")
    res = res[sl] if sl is not None else res[:]
    t0 = time()
    res2 = expr[sl]
    print(f"Elapsed time (getitem): {time() - t0:.3f} s")
    np.testing.assert_allclose(res, nres)
    np.testing.assert_allclose(res2, nres)
    print("Everything is working fine")
