#######################################################################
# Copyright (c) 2019-present, Blosc Development Team <blosc@blosc.org>
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#######################################################################

"""Persistable references to remote arrays."""

from __future__ import annotations

import asyncio
import contextlib
import json
import math
import os
import tempfile
import threading
import weakref
from collections.abc import Mapping
from contextlib import nullcontext
from functools import wraps
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from urllib.parse import parse_qsl, urlsplit, urlunsplit

import numpy as np

import blosc2
from blosc2.b2objects import (
    _B2OBJECT_USER_VLMETA_KEY,
    make_b2object_carrier,
    read_b2object_payload,
    read_b2object_user_vlmeta,
    write_b2object_payload,
    write_b2object_user_vlmeta,
)
from blosc2.core import fsspec_cache_path, parse_container_url, storage_options_fingerprint
from blosc2.info import InfoReporter, format_nbytes_info
from blosc2.remote_object import RemoteObject

DEFAULT_DISK_CACHE_BYTES = 256 * 2**20


class RemoteMetadataMapping(Mapping):
    """Read-only dictionary-like mapping of remote array metadata."""

    def __init__(self, data: Mapping | None = None):
        self._data = dict(data) if data is not None else {}

    def __getitem__(self, key: str | slice) -> Any:
        if isinstance(key, slice):
            if key.start is None and key.stop is None and key.step is None:
                return self.getall()
            raise NotImplementedError("Slicing is not supported, unless [:]")
        return self._data[key]

    def __iter__(self):
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, key: object) -> bool:
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def getall(self) -> dict[str, Any]:
        return self._data.copy()

    def copy(self) -> dict[str, Any]:
        return self._data.copy()

    def __repr__(self) -> str:
        return repr(self._data)

    def __str__(self) -> str:
        return str(self._data)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Mapping):
            return self._data == dict(other)
        return False


class _PolicyDefault:
    def __repr__(self) -> str:
        return "<policy default>"


CACHE_POLICY_DEFAULT = _PolicyDefault()
_INTERNAL_CARRIER_METALAYERS = frozenset({"b2o", "proxy", "proxy-source"})
_C2_INTERNAL_VLMETA_KEYS = frozenset({"fill_nonce", "fill_state"})
_SENSITIVE_QUERY_PARTS = (
    "credential",
    "signature",
    "signed",
    "token",
    "password",
    "secret",
    "key",
    "sig",
    "expires",
)


def _normalize_source_format(urlpath, source_format):
    if source_format not in {None, "blosc2", "zarr", "hdf5", "b2z"}:
        raise ValueError("source_format must be None, 'blosc2', 'zarr', 'hdf5', or 'b2z'")
    if source_format is not None:
        return source_format
    if isinstance(urlpath, blosc2.ZarrNDSource):
        return "zarr"
    if isinstance(getattr(blosc2, "HDF5NDSource", None), type) and isinstance(urlpath, blosc2.HDF5NDSource):
        return "hdf5"
    if isinstance(urlpath, str):
        _, _, hint = parse_container_url(urlpath)
        if hint is not None:
            return hint
    return "blosc2"


def _validate_assume_immutable(value, name="assume_immutable"):
    if not isinstance(value, bool):
        raise TypeError(f"{name} must be a bool")
    return value


def _hdf5_index_from_carrier(carrier):
    """Decode the native HDF5 index a carrier stores, if present."""
    if carrier is None:
        return None
    raw_hdf5_index = getattr(carrier, "schunk", carrier).vlmeta.get("hdf5-index")
    if raw_hdf5_index is None:
        return None
    try:
        import ujson as json_mod
    except ImportError:
        import json as json_mod
    return json_mod.loads(blosc2.decompress(raw_hdf5_index).decode("utf-8"))


def _store_hdf5_index(carrier, hdf5_index):
    """Keep the native HDF5 index on the carrier so a reopen needs no rescan."""
    if hdf5_index is None:
        return
    try:
        import ujson as json_mod
    except ImportError:
        import json as json_mod
    carrier.schunk.vlmeta["hdf5-index"] = blosc2.compress(
        json_mod.dumps(hdf5_index).encode("utf-8"), typesize=1
    )


def _publish_hdf5_index(path, carrier, *, scanned):
    if path is None or carrier is None:
        return
    raw_hdf5_index = getattr(carrier, "schunk", carrier).vlmeta.get("hdf5-index")
    if raw_hdf5_index is None:
        return  # Local h5py readers have no native index to share.
    if scanned or not path.exists():
        from blosc2.remote_store_cache import atomic_write

        # Also seed the shared snapshot when reopening an older leaf cache.
        atomic_write(path, raw_hdf5_index)


def _b2z_seed_from_carrier(carrier):
    """Decode the cached B2Z bootstrap a carrier stores, if present."""
    if carrier is None:
        return None
    seed = getattr(carrier, "schunk", carrier).vlmeta.get("b2z-frame")
    # Older experimental carriers used a JSON blob; rebuild their bootstrap.
    return seed if isinstance(seed, dict) and seed.get("version") == 1 else None


def _store_b2z_seed(carrier, seed):
    """Keep a B2Z bootstrap on the carrier so a reopen skips the remote ZIP bootstrap."""
    if seed is not None:
        schunk = getattr(carrier, "schunk", carrier)
        if getattr(schunk, "mode", "a") != "r":
            # A read-only portable carrier keeps whatever seed it already has.
            schunk.vlmeta["b2z-frame"] = seed


def _zarr_metadata_from_carrier(carrier):
    """Read the Zarr metadata snapshot, including absent metadata keys."""
    if carrier is None:
        return None
    return getattr(carrier, "schunk", carrier).vlmeta.get("zarr-metadata")


def _serialized_operation(method):
    @wraps(method)
    def locked(self, *args, **kwargs):
        owner = getattr(self, "_store_owner", None)
        with owner.lock if owner is not None else nullcontext(), self._operation_lock:
            self._check_open()
            if owner is not None and getattr(owner, "shared", False):
                self._proxy = owner.get_cache(self.src)
            cache_lock = (
                self._runtime_cache.holding_lock()
                if self._shared_runtime_cache and self._runtime_cache is not None
                else nullcontext()
            )
            with cache_lock:
                if self._shared_runtime_cache and self._proxy is not None:
                    self._proxy._refresh_shared_cache()
                try:
                    return method(self, *args, **kwargs)
                finally:
                    if self._proxy is not None and getattr(self, "is_cache_mutable", True):
                        self._proxy._enforce_cache_limit(tuple(slice(0, 0) for _ in self.shape))

    return locked


def validate_persistable_url(url: str) -> None:
    """Reject URL features that would put credentials in a portable carrier."""
    if "::" in url:
        raise ValueError("RemoteArray does not persist chained fsspec URLs")
    parsed = urlsplit(url)
    if not parsed.scheme:
        raise ValueError("RemoteArray requires a remote URL or a Caterva2 URLPath")
    if parsed.scheme.lower() in {"file", "local"}:
        raise ValueError("RemoteArray does not persist local filesystem URLs")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("RemoteArray URLs cannot contain user information")
    if parsed.fragment:
        raise ValueError("RemoteArray URLs cannot contain fragments")
    sensitive = [
        key
        for key, _ in parse_qsl(parsed.query, keep_blank_values=True)
        if any(part in key.lower() for part in _SENSITIVE_QUERY_PARTS)
    ]
    if sensitive:
        raise ValueError("RemoteArray URLs cannot contain credential-like query parameters")


def normalize_cache_limit(policy, value):
    if policy is blosc2.CachePolicy.NONE:
        if value is not CACHE_POLICY_DEFAULT:
            raise ValueError("max_cache_bytes is not applicable to CachePolicy.NONE")
        return None
    if value is CACHE_POLICY_DEFAULT:
        return DEFAULT_DISK_CACHE_BYTES
    if value is None:
        if policy is blosc2.CachePolicy.DISK:
            return None
        raise TypeError("max_cache_bytes must be a positive integer")
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("max_cache_bytes must be a positive integer")
    if value <= 0:
        raise ValueError("max_cache_bytes must be a positive integer")
    return value


def _validate_max_concurrency(value: int | None) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("max_concurrency must be a positive integer")
    if value <= 0:
        raise ValueError("max_concurrency must be a positive integer")
    return value


def _local_source_path(urlpath, enabled):
    if not enabled:
        return None, urlpath
    if not isinstance(urlpath, str) or (urlsplit(urlpath).scheme and not os.path.splitdrive(urlpath)[0]):
        raise ValueError("local cache sources must use a local filesystem path")
    urlpath = os.path.abspath(urlpath)
    return urlpath, urlpath


def _validate_payload_limit(policy: blosc2.CachePolicy, limit) -> None:
    if policy is blosc2.CachePolicy.NONE:
        if limit is not None:
            raise ValueError("persisted NONE RemoteArray cannot have max_cache_bytes")
    elif policy is blosc2.CachePolicy.DISK:
        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0):
            raise ValueError("persisted DISK RemoteArray requires positive max_cache_bytes or None")
    elif isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0:
        raise ValueError(f"persisted {policy.name} RemoteArray requires positive max_cache_bytes")


def _validate_authorized_source(
    urlpath, storage_options, source_descriptor, *, store_attachment=False, allow_local_source=False
):
    if storage_options is not None:
        raise ValueError("storage_options cannot be used with an authorized source")
    hdf5_cls = getattr(blosc2, "HDF5NDSource", ())
    if not isinstance(
        urlpath,
        (blosc2.C2Array, blosc2.FsspecNDSource, blosc2.ZarrNDSource, hdf5_cls, blosc2.B2ZNDSource),
    ):
        raise TypeError(
            "source_descriptor requires an authorized C2Array, FsspecNDSource, ZarrNDSource, "
            "HDF5NDSource, or B2ZNDSource"
        )
    assume_immutable = _validate_assume_immutable(
        source_descriptor.get("assume_immutable"), "source_descriptor assume_immutable"
    )
    if isinstance(urlpath, blosc2.C2Array):
        expected = {
            "kind": "caterva2",
            "version": 1,
            "path": urlpath.path,
            "urlbase": urlpath.urlbase,
            "assume_immutable": assume_immutable,
        }
    else:
        expected = {
            "kind": (
                "b2z"
                if isinstance(urlpath, blosc2.B2ZNDSource)
                else "hdf5"
                if isinstance(urlpath, hdf5_cls)
                else "zarr"
                if isinstance(urlpath, blosc2.ZarrNDSource)
                else "fsspec"
            ),
            "version": 1,
            "urlpath": urlpath.urlpath,
            "assume_immutable": assume_immutable,
        }
    if isinstance(urlpath, (hdf5_cls, blosc2.B2ZNDSource)):
        expected["dataset"] = urlpath.dataset
    if isinstance(urlpath, blosc2.B2ZNDSource) and urlpath._archive.urlpath != urlpath.urlpath:
        raise ValueError("B2Z source URL does not match its archive")
    if source_descriptor != expected:
        raise ValueError("source_descriptor does not match the supplied source")
    persisted_url = urlpath.urlbase if isinstance(urlpath, blosc2.C2Array) else urlpath.urlpath
    if persisted_url is not None and not (
        store_attachment
        and allow_local_source
        and (not urlsplit(persisted_url).scheme or os.path.splitdrive(persisted_url)[0])
    ):
        validate_persistable_url(persisted_url)
    return urlpath, dict(expected)


def _open_url_source(
    urlpath: str,
    max_concurrency: int | None,
    *,
    traffic=None,
    persistable=True,
    storage_options=None,
    source_format=None,
    assume_immutable=True,
    dataset=None,
    hdf5_index=None,
    seed=None,
    blocks=None,
    cparams=None,
    source_cache_dir=None,
    hdf5_index_explicit=True,
    local_source=False,
    _filesystem=None,
):
    if persistable and not local_source:
        validate_persistable_url(urlpath)
    kwargs = {} if max_concurrency is None else {"max_concurrency": max_concurrency}
    if storage_options is not None:
        kwargs["storage_options"] = storage_options
    source_format = _normalize_source_format(urlpath, source_format)
    if source_format == "zarr":
        if not assume_immutable:
            raise NotImplementedError("mutable Zarr sources are not supported")
        store = _filesystem.get_mapper(urlpath) if _filesystem is not None else urlpath
        src = blosc2.ZarrNDSource(
            store,
            _urlpath=urlpath if _filesystem is not None else None,
            _traffic=traffic,
            _metadata=seed,
            blocks=blocks,
            cparams=cparams,
            **kwargs,
        )
        source = {
            "kind": "zarr",
            "version": 1,
            "urlpath": urlpath,
            "assume_immutable": assume_immutable,
        }
    elif source_format == "hdf5":
        if _filesystem is not None:
            kwargs["_filesystem"] = _filesystem
        if not assume_immutable:
            raise NotImplementedError("mutable HDF5 sources are not supported")
        if dataset is None:
            raise ValueError("HDF5 sources require a dataset path (e.g., dataset='d0/d1/a2')")
        src = blosc2.HDF5NDSource(
            urlpath,
            dataset,
            hdf5_index=hdf5_index,
            _source_cache_dir=source_cache_dir,
            _index_explicit=hdf5_index_explicit,
            _traffic=traffic,
            blocks=blocks,
            cparams=cparams,
            **kwargs,
        )
        source = {
            "kind": "hdf5",
            "version": 1,
            "urlpath": urlpath,
            "dataset": src.dataset,
            "assume_immutable": assume_immutable,
        }
    elif source_format == "b2z":
        if _filesystem is not None:
            kwargs["_filesystem"] = _filesystem
        if not assume_immutable:
            raise NotImplementedError("mutable B2Z sources are not supported")
        src = blosc2.B2ZNDSource(
            urlpath, dataset, _traffic=traffic, _seed=seed, _source_cache_dir=source_cache_dir, **kwargs
        )
        source = {
            "kind": "b2z",
            "version": 1,
            "urlpath": urlpath,
            "dataset": src.dataset,
            "assume_immutable": True,
        }
    else:
        if _filesystem is not None:
            kwargs["_filesystem"] = _filesystem
        src = blosc2.FsspecNDSource(urlpath, _traffic=traffic, **kwargs)
        source = {
            "kind": "fsspec",
            "version": 1,
            "urlpath": urlpath,
            "assume_immutable": assume_immutable,
        }
    return src, source


def _validate_cache_locations(cache_policy, cache_dir, cache_path, carrier, runtime_cache_path):
    if cache_dir is not None and cache_path is not None:
        raise ValueError("cache_dir and cache_path are mutually exclusive")
    if cache_policy is not blosc2.CachePolicy.DISK and (cache_dir is not None or cache_path is not None):
        raise ValueError("cache_dir and cache_path require CachePolicy.DISK")
    if (
        cache_policy is blosc2.CachePolicy.DISK
        and cache_dir is None
        and cache_path is None
        and carrier is None
        and runtime_cache_path is None
    ):
        raise ValueError("CachePolicy.DISK requires cache_dir or cache_path")


def _validate_urlpath_source(source, expected_fields, kind_name):
    if set(source) != expected_fields:
        raise ValueError(f"{kind_name} RemoteArray source descriptors contain unsupported fields")
    urlpath = source.get("urlpath")
    if not isinstance(urlpath, str):
        raise TypeError(f"{kind_name} RemoteArray sources require a string 'urlpath'")
    return urlpath


def _parse_source_from_payload(source):
    if not isinstance(source, dict) or source.get("version") != 1:
        raise ValueError("unsupported RemoteArray source descriptor")
    source_kind = source.get("kind")
    if source_kind == "fsspec":
        urlpath = _validate_urlpath_source(
            source, {"kind", "version", "urlpath", "assume_immutable"}, "fsspec"
        )
    elif source_kind == "caterva2":
        if set(source) != {"kind", "version", "path", "urlbase", "assume_immutable"}:
            raise ValueError("Caterva2 RemoteArray source descriptors contain unsupported fields")
        path = source.get("path")
        urlbase = source.get("urlbase")
        if not isinstance(path, str) or (urlbase is not None and not isinstance(urlbase, str)):
            raise TypeError("Caterva2 RemoteArray sources require string 'path' and 'urlbase' fields")
        urlpath = blosc2.URLPath(path, urlbase=urlbase)
    elif source_kind == "zarr":
        urlpath = _validate_urlpath_source(
            source, {"kind", "version", "urlpath", "assume_immutable"}, "Zarr"
        )
    elif source_kind in {"hdf5", "b2z"}:
        urlpath = _validate_urlpath_source(
            source, {"kind", "version", "urlpath", "dataset", "assume_immutable"}, source_kind.upper()
        )
        dataset = source.get("dataset")
        if not isinstance(dataset, str):
            raise TypeError(f"{source_kind.upper()} RemoteArray sources require a string 'dataset'")
    else:
        raise ValueError(f"unsupported RemoteArray source kind: {source_kind!r}")
    _validate_assume_immutable(source.get("assume_immutable"), "source assume_immutable")
    return source_kind, urlpath


def _source_format_with_index(urlpath, source_format, hdf5_index):
    """Fold an explicit HDF5 index into the requested source format."""
    if hdf5_index is None:
        return source_format
    if isinstance(urlpath, (blosc2.URLPath, blosc2.C2Array)):
        raise ValueError("hdf5_index is not supported for Caterva2 inputs")
    if source_format not in {None, "hdf5"}:
        raise ValueError("hdf5_index is only supported for HDF5 sources")
    return "hdf5"


def _resolve_init_dataset_and_url(urlpath, dataset, source_format, hdf5_index=None):
    if isinstance(urlpath, (blosc2.URLPath, blosc2.C2Array)) and source_format is not None:
        raise ValueError("source_format is not supported for Caterva2 inputs")
    urlpath, parsed_dataset, detected_format = parse_container_url(urlpath, dataset)
    if dataset is None:
        dataset = parsed_dataset
    if source_format is None:
        source_format = detected_format
    source_format = _source_format_with_index(urlpath, source_format, hdf5_index)
    resolved_format = _normalize_source_format(urlpath, source_format)
    if dataset is not None and resolved_format not in {"hdf5", "zarr", "b2z"}:
        raise ValueError("dataset is only supported for HDF5 and Zarr sources or B2Z archives")

    if resolved_format == "zarr":
        if dataset is not None:
            resolved_dataset = dataset.strip("/")
            if isinstance(urlpath, str):
                parsed = urlsplit(urlpath)
                clean_path = parsed.path.rstrip("/")
                if not clean_path.endswith(f"/{resolved_dataset}"):
                    new_path = f"{clean_path}/{resolved_dataset}"
                    urlpath = urlunsplit(
                        (
                            parsed.scheme,
                            parsed.netloc,
                            new_path,
                            parsed.query,
                            parsed.fragment,
                        )
                    )
            elif not str(urlpath).rstrip("/").endswith(f"/{resolved_dataset}"):
                urlpath = f"{str(urlpath).rstrip('/')}/{resolved_dataset}"
        elif isinstance(urlpath, str):
            parsed = urlsplit(urlpath)
            clean_path = parsed.path.rstrip("/")
            if ".zarr/" in clean_path.lower():
                idx = clean_path.lower().find(".zarr/")
                resolved_dataset = clean_path[idx + 6 :].strip("/") or None
            else:
                resolved_dataset = None
        else:
            resolved_dataset = None
    elif resolved_format in {"hdf5", "b2z"}:
        resolved_dataset = dataset.strip("/") if dataset is not None else None
    else:
        resolved_dataset = None

    return urlpath, resolved_dataset, resolved_format


class RemoteArray(RemoteObject, blosc2.Operand):
    """A persistable, optionally self-caching reference to a remote array.

    ``blosc2.open(local_path, cache_dir=...)`` also returns this read-only
    wrapper for local arrays; these local references cannot be exported.

    With :attr:`CachePolicy.DISK`, the public constructor uses the persisted
    B2ND carrier itself as the bounded cache. Use
    ``blosc2.open(url, cache_dir=..., shared_cache=True)`` for a process-shared
    sparse runtime cache. Server code can also use :meth:`with_sparse_cache`
    for advanced attachment beside a portable carrier. With
    :attr:`CachePolicy.MEMORY`, chunks are retained in process memory up to a bounded size. With
    :attr:`CachePolicy.NONE`, reads retain no data.

    .. note::

       RemoteArray manages supported remote sources and their portable
       descriptors, using :ref:`Proxy` internally for reads and caching. For a
       custom source implementing :ref:`ProxyNDSource` or :ref:`ProxySource`,
       use Proxy directly; RemoteArray does not accept arbitrary source objects.

    Parameters
    ----------
    urlpath: str, URLPath, or C2Array
        A B2ND or Zarr array URL, an HDF5 or B2Z container URL with a
        ``dataset`` selection, or a Caterva2 array reference.
    cache_policy: CachePolicy
        ``NONE`` retains no array data. ``MEMORY`` retains compressed chunks
        in client process memory. ``DISK`` retains compressed chunks in
        the RemoteArray carrier at ``cache_path`` or under ``cache_dir``.
    cache_path: str or path-like, optional
        Exact persistent cache filename. Only valid with ``DISK`` and mutually
        exclusive with ``cache_dir``.
    cache_dir: str or path-like, optional
        Directory in which a source-derived persistent cache filename is made.
        Only valid with ``DISK``.
        HDF5 leaves also share a native container index here, avoiding
        repeated discovery scans when opening sibling datasets.
    max_cache_bytes: int or None, optional
        Post-operation compressed-payload bound. It defaults to 256 MiB for
        ``DISK`` and ``MEMORY``. Passing ``None`` with ``DISK`` disables cache
        eviction (unbounded cache). ``MEMORY`` requires a finite positive integer.
        It is not applicable to ``NONE``.
    max_concurrency: int, optional
        Maximum number of independent remote fetches in flight.
    storage_options: dict, optional
        Parameters passed to the underlying ``fsspec`` filesystem when opening
        an fsspec URL.
    source_format: {None, "blosc2", "zarr", "hdf5", "b2z"}, optional
        Format of a URL source, inferred from its container suffix when omitted.
    path: str, optional
        Array path within an HDF5, Zarr, or B2Z container. B2Z supports external
        NDArray leaves in immutable archives, e.g. ``path="d0/a3"``.
        None leaves selection unspecified; ``""`` and ``"/"`` select the root.
        Do not combine with a selector embedded in the URL.
    dataset: str, optional
        Supported alias of ``path``. If both are given, they must agree after
        stripping leading/trailing slashes.
    hdf5_index: dict, str, or path-like, optional
        Pre-computed native HDF5 index for the dataset, or a local or remote
        fsspec URL to its JSON encoding. It must match the source URL and dataset
        scope. Legacy HDF5 reference maps are rejected; omit it to scan the
        source and build a native index.
    assume_immutable: bool, optional
        Skip remote identity checks before reads. Defaults to ``True``. Set to
        ``False`` when the object at the URL may be replaced.
    """

    def __init__(
        self,
        urlpath,
        *,
        cache_policy=blosc2.CachePolicy.NONE,
        cache_path=None,
        cache_dir=None,
        max_cache_bytes=CACHE_POLICY_DEFAULT,
        max_concurrency: int | None = None,
        storage_options: dict | None = None,
        source_format: str | None = None,
        assume_immutable: bool = True,
        dataset: str | None = None,
        path: str | None = None,
        hdf5_index=None,
        _carrier=None,
        _runtime_cache_path=None,
        _source_descriptor=None,
        _source_blocks=None,
        _source_cparams=None,
        _store_owner=None,
        _runtime_is_mutable: bool = True,
        _defer_cache: bool = False,
        _shared_cache: bool = False,
        _local_source: bool = False,
    ):
        dataset = blosc2.core.resolve_dataset_path(dataset, path)
        if not isinstance(cache_policy, blosc2.CachePolicy):
            raise TypeError("cache_policy must be a blosc2.CachePolicy instance")
        assume_immutable = _validate_assume_immutable(assume_immutable)
        if _store_owner is None:
            _validate_cache_locations(cache_policy, cache_dir, cache_path, _carrier, _runtime_cache_path)

        self._store_owner = _store_owner
        self._store_generation = _store_owner.generation if _store_owner is not None else None
        self._cache_policy = cache_policy
        self._cache_limit = normalize_cache_limit(cache_policy, max_cache_bytes)
        self._max_concurrency = _validate_max_concurrency(max_concurrency)
        urlpath, self._dataset, self._source_format = _resolve_init_dataset_and_url(
            urlpath, dataset, source_format, hdf5_index
        )
        _local_source = _local_source and cache_policy is blosc2.CachePolicy.DISK
        self._local_source = _local_source
        self._local_source_path, urlpath = _local_source_path(urlpath, _local_source)
        self._authorized_source = _source_descriptor is not None
        hdf5_index_explicit = hdf5_index is not None
        shared_index_path = None
        if (
            not self._authorized_source
            and self._source_format == "hdf5"
            and cache_policy is blosc2.CachePolicy.DISK
            and cache_dir is not None
            and hdf5_index is None
        ):
            shared_index_path = Path(
                fsspec_cache_path(
                    urlpath,
                    cache_dir,
                    ".hdf5-index.b2",
                    storage_options=storage_options,
                    create_parent=not _defer_cache,
                )
            )
        if self._authorized_source:
            self.src, self._source = _validate_authorized_source(
                urlpath,
                storage_options,
                _source_descriptor,
                store_attachment=_store_owner is not None,
                allow_local_source=getattr(_store_owner, "local_source", False),
            )
        else:
            read_seed = (
                _zarr_metadata_from_carrier if self._source_format == "zarr" else _b2z_seed_from_carrier
            )
            seed = read_seed(_carrier) if self._source_format in {"b2z", "zarr"} else None
            if hdf5_index is None and _carrier is not None:
                hdf5_index = _hdf5_index_from_carrier(_carrier)
            elif (
                hdf5_index is None
                and _carrier is None
                and cache_policy is blosc2.CachePolicy.DISK
                and (cache_dir is not None or cache_path is not None)
                and self._source_format in {"hdf5", "b2z", "zarr"}
            ):
                # A DISK carrier already holds the container bootstrap from a
                # previous run; reuse it rather than redoing the remote discovery.
                path = self._carrier_path(
                    cache_dir, cache_path, urlpath, storage_options, create_parent=not _defer_cache
                )
                if os.path.exists(path):
                    with contextlib.suppress(Exception):
                        cached = blosc2.blosc2_ext.open(path, "r", 0, dparams=blosc2.DParams(nthreads=1))
                        if self._source_format == "hdf5":
                            hdf5_index = _hdf5_index_from_carrier(cached)
                        else:
                            seed = read_seed(cached)
            if hdf5_index is None and shared_index_path is not None:
                # Disposable metadata: an absent or damaged snapshot needs a fresh scan.
                from blosc2.hdf5_source import validate_hdf5_index

                with contextlib.suppress(OSError, ValueError, RuntimeError):
                    candidate = json.loads(blosc2.decompress(shared_index_path.read_bytes()))
                    hdf5_index = validate_hdf5_index(candidate, urlpath)
            self.src, self._source = self._open_source(
                urlpath,
                self._max_concurrency,
                persistable=cache_policy is not blosc2.CachePolicy.MEMORY,
                storage_options=storage_options,
                source_format=self._source_format,
                assume_immutable=assume_immutable,
                dataset=self._dataset,
                hdf5_index=hdf5_index,
                seed=seed,
                blocks=_source_blocks,
                cparams=_source_cparams,
                source_cache_dir=cache_dir if cache_policy is blosc2.CachePolicy.DISK else None,
                hdf5_index_explicit=hdf5_index_explicit,
                local_source=_local_source,
            )
            if _local_source:
                self.src.stamp = ("local", urlpath, self._dataset, self._source_format)
        self._assume_immutable = assume_immutable
        self._storage_options = storage_options
        self._refresh_cache_dir = cache_dir
        self._source_blocks = _source_blocks
        self._source_cparams = _source_cparams
        if _shared_cache:
            _runtime_cache_path = self._carrier_path(cache_dir, None) + ".cache"
        self._runtime_urlpath = self._runtime_source(urlpath)
        self._expected_geometry = self._geometry(self.src)
        self._expected_cparams = self.src.cparams
        self._refresh_lock = threading.Lock()
        self._operation_lock = threading.RLock()
        self._closed = False
        self._proxy = None
        self._carrier = _carrier
        self._runtime_cache = _carrier if cache_policy is blosc2.CachePolicy.DISK else None
        self._shared_runtime_cache = _runtime_cache_path is not None
        self._cache_status = None
        self._cached_meta = None
        self._cached_vlmeta = None
        self._meta_mapping = None
        self._vlmeta_mapping = None
        self._runtime_is_mutable = _runtime_is_mutable
        self._mutable = False

        self._deferred_cache = (
            cache_dir,
            cache_path,
            _runtime_cache_path,
            shared_index_path,
            hdf5_index is None,
        )
        if not _defer_cache:
            self._complete_deferred_cache()

        if _store_owner is not None:
            _store_owner.acquire()
            self._store_owner = _store_owner
            self._store_finalizer = weakref.finalize(self, _store_owner.release)

    def _complete_deferred_cache(self):
        if self._deferred_cache is None:
            return
        cache_dir, cache_path, runtime_cache_path, shared_index_path, scanned = self._deferred_cache
        self._initialize_runtime_cache(cache_dir, cache_path, runtime_cache_path)
        self._publish_source_cache()
        _publish_hdf5_index(shared_index_path, self._carrier, scanned=scanned)
        if self._carrier is not None:
            if self._cached_meta is None:
                self._cached_meta = self._meta_from_carrier(self._carrier)
            if self._cached_vlmeta is None:
                self._cached_vlmeta = read_b2object_user_vlmeta(self._carrier)
        self._deferred_cache = None

    def _publish_source_cache(self):
        if not self._authorized_source and isinstance(self.src, blosc2.B2ZNDSource):
            publish = getattr(self.src._archive, "publish_source", None)
            if publish is not None:
                publish()
        if (
            not self._authorized_source
            and isinstance(self.src, blosc2.HDF5NDSource)
            and self.src._source_cache_path is not None
        ):
            from blosc2.hdf5_source import publish_hdf5_source_cache

            _store_hdf5_index(self._carrier, self.src._hdf5_index)
            publish_hdf5_source_cache(
                self.src._source_cache_path,
                self.src._blob,
                self.src._hdf5_index,
                expected=self.src._source_cache_marker,
            )

    def _initialize_runtime_cache(self, cache_dir, cache_path, _runtime_cache_path):
        if self._store_owner is not None and self.cache_policy is not blosc2.CachePolicy.NONE:
            self._attach_carrier_cache()
        elif self.cache_policy is blosc2.CachePolicy.DISK:
            if _runtime_cache_path is not None:
                self._runtime_cache, self._cache_status = self._open_or_create_sparse_cache(
                    _runtime_cache_path
                )
            elif self._carrier is None:
                self._carrier, self._cache_status = self._open_or_create_carrier(cache_dir, cache_path)
                self._runtime_cache = self._carrier
            cache_lock = self._runtime_cache.holding_lock() if self._shared_runtime_cache else nullcontext()
            with cache_lock:
                self._attach_carrier_cache()
        elif self.cache_policy is blosc2.CachePolicy.MEMORY:
            self._attach_carrier_cache()
        if isinstance(self.src, blosc2.B2ZNDSource):
            self.src._prefetched_frame = None
            if (
                self._carrier is not None
                and self._runtime_is_mutable
                and _b2z_seed_from_carrier(self._carrier) != self.src._seed
            ):
                _store_b2z_seed(self._carrier, self.src._seed)

    def _check_open(self):
        if getattr(self, "_closed", False):
            raise RuntimeError("RemoteArray handle is closed")
        finalizer = getattr(self, "_store_finalizer", None)
        if finalizer is not None and not finalizer.alive:
            raise RuntimeError("RemoteArray handle is closed")
        if self._store_owner is not None and self._store_generation != self._store_owner.generation:
            raise RuntimeError("RemoteArray handle is stale; look it up again after refresh")

    def close(self):
        """Release this handle and any HDF5 file resources it owns.

        Closing is idempotent. Standalone HDF5 handles reject further
        operations; other standalone handles keep their no-op close behavior.
        """
        if getattr(self, "_closed", False):
            return
        owner = getattr(self, "_store_owner", None)
        if owner is not None:
            with owner.lock, self._operation_lock:
                self._closed = True
                self._store_finalizer()
                self._proxy = None
                self._runtime_cache = None
        else:
            hdf5_source = getattr(self, "src", None)
            if isinstance(hdf5_source, blosc2.HDF5NDSource):
                with self._operation_lock:
                    # Serialize against in-flight reads before closing the source.
                    self._closed = True
                    hdf5_source.close()

    def refresh(self) -> None:
        """Reload a standalone source and discard its cached payload and metadata.

        Refresh arrays obtained from a RemoteStore through the root store instead.
        Ordinary disk caches must not be used concurrently by other processes.
        """
        with self._operation_lock:
            self._check_open()
            if self._store_owner is not None:
                raise ValueError("Refresh the root RemoteStore, then retrieve this array again")
            if self._shared_runtime_cache:
                raise NotImplementedError("Shared sparse array caches cannot be refreshed directly")
            if not self.is_cache_mutable:
                raise ValueError("Cannot refresh an immutable RemoteArray carrier")

            urlpath = self._runtime_urlpath
            if isinstance(urlpath, str) and self._source_format == "zarr" and self._dataset:
                if self._local_source:
                    urlpath = str(Path(urlpath).parents[len(self._dataset.split("/")) - 1])
                else:
                    parsed = urlsplit(urlpath)
                    suffix = f"/{self._dataset}"
                    if parsed.path.endswith(suffix):
                        urlpath = urlunsplit(parsed._replace(path=parsed.path[: -len(suffix)]))
            options = {
                "cache_policy": self.cache_policy,
                "max_concurrency": self._max_concurrency,
                "storage_options": self._storage_options,
                "assume_immutable": self._assume_immutable,
                "dataset": self._dataset,
                "_local_source": self._local_source,
                "_source_blocks": self._source_blocks,
                "_source_cparams": self._source_cparams,
            }
            if isinstance(urlpath, str):
                options["source_format"] = self._source_format
            if self.cache_policy is not blosc2.CachePolicy.NONE:
                options["max_cache_bytes"] = self.max_cache_bytes

            cache_path = self.cache_path if self.cache_policy is blosc2.CachePolicy.DISK else None
            if self.cache_policy is blosc2.CachePolicy.DISK and cache_path is None:
                raise ValueError("Refresh requires a writable disk cache path")
            temporary = None
            fresh = None
            try:
                if cache_path is not None:
                    fd, temporary = tempfile.mkstemp(
                        prefix=".refresh-", suffix=".b2nd", dir=Path(cache_path).parent
                    )
                    os.close(fd)
                    os.unlink(temporary)
                    options["cache_path"] = temporary
                fresh = type(self)(urlpath, **options)
                if temporary is not None:
                    self._discard_source_snapshots()
                    os.replace(temporary, cache_path)
                    carrier = blosc2.blosc2_ext.open(cache_path, "a", 0, dparams=blosc2.DParams(nthreads=1))
                    fresh._carrier = fresh._runtime_cache = carrier
                    fresh._attach_carrier_cache()
                    fresh._cache_status = "refreshed"
                old_source = self.src
                state = fresh.__dict__.copy()
                state["_operation_lock"] = self._operation_lock
                state["_refresh_lock"] = self._refresh_lock
                state["_refresh_cache_dir"] = self._refresh_cache_dir
                self.__dict__ = state
                if isinstance(old_source, blosc2.HDF5NDSource):
                    old_source.close()
            finally:
                if temporary is not None:
                    Path(temporary).unlink(missing_ok=True)

    def _discard_source_snapshots(self):
        if self._refresh_cache_dir is None or self._local_source:
            return
        if self._source_format in {"hdf5", "b2z"}:
            from blosc2.remote_source_cache import source_cache_path

            path = source_cache_path(
                self._source["urlpath"],
                self._refresh_cache_dir,
                self._storage_options,
                kind=self._source_format,
            )
            path.unlink(missing_ok=True)
            path.with_suffix(path.suffix + ".json").unlink(missing_ok=True)
        if self._source_format == "hdf5":
            index = fsspec_cache_path(
                self._source["urlpath"],
                self._refresh_cache_dir,
                ".hdf5-index.b2",
                storage_options=self._storage_options,
            )
            Path(index).unlink(missing_ok=True)

    def _runtime_source(self, original):
        """Keep credentials in live process state, outside the descriptor."""
        if isinstance(self.src, blosc2.C2Array):
            return blosc2.URLPath(
                self.src.path,
                urlbase=self.src.urlbase,
                auth_token=self.src.auth_token,
            )
        return original

    @staticmethod
    def _geometry(src):
        return (
            tuple(src.shape),
            np.dtype(src.dtype),
            tuple(src.chunks),
            tuple(src.blocks),
        )

    def _carrier_path(
        self, cache_dir, cache_path, urlpath=None, storage_options=None, *, create_parent=True
    ):
        if cache_path is not None:
            path = os.fspath(cache_path)
            if os.path.isdir(path):
                raise ValueError("cache_path must name a file, not a directory")
            if self._local_source and (
                os.path.abspath(path) == self._local_source_path
                or (os.path.exists(path) and os.path.samefile(path, self._local_source_path))
            ):
                raise ValueError("cache_path cannot overwrite the local source")
            return path
        if urlpath is None:
            urlpath = self._source.get("urlpath", self._source_identity())
            storage_options = self._storage_options
        if self._source_format == "zarr" and self._dataset:
            parsed = urlsplit(urlpath)
            urlpath = urlunsplit(parsed._replace(path=parsed.path.rstrip("/")[: -len(self._dataset) - 1]))
        cache_dataset = self._dataset
        if self._local_source:
            cache_dataset = f"{self._source_format}::{self._dataset or ''}"
        return fsspec_cache_path(
            urlpath,
            cache_dir,
            ".b2nd",
            dataset=cache_dataset,
            storage_options=storage_options,
            create_parent=create_parent,
        )

    def _open_or_create_carrier(self, cache_dir, cache_path):
        path = self._carrier_path(cache_dir, cache_path)
        if os.path.exists(path):
            kwargs = {"dparams": blosc2.DParams(nthreads=1)}
            carrier = blosc2.blosc2_ext.open(path, "a", 0, **kwargs)
            payload = carrier.schunk.vlmeta.get("b2o")
            if payload != self._payload(mutable=True):
                raise ValueError(
                    f"the RemoteArray carrier at {path} has a different specification; "
                    "open legacy Proxy caches directly with blosc2.open(cache_path), "
                    "or choose a new cache_path"
                )
            if self._source.get("kind") == "hdf5" and "hdf5-index" not in carrier.schunk.vlmeta:
                _store_hdf5_index(carrier, getattr(self.src, "_hdf5_index", None))
            if self._source.get("kind") == "zarr" and "zarr-metadata" not in carrier.schunk.vlmeta:
                carrier.schunk.vlmeta["zarr-metadata"] = self.src._metadata
            stored = carrier.schunk.vlmeta.get("proxy-stamp")
            current = getattr(self.src, "stamp", None)
            status = (
                "invalidated/rebuilt"
                if stored is not None and current is not None and stored != current
                else "reused"
            )
            if (
                status == "invalidated/rebuilt"
                and isinstance(self.src, (blosc2.HDF5NDSource, blosc2.B2ZNDSource))
                and self._geometry(carrier) != self._geometry(self.src)
            ):
                del carrier
                return self._to_b2object_carrier(
                    urlpath=path, contiguous=True, mode="w", mutable=True
                ), status
            if status == "reused":
                if self._cached_meta is None:
                    self._cached_meta = self._meta_from_carrier(carrier)
                if self._cached_vlmeta is None:
                    self._cached_vlmeta = read_b2object_user_vlmeta(carrier)
            return carrier, status
        carrier = self._to_b2object_carrier(urlpath=path, contiguous=True, mode="w", mutable=True)
        return carrier, "created"

    def _open_or_create_sparse_cache(self, cache_path):
        """Open a server-owned sparse runtime cache or create it cold.

        This is deliberately separate from ``cache_path`` in the public
        constructor: portable RemoteArray carriers remain contiguous files.
        """
        from blosc2.remote_store_cache import lock_cache_file

        # The frame lock cannot protect a directory that does not exist yet.
        lock_path = Path(os.fspath(cache_path) + ".init.lock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with lock_path.open("a+b") as lock:
            lock_cache_file(lock, blocking=True)
            return self._open_sparse_cache(cache_path)

    def _open_sparse_cache(self, cache_path):
        path = os.fspath(cache_path)
        if os.path.exists(path):
            if not os.path.isdir(path):
                raise ValueError("runtime_cache_path must name a sparse frame directory")
            runtime = blosc2.blosc2_ext.open(path, "a", 0, dparams=blosc2.DParams(nthreads=1), locking=True)
            with runtime.holding_lock():
                if runtime.schunk.vlmeta.get("b2o") != self._payload(mutable=True):
                    raise ValueError(f"the sparse runtime cache at {path} has a different specification")
                self._validate_geometry(
                    (runtime.shape, runtime.dtype, runtime.chunks, runtime.blocks), src=self.src
                )
                stored = runtime.schunk.vlmeta.get("proxy-stamp")
                current = getattr(self.src, "stamp", None)
                status = (
                    "invalidated/rebuilt"
                    if stored is not None and current is not None and stored != current
                    else "reused"
                )
                if status == "reused":
                    if self._cached_meta is None:
                        self._cached_meta = self._meta_from_carrier(runtime)
                    if self._cached_vlmeta is None:
                        self._cached_vlmeta = read_b2object_user_vlmeta(runtime)
            return runtime, status

        if self._carrier is not None:
            self._validate_warm_seed(self._carrier)

        runtime = self._to_b2object_carrier(
            urlpath=path, contiguous=False, mode="w", locking=True, mutable=True
        )
        if self._carrier is not None:
            self._import_warm_seed(self._carrier, runtime)
        return runtime, "created"

    def _import_warm_seed(self, seed, runtime) -> None:
        """Migrate valid warm chunks once into a newly-created runtime cache."""
        seed = self._validate_warm_seed(seed)
        seed_schunk = getattr(seed, "schunk", seed)
        if seed_schunk.vlmeta.get("proxy-dirty") is not None:
            return  # An interrupted seed has no trustworthy fetched bitmap.
        stamp = getattr(self.src, "stamp", None)
        if stamp is None or seed_schunk.vlmeta.get("proxy-stamp") != stamp:
            return

        bpc = seed_schunk.vlmeta.get("proxy-fetched-bpc", 1)
        if not isinstance(bpc, int) or bpc <= 0:
            return
        key = "proxy-fetched-blocks" if bpc > 1 else "proxy-fetched"
        fetched = seed_schunk.vlmeta.get(key)
        expected_size = (seed_schunk.nchunks * bpc + 7) // 8
        if not isinstance(fetched, bytes) or len(fetched) != expected_size:
            return
        for nchunk in range(seed_schunk.nchunks):
            start = nchunk * bpc
            if any(fetched[n // 8] >> (n % 8) & 1 for n in range(start, start + bpc)):
                runtime.schunk.update_chunk(nchunk, seed_schunk.get_chunk(nchunk))
        for name in (
            "proxy-cache-sizes",
            "proxy-fetched",
            "proxy-fetched-blocks",
            "proxy-fetched-bpc",
            "proxy-index",
            "proxy-stamp",
            _B2OBJECT_USER_VLMETA_KEY,
        ):
            value = seed_schunk.vlmeta.get(name)
            if value is not None:
                runtime.schunk.vlmeta[name] = value

    def _validate_warm_seed(self, seed):
        seed = getattr(seed, "cache", seed)
        seed_schunk = getattr(seed, "schunk", seed)
        self._validate_geometry((seed.shape, seed.dtype, seed.chunks, seed.blocks))
        seed_payload = seed_schunk.vlmeta.get("b2o")
        if (
            not isinstance(seed_payload, dict)
            or seed_payload.get("kind") != "remote_array"
            or seed_payload.get("source") != self._source
        ):
            raise ValueError("the warm carrier belongs to a different remote source")
        return seed

    @classmethod
    def with_sparse_cache(
        cls,
        urlpath,
        runtime_cache_path,
        *,
        carrier=None,
        source_descriptor=None,
        max_cache_bytes=CACHE_POLICY_DEFAULT,
        max_concurrency: int | None = None,
        assume_immutable: bool = True,
    ):
        """Attach an authorized remote source to a private sparse disk cache.

        This server-facing constructor keeps the portable carrier separate from
        the mutable directory-backed runtime cache.  All processes using the
        directory must construct it through this method so frame locking and
        interrupted-mutation recovery remain enabled.

        The compressed-payload budget defaults to 256 MiB; pass
        ``max_cache_bytes=None`` for unlimited retention.
        For ordinary shared caching, prefer
        ``blosc2.open(url, cache_dir=..., shared_cache=True)``.

        ``carrier`` is the portable RemoteArray carrier.  If it contains valid
        warm chunks when the sparse runtime cache is first created, those chunks
        are copied into the runtime cache.  Both copies continue to exist until
        the server replaces the portable carrier with a cold descriptor.  After
        migration, only the runtime cache is consulted for cached data, so an
        evicted chunk cannot be resurrected from the carrier.

        Pass an already-authorized ``FsspecNDSource`` and its credential-free
        ``source_descriptor`` to retain the caller's transport and source
        snapshot. The caller must authorize and refresh that snapshot before
        each attachment; this form never reopens its URL or refreshes its source.
        """
        return cls(
            urlpath,
            cache_policy=blosc2.CachePolicy.DISK,
            max_cache_bytes=max_cache_bytes,
            max_concurrency=max_concurrency,
            assume_immutable=assume_immutable,
            _carrier=carrier,
            _runtime_cache_path=runtime_cache_path,
            _source_descriptor=source_descriptor,
        )

    @_serialized_operation
    def read_cached(self, item=(), *, nchunk=None):
        """Return ``(hit, result)`` atomically, without fetching a missing block.

        The source must already have been authorized by the caller. A miss
        returns ``(False, None)``. This operation does not refresh the source.
        """
        if self._proxy is None:
            return False, None
        if nchunk is not None:
            item = self._chunk_slice(nchunk)
        if self._proxy._missing_blocks(item):
            return False, None
        result = self._proxy._cache[item] if nchunk is None else self.schunk.get_chunk(nchunk)
        if self.is_cache_mutable:
            self._proxy._enforce_cache_limit(item)
        return True, result

    @_serialized_operation
    def cache_contains(self, item=(), *, nchunk=None):
        """Check cached coverage; use ``read_cached`` for an atomic hit/read."""
        if nchunk is not None:
            item = self._chunk_slice(nchunk)
        return self._proxy is not None and not self._proxy._missing_blocks(item)

    @property
    def cached_payload_bytes(self):
        """Compressed resident payload accounting from the attached snapshot."""
        return 0 if self._proxy is None else sum(self._proxy._cache_sizes.values())

    @_serialized_operation
    def trim_cache(self, target_bytes, *, max_chunks=64):
        """Evict at most ``max_chunks`` LRU chunks toward a payload-byte target.

        Return the evicted logical chunk numbers. Allocated filesystem charge
        must be measured separately, including after a partially failed eviction.
        """
        for name, value in (("target_bytes", target_bytes), ("max_chunks", max_chunks)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        if not self.is_cache_mutable:
            raise RuntimeError("Cannot trim an immutable cache")
        if self._proxy is None:
            return ()
        return self._proxy._trim_cache(target_bytes, max_chunks=max_chunks)

    @staticmethod
    def trim_sparse_cache(runtime_cache_path, target_bytes, *, max_chunks=64):
        """Trim an offline private cache without constructing a remote source.

        The server must hold its generation lifecycle guard. Return
        ``(evicted_chunk_numbers, remaining_payload_bytes)``. A dirty cache is
        conservatively invalidated before trimming; filesystem charge still
        needs measurement because unreachable payload can remain on disk.
        """
        for value in (target_bytes, max_chunks):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError("target_bytes and max_chunks must be non-negative integers")
        cache = blosc2.blosc2_ext.open(os.fspath(runtime_cache_path), "a", 0, locking=True)
        with cache.holding_lock():
            bpc = cache.schunk.vlmeta.get("proxy-fetched-bpc", 1)

            def unavailable(*args, **kwargs):
                raise RuntimeError("offline cache maintenance cannot fetch remote data")

            source = SimpleNamespace(
                shape=cache.shape,
                dtype=cache.dtype,
                chunks=cache.chunks,
                blocks=cache.blocks,
                cparams=cache.cparams,
                stamp=cache.schunk.vlmeta.get("proxy-stamp"),
                blocks_per_chunk=bpc,
                wants_blocks=unavailable,
                chunk_layout=unavailable,
                block_plan=unavailable,
                read_range=unavailable,
            )
            backend = blosc2.Proxy(source, _cache=cache, _refresh_source=False, _persistent_dirty=True)
            evicted = backend._trim_cache(target_bytes, max_chunks=max_chunks)
            return evicted, sum(backend._cache_sizes.values())

    def _attach_carrier_cache(self):
        if self._store_owner is not None and self.cache_policy is not blosc2.CachePolicy.NONE:
            self._proxy = self._store_owner.get_cache(self.src)
            return
        if self.cache_policy is blosc2.CachePolicy.DISK:
            if self._runtime_cache is None:
                self._proxy = None
                return
            if not getattr(self, "_runtime_is_mutable", True):
                self._runtime_cache.schunk.mode = "r"
                self._proxy = blosc2.Proxy(
                    self.src,
                    _cache=self._runtime_cache,
                    mode="r",
                    _refresh_source=False,
                    _max_cache_bytes=self._cache_limit,
                    _persistent_dirty=False,
                )
                return
            if getattr(self.src, "stamp", None) is None:
                # Without a stable validator, cached bytes cannot be trusted across
                # independent opens. Reads still work, but misses are not retained.
                self._proxy = None
                return
            self._proxy = blosc2.Proxy(
                self.src,
                _cache=self._runtime_cache,
                _refresh_source=False,
                _max_cache_bytes=self._cache_limit,
                _persistent_dirty=self._shared_runtime_cache,
            )
        elif self.cache_policy is blosc2.CachePolicy.MEMORY:
            proxy = blosc2.Proxy(
                self.src,
                _refresh_source=False,
                _max_cache_bytes=self._cache_limit,
            )
            if self._carrier is not None:
                self._import_warm_seed(self._carrier, proxy._cache)
                proxy = blosc2.Proxy(
                    self.src,
                    _cache=proxy._cache,
                    _refresh_source=False,
                    _max_cache_bytes=self._cache_limit,
                )
            self._proxy = proxy
        else:
            self._proxy = None

    @staticmethod
    def _open_source(
        urlpath,
        max_concurrency,
        *,
        traffic=None,
        persistable=True,
        storage_options: dict | None = None,
        source_format: str | None = None,
        assume_immutable: bool = True,
        dataset: str | None = None,
        hdf5_index=None,
        seed=None,
        blocks=None,
        cparams=None,
        source_cache_dir=None,
        hdf5_index_explicit=True,
        local_source=False,
        _filesystem=None,
    ):
        if isinstance(urlpath, blosc2.C2Array):
            if source_format not in {None, "blosc2"}:
                raise ValueError("source_format is not supported for Caterva2 inputs")
            if storage_options is not None:
                raise ValueError("storage_options is only supported for fsspec URLs")
            src = urlpath
            if persistable and src.urlbase is not None:
                validate_persistable_url(src.urlbase)
            source = {
                "kind": "caterva2",
                "version": 1,
                "path": src.path,
                "urlbase": src.urlbase,
                "assume_immutable": assume_immutable,
            }
        elif isinstance(urlpath, blosc2.URLPath):
            if source_format not in {None, "blosc2"}:
                raise ValueError("source_format is not supported for Caterva2 URLPath inputs")
            if storage_options is not None:
                raise ValueError("storage_options is only supported for fsspec URLs")
            src = blosc2.C2Array(
                urlpath.path,
                urlbase=urlpath.urlbase,
                auth_token=urlpath.auth_token,
                _traffic=traffic,
            )
            source = {
                "kind": "caterva2",
                "version": 1,
                "path": src.path,
                "urlbase": src.urlbase,
                "assume_immutable": assume_immutable,
            }
        elif isinstance(urlpath, str):
            src, source = _open_url_source(
                urlpath,
                max_concurrency,
                traffic=traffic,
                persistable=persistable,
                storage_options=storage_options,
                source_format=source_format,
                assume_immutable=assume_immutable,
                dataset=dataset,
                hdf5_index=hdf5_index,
                seed=seed,
                blocks=blocks,
                cparams=cparams,
                source_cache_dir=source_cache_dir,
                hdf5_index_explicit=hdf5_index_explicit,
                local_source=local_source,
                _filesystem=_filesystem,
            )
        else:
            raise TypeError("RemoteArray requires a URL string, URLPath, or C2Array")

        if max_concurrency is not None and isinstance(src, blosc2.C2Array):
            src.max_concurrency = max_concurrency
        return src, source

    def _source_identity(self) -> str:
        if self._source["kind"] in {"hdf5", "b2z"}:
            return f"{self._source['urlpath']}::{self._source['dataset']}"
        if self._source["kind"] in {"fsspec", "zarr"}:
            return self._source["urlpath"]
        return f"caterva2:{blosc2.c2array._server_url(self.src.urlbase, self.src.path)}"

    def _cache_identity(self) -> str:
        """``_source_identity`` plus a fingerprint of the fsspec access options.

        Different endpoints or accounts can reach different bytes through the
        same URL, so source-derived cache names must not collide across them.
        """
        identity = self._source_identity()
        fingerprint = storage_options_fingerprint(self._storage_options)
        return f"{identity}::{fingerprint}" if fingerprint else identity

    def _validate_geometry(self, expected, *, src=None) -> None:
        if expected is None:
            return
        actual = self._geometry(self.src if src is None else src)
        normalized = (
            tuple(expected[0]),
            np.dtype(expected[1]),
            tuple(expected[2]),
            tuple(expected[3]),
        )
        if actual != normalized:
            raise ValueError(
                "RemoteArray source geometry no longer matches its carrier: "
                f"carrier={normalized}, source={actual}"
            )

    def _prepare_read(self):
        """Refresh source identity and return the backend for one operation."""
        self._check_open()
        if self._authorized_source or self._assume_immutable:
            return self._proxy if self._proxy is not None else self.src
        with self._refresh_lock:
            previous_stamp = getattr(self.src, "stamp", None)
            refresh = getattr(self.src, "refresh_identity", None)
            if refresh is None:
                refresh = getattr(self.src, "refresh_stamp", None)
            if refresh is not None:
                if isinstance(self.src, blosc2.C2Array):
                    refresh(force=True)
                else:
                    refresh()

            self._validate_geometry(self._expected_geometry)
            current_stamp = getattr(self.src, "stamp", None)
            source_changed = (
                previous_stamp is None or current_stamp is None or current_stamp != previous_stamp
            )
            if source_changed:
                fresh, _ = self._open_source(
                    self._runtime_urlpath,
                    self._max_concurrency,
                    traffic=self.traffic,
                    persistable=self.cache_policy is not blosc2.CachePolicy.MEMORY,
                    storage_options=self._storage_options,
                    source_format=self._source_format,
                    assume_immutable=self._assume_immutable,
                    dataset=self.dataset,
                    hdf5_index=getattr(self.src, "_hdf5_index", None),
                )
                if current_stamp is None and not isinstance(fresh, blosc2.C2Array):
                    # No stable validator means cached bytes cannot safely be
                    # carried from one independent operation to the next.
                    fresh.stamp = None
                self._validate_geometry(self._expected_geometry, src=fresh)
                self.src = fresh
                self._attach_carrier_cache()
                self._cached_meta = None
                self._cached_vlmeta = None
                self._meta_mapping = None
                self._vlmeta_mapping = None

            return self.src if self._proxy is None else self._proxy

    @property
    def shape(self):
        self._check_open()
        return self._expected_geometry[0]

    @property
    def dtype(self):
        self._check_open()
        return self._expected_geometry[1]

    @property
    def ndim(self) -> int:
        """The number of dimensions in the remote array."""
        return len(self.shape)

    @property
    def chunks(self):
        self._check_open()
        return self._expected_geometry[2]

    @property
    def blocks(self):
        self._check_open()
        return self._expected_geometry[3]

    @property
    def cache_policy(self) -> blosc2.CachePolicy:
        """The persisted retention policy."""
        self._check_open()
        return self._cache_policy

    @property
    def max_cache_bytes(self) -> int | None:
        """The persisted post-operation retained-cache bound."""
        self._check_open()
        return self._cache_limit

    @property
    def mutable(self) -> bool:
        """The export default mutability for future exports."""
        self._check_open()
        if self._store_owner is not None:
            return self._store_owner.mutable
        return getattr(self, "_mutable", False)

    @mutable.setter
    def mutable(self, value: bool) -> None:
        self._check_open()
        if not isinstance(value, bool):
            raise TypeError("mutable must be a boolean")
        if self._store_owner is not None:
            self._store_owner.mutable = value
        else:
            self._mutable = value

    @property
    def is_cache_mutable(self) -> bool:
        """Whether the currently opened cache is writable."""
        self._check_open()
        if self._store_owner is not None:
            return getattr(self._store_owner, "is_mutable", True)
        return getattr(self, "_runtime_is_mutable", True)

    @property
    def cparams(self):
        self._check_open()
        return self._expected_cparams

    @property
    def traffic(self):
        self._check_open()
        return getattr(self.src, "traffic", None)

    @property
    def cbytes(self) -> int:
        """Compressed source size, when supplied by the source format."""
        self._check_open()
        value = getattr(self.src, "cbytes", None)
        if value is None:
            raise NotImplementedError("This remote source does not report its compressed size")
        return int(value)

    @property
    def nbytes(self) -> int:
        """The uncompressed size of the remote array."""
        self._check_open()
        value = getattr(self.src, "nbytes", None)
        return int(value) if value is not None else math.prod(self.shape) * self.dtype.itemsize

    @property
    def info(self) -> InfoReporter:
        """A printable summary of this remote reference."""
        self._check_open()
        return InfoReporter(self)

    def _display_source(self) -> dict:
        """The source descriptor for display, masking runtime-only URLs."""
        try:
            return self.source
        except ValueError:
            # Local paths are useful for display; runtime URLs may contain credentials.
            source = dict(self._source)
            for key in ("urlpath", "urlbase"):
                url = source.get(key)
                if url is not None and (urlsplit(url).scheme or "::" in url):
                    source[key] = "<runtime-only URL>"
            return source

    def _display_identity(self) -> str:
        """`_source_identity` for display, without runtime-only credentials."""
        source = self._display_source()
        if source.get("kind") in {"hdf5", "b2z"}:
            return f"{source['urlpath']}::{source['dataset']}"
        if source.get("kind") in {"fsspec", "zarr"}:
            return source["urlpath"]
        return f"caterva2:{blosc2.c2array._server_url(source.get('urlbase'), source.get('path'))}"

    @property
    def info_items(self) -> list[tuple[str, object]]:
        """The fields shown by :attr:`info`."""
        self._check_open()
        source = self._display_source()
        return [
            ("type", type(self).__name__),
            ("source", source),
            ("shape", self.shape),
            ("chunks", self.chunks),
            ("blocks", self.blocks),
            ("dtype", self.dtype),
            ("nbytes", format_nbytes_info(self.nbytes)),
            ("cache_policy", self.cache_policy.name),
            ("cache_bytes", format_nbytes_info(self.cache_bytes)),
        ]

    @property
    def source(self) -> dict:
        """A copy of the credential-free source descriptor."""
        self._ensure_exportable_source()
        self._payload()  # Runtime-only URLs must not escape as portable descriptors.
        return dict(self._source)

    @property
    def assume_immutable(self) -> bool:
        """Whether reads skip remote identity checks."""
        self._check_open()
        return self._assume_immutable

    @property
    def meta(self) -> RemoteMetadataMapping:
        """The fixed-length metalayers of the remote array."""
        self._prepare_read()
        if self._cached_meta is None:
            self._cached_meta = self._fetch_meta()
            self._meta_mapping = None
        if self._meta_mapping is None:
            self._meta_mapping = RemoteMetadataMapping(self._cached_meta)
        return self._meta_mapping

    @property
    def vlmeta(self) -> RemoteMetadataMapping:
        """The variable-length metadata of the remote array."""
        self._prepare_read()
        if self._cached_vlmeta is None:
            self._cached_vlmeta = self._fetch_vlmeta()
            self._vlmeta_mapping = None
        if self._vlmeta_mapping is None:
            self._vlmeta_mapping = RemoteMetadataMapping(self._cached_vlmeta)
        return self._vlmeta_mapping

    @property
    def attrs(self) -> RemoteMetadataMapping:
        """The read-only user attributes of the remote array."""
        return self.vlmeta

    @staticmethod
    def _meta_from_carrier(carrier) -> dict[str, Any]:
        carrier_schunk = getattr(carrier, "schunk", carrier)
        return {
            name: carrier_schunk.meta[name]
            for name in carrier_schunk.meta
            if name not in _INTERNAL_CARRIER_METALAYERS
        }

    def _fetch_meta(self) -> dict[str, Any]:
        if isinstance(self.src, blosc2.C2Array):
            # The Caterva2 REST API (api/info) does not carry Blosc2 fixed metalayers.
            return {}
        meta = getattr(self.src, "meta", None)
        if meta is not None and isinstance(meta, Mapping):
            return {name: meta[name] for name in meta if name not in _INTERNAL_CARRIER_METALAYERS}
        return {}

    def _fetch_vlmeta(self) -> dict[str, Any]:
        vlmeta = (
            self.src.attrs if isinstance(self.src, blosc2.C2Array) else getattr(self.src, "vlmeta", None)
        )
        if vlmeta is not None and isinstance(vlmeta, Mapping):
            if isinstance(self.src, blosc2.C2Array) and self.src.meta.get("attrs") is None:
                res = {k: v for k, v in vlmeta.items() if k not in _C2_INTERNAL_VLMETA_KEYS}
            elif isinstance(vlmeta, dict):
                res = vlmeta.copy()
            else:
                res = dict(vlmeta)
        else:
            res = {}
        if self._runtime_cache is not None:
            cache_lock = (
                self._runtime_cache.holding_lock()
                if self._shared_runtime_cache and hasattr(self._runtime_cache, "holding_lock")
                else nullcontext()
            )
            with self._operation_lock, cache_lock:
                with contextlib.suppress(Exception):
                    write_b2object_user_vlmeta(self._runtime_cache, res)
        return res

    @property
    def schunk(self):
        """The underlying carrier's or cache's :class:`SChunk`, or None if unattached."""
        self._check_open()
        if self._proxy is not None:
            return self._proxy.schunk
        if self._runtime_cache is not None:
            return getattr(self._runtime_cache, "schunk", self._runtime_cache)
        if self._carrier is not None:
            return getattr(self._carrier, "schunk", self._carrier)
        return None

    @property
    def cache(self):
        """The local container used as cache, or None if caching is disabled."""
        self._check_open()
        if self._proxy is not None:
            return getattr(self._proxy, "cache", getattr(self._proxy, "_cache", None))
        return self._runtime_cache

    @property
    def urlpath(self):
        """The remote fsspec URL or credential-free Caterva2 URLPath."""
        self._check_open()
        if self._source["kind"] in {"fsspec", "zarr", "hdf5", "b2z"}:
            return self._source["urlpath"]
        return blosc2.URLPath(self._source["path"], urlbase=self._source["urlbase"])

    @property
    def dataset(self) -> str | None:
        """The dataset path within a container source, or None."""
        self._check_open()
        return self._source.get("dataset", self._dataset)

    @property
    def cache_path(self):
        """The self-caching carrier path, or ``None`` for other policies."""
        self._check_open()
        if self._carrier is None or self.cache_policy is not blosc2.CachePolicy.DISK:
            return None
        return getattr(self._carrier.schunk, "urlpath", None)

    @property
    def runtime_cache_path(self):
        """The mutable sparse cache directory, when one is attached."""
        self._check_open()
        if not self._shared_runtime_cache or self._runtime_cache is None:
            return None
        return getattr(self._runtime_cache.schunk, "urlpath", None)

    @property
    def cache_status(self):
        """How a persistent disk cache was handled, or ``None`` otherwise."""
        self._check_open()
        return self._cache_status

    @property
    def cache_bytes(self) -> int:
        """Compressed bytes currently retained by the runtime cache."""
        self._check_open()
        if self._proxy is None:
            return 0
        if self._proxy._cache_coordinator is None:
            return self._proxy.schunk.cbytes
        return self._proxy._retained_cache_bytes()

    @_serialized_operation
    def __getitem__(self, item):
        if self._store_owner is not None and self._store_owner.cache_coordinator.cached_only:
            from blosc2.remote_store import CacheMiss

            hit, value = self.read_cached(item)
            if not hit:
                raise CacheMiss
            return value
        backend = self._prepare_read()
        if isinstance(backend, blosc2.Proxy):
            if not self.is_cache_mutable:
                if backend._missing_blocks(item):
                    return blosc2.Proxy(self.src, _refresh_source=False)[item]
                return backend._cache[item]
            return backend[item]
        if isinstance(backend, blosc2.C2Array):
            # Caterva2 can evaluate slices and fancy indices server-side.  In
            # particular, do not turn a no-cache C2 read into a chunk-by-chunk
            # client assembly operation just to satisfy the fsspec backend.
            return backend[item]
        # fsspec exposes chunk/range reads rather than NumPy indexing.  Use an
        # operation-scoped Proxy so its temporary assembly state is discarded
        # as soon as this result is returned.
        proxy = blosc2.Proxy(backend, _refresh_source=False)
        return proxy[item]

    def __len__(self) -> int:
        """The length of the first dimension, like other array operands."""
        if not self.shape:
            raise TypeError("len() of unsized object")
        return self.shape[0]

    def _chunk_slice(self, nchunk: int):
        grid = tuple(math.ceil(size / chunk) for size, chunk in zip(self.shape, self.chunks, strict=True))
        total = math.prod(grid)
        if nchunk < 0 or nchunk >= total:
            raise IndexError(f"nchunk must be in range [0, {total}), got {nchunk}")
        coords = np.unravel_index(nchunk, grid)
        return tuple(
            slice(int(coord) * chunk, min((int(coord) + 1) * chunk, size))
            for coord, chunk, size in zip(coords, self.chunks, self.shape, strict=True)
        )

    @_serialized_operation
    def fetch(self, item=(), max_concurrency: int | None = None):
        """Fetch remote data into the cache container.

        Return this proxy, not a materialized array. Eviction may discard
        prefetched chunks. Use indexing for values or :meth:`materialize`
        for an independent NDArray. Requires MEMORY or DISK caching.
        """
        backend = self._prepare_read()
        if not isinstance(backend, blosc2.Proxy):
            raise NotImplementedError("fetch requires CachePolicy.DISK or CachePolicy.MEMORY")
        if not self.is_cache_mutable:
            raise RuntimeError("Cannot prefetch into an immutable cache; use indexing or get_chunk()")
        backend.fetch(item, max_concurrency=max_concurrency)
        backend._enforce_cache_limit(item)
        return self

    async def afetch(self, item=(), max_concurrency: int | None = None):
        """Prefetch in a worker thread and return this proxy, like :meth:`fetch`.

        Requires MEMORY or DISK. Cancelling the await does not interrupt an
        already running fetch, which retains the operation lock until done.
        """
        if self.cache_policy is blosc2.CachePolicy.NONE:
            raise NotImplementedError("afetch requires CachePolicy.DISK or CachePolicy.MEMORY")
        return await asyncio.to_thread(self.fetch, item, max_concurrency=max_concurrency)

    def materialize(self, item=(), **kwargs):
        """Return an independent NDArray containing the requested values.

        The output and temporary NumPy buffer are not bounded by max_cache_bytes.
        Keyword arguments are forwarded to blosc2.asarray.
        """
        return blosc2.asarray(self[item], **kwargs)

    @_serialized_operation
    def slice(self, item=(), **kwargs):
        """Return a requested selection as an independent compressed NDArray.

        Unlike :meth:`materialize`, this constructs the result with the NDArray
        slicing machinery and does not first assemble the complete selection as
        a NumPy array.  Integer indices and unit-step basic slices are supported;
        output-construction keyword arguments are forwarded to
        :meth:`NDArray.slice`.

        Fetching, result construction, and post-operation cache eviction are one
        serialized operation.  Consequently a selection may be larger than the
        retained cache budget without cached chunks disappearing while the
        result is being built.
        """
        backend = self._prepare_read()
        if isinstance(backend, blosc2.Proxy):
            if not self.is_cache_mutable and backend._missing_blocks(item):
                temporary = blosc2.Proxy(self.src, _refresh_source=False)
                temporary.fetch(item)
                return temporary._cache.slice(item, **kwargs)
            if self.is_cache_mutable:
                backend.fetch(item)
            return backend._cache.slice(item, **kwargs)
        if isinstance(backend, blosc2.C2Array):
            return backend.slice(item, **kwargs)
        temporary = blosc2.Proxy(backend, _refresh_source=False)
        temporary.fetch(item)
        return temporary._cache.slice(item, **kwargs)

    @_serialized_operation
    def get_chunk(self, nchunk: int) -> bytes:
        if self._store_owner is not None and self._store_owner.cache_coordinator.cached_only:
            from blosc2.remote_store import CacheMiss

            hit, value = self.read_cached(nchunk=nchunk)
            if not hit:
                raise CacheMiss
            return value
        backend = self._prepare_read()
        if not isinstance(backend, blosc2.Proxy):
            return backend.get_chunk(nchunk)
        item = self._chunk_slice(nchunk)
        if not self.is_cache_mutable:
            if backend._missing_blocks(item):
                return self.src.get_chunk(nchunk)
            return backend.schunk.get_chunk(nchunk)
        backend.fetch(item)
        chunk = backend.schunk.get_chunk(nchunk)
        backend._enforce_cache_limit(item)
        return chunk

    async def aget_chunk(self, nchunk: int) -> bytes:
        return await asyncio.to_thread(self.get_chunk, nchunk)

    def _payload(self, mutable=None):
        url = self._source.get("urlpath", self._source.get("urlbase"))
        if url is not None and not self._local_source:
            validate_persistable_url(url)
        return {
            "kind": "remote_array",
            "version": 1,
            "source": {**self._source, **({"local": True} if self._local_source else {})},
            "cache_policy": self.cache_policy.value,
            "max_cache_bytes": self.max_cache_bytes,
            "mutable": self.mutable if mutable is None else mutable,
        }

    def _to_b2object_carrier(self, mutable=None, **kwargs):
        carrier_excluded = _INTERNAL_CARRIER_METALAYERS | {"b2nd"}
        if self._carrier is not None:
            kwargs.setdefault(
                "meta",
                {
                    name: self._carrier.schunk.meta[name]
                    for name in self._carrier.schunk.meta
                    if name not in carrier_excluded
                },
            )
        else:
            kwargs.setdefault(
                "meta",
                {name: self.meta[name] for name in self.meta if name not in carrier_excluded},
            )
        array = make_b2object_carrier(
            "remote_array",
            self.shape,
            self.dtype,
            chunks=self.chunks,
            blocks=self.blocks,
            cparams=self.cparams,
            **kwargs,
        )
        write_b2object_payload(array, self._payload(mutable=mutable))
        user_vlmeta = dict(self.vlmeta)
        if user_vlmeta:
            write_b2object_user_vlmeta(array, user_vlmeta)
        if self._source.get("kind") == "hdf5":
            hdf5_index = getattr(self.src, "_hdf5_index", None)
            if hdf5_index is not None:
                _store_hdf5_index(array, hdf5_index)
            elif self._carrier is not None:
                carrier_schunk = getattr(self._carrier, "schunk", self._carrier)
                if "hdf5-index" in carrier_schunk.vlmeta:
                    array.schunk.vlmeta["hdf5-index"] = carrier_schunk.vlmeta["hdf5-index"]
        elif self._source.get("kind") == "zarr":
            array.schunk.vlmeta["zarr-metadata"] = self.src._metadata
        elif self._source.get("kind") == "b2z":
            seed = getattr(self.src, "_seed", None)
            if seed is not None:
                _store_b2z_seed(array, seed)
            elif self._carrier is not None:
                carrier_schunk = getattr(self._carrier, "schunk", self._carrier)
                if "b2z-frame" in carrier_schunk.vlmeta:
                    array.schunk.vlmeta["b2z-frame"] = carrier_schunk.vlmeta["b2z-frame"]
        return array

    def _export_carrier_with_policy(self, cache_policy, effective_mutable):
        carrier = self._to_b2object_carrier(mutable=effective_mutable)
        payload = self._payload(mutable=effective_mutable)
        payload["cache_policy"] = cache_policy.value
        if cache_policy is blosc2.CachePolicy.NONE:
            payload["max_cache_bytes"] = None
        elif cache_policy is blosc2.CachePolicy.DISK:
            payload["max_cache_bytes"] = (
                self.max_cache_bytes
                if self.cache_policy is not blosc2.CachePolicy.NONE
                else DEFAULT_DISK_CACHE_BYTES
            )
        else:
            payload["max_cache_bytes"] = self.max_cache_bytes or DEFAULT_DISK_CACHE_BYTES
        write_b2object_payload(carrier, payload)
        return carrier

    def _ensure_exportable_source(self):
        if self._local_source:
            raise ValueError("local-source caches cannot be exported as portable RemoteArray references")

    def _export_carrier(self, include_cache: bool, cache_policy=None, mutable=None):
        self._ensure_exportable_source()
        if not isinstance(include_cache, bool):
            raise TypeError("include_cache must be a boolean")
        effective_mutable = self.mutable if mutable is None else mutable
        if cache_policy is not None:
            if not isinstance(cache_policy, blosc2.CachePolicy):
                raise TypeError("cache_policy must be a blosc2.CachePolicy instance")
            return self._export_carrier_with_policy(cache_policy, effective_mutable)
        if include_cache and self._runtime_cache is not None:
            current_payload = getattr(self._runtime_cache, "schunk", self._runtime_cache).vlmeta.get(
                "b2o", {}
            )
            if current_payload.get("mutable") == effective_mutable:
                return self._runtime_cache
            carrier = self._to_b2object_carrier(mutable=effective_mutable)
            runtime_schunk = getattr(self._runtime_cache, "schunk", self._runtime_cache)
            for nchunk in range(runtime_schunk.nchunks):
                chunk = runtime_schunk.get_chunk(nchunk)
                if chunk is not None:
                    carrier.schunk.update_chunk(nchunk, chunk)
            for key in runtime_schunk.vlmeta:
                if key.startswith("proxy-") or key == _B2OBJECT_USER_VLMETA_KEY:
                    carrier.schunk.vlmeta[key] = runtime_schunk.vlmeta[key]
            return carrier
        if include_cache and self._proxy is not None:
            carrier = self._to_b2object_carrier(mutable=effective_mutable)
            for nchunk in self._proxy._cache_sizes:
                carrier.schunk.update_chunk(nchunk, self._proxy.schunk.get_chunk(nchunk))
            for key in self._proxy.schunk.vlmeta:
                if key.startswith("proxy-") or key == _B2OBJECT_USER_VLMETA_KEY:
                    carrier.schunk.vlmeta[key] = self._proxy.schunk.vlmeta[key]
            return carrier
        return self._to_b2object_carrier(mutable=effective_mutable)

    @_serialized_operation
    def to_cframe(
        self, *, include_cache: bool = True, cache_policy=None, mutable: bool | None = None
    ) -> bytes:
        """Export a carrier containing retained chunks by default.

        An explicit cache_policy exports a cold carrier with that policy.
        """
        if mutable is not None and not isinstance(mutable, bool):
            raise TypeError("mutable must be a boolean")
        return self._export_carrier(include_cache, cache_policy, mutable=mutable).to_cframe()

    @_serialized_operation
    def save(
        self,
        destination: str | os.PathLike | None = None,
        contiguous: bool = True,
        *,
        urlpath: str | os.PathLike | None = None,
        include_cache: bool = True,
        cache_policy=None,
        mutable: bool | None = None,
        overwrite: bool = False,
        **kwargs,
    ) -> str:
        """Save a carrier containing retained chunks by default.

        ``urlpath`` is retained as a compatibility alias for ``destination``.
        Return the written destination.
        """
        if mutable is not None and not isinstance(mutable, bool):
            raise TypeError("mutable must be a boolean")
        if destination is None:
            if urlpath is None:
                raise TypeError("save() missing required destination")
            destination = urlpath
        elif urlpath is not None:
            raise TypeError("destination and urlpath cannot both be specified")
        destination = os.fspath(destination)
        dest_real = os.path.realpath(destination)
        for attached in (self._carrier, self._runtime_cache):
            path = None if attached is None else getattr(attached.schunk, "urlpath", None)
            if path is None:
                continue
            live_real = os.path.realpath(path)
            if (
                dest_real == live_real
                or (os.path.exists(destination) and os.path.samefile(destination, path))
                or (os.path.isdir(path) and dest_real.startswith(live_real + os.sep))
            ):
                raise ValueError(
                    "cannot overwrite the attached live cache; export requires a different destination"
                )
        if os.path.exists(destination) and not overwrite:
            raise ValueError(f"destination {destination!r} already exists; use overwrite=True to replace it")
        blosc2.blosc2_ext.check_access_mode(destination, "w")
        carrier = self._export_carrier(include_cache, cache_policy, mutable=mutable)
        with tempfile.TemporaryDirectory(dir=os.path.dirname(os.path.abspath(destination))) as temp_dir:
            staged = os.path.join(temp_dir, "payload")
            carrier.save(staged, contiguous=contiguous, **kwargs)
            if os.path.exists(destination) and (os.path.isdir(destination) or not contiguous):
                # Keep the previous directory until publication succeeds.
                previous = os.path.join(temp_dir, "previous")
                os.replace(destination, previous)
                try:
                    os.replace(staged, destination)
                except BaseException:
                    os.replace(previous, destination)
                    raise
            else:
                os.replace(staged, destination)
        return destination

    @classmethod
    def _from_carrier_with_owner(cls, carrier, owner, cache_key):
        """Open a persisted carrier under a RemoteStore owner's cache policy."""
        payload = read_b2object_payload(carrier)
        allowed = {"kind", "version", "source", "cache_policy", "max_cache_bytes", "mutable"}
        if not set(payload).issubset(allowed) or payload.get("kind") != "remote_array":
            raise ValueError("CTable source column is not a RemoteArray carrier")
        if payload.get("version") != 1:
            raise ValueError(f"Unsupported persisted Blosc2 object version: {payload.get('version')!r}")
        source = payload.get("source")
        source_kind, urlpath = _parse_source_from_payload(source)
        filesystem = None
        if owner.filesystem_resolver is not None:
            if not isinstance(urlpath, str):
                raise ValueError("RemoteStore source policy cannot authorize this column source")
            filesystem = owner.filesystem_resolver(urlpath)
        hdf5_index = _hdf5_index_from_carrier(carrier) if source_kind == "hdf5" else None
        seed = (
            _zarr_metadata_from_carrier(carrier)
            if source_kind == "zarr"
            else _b2z_seed_from_carrier(carrier)
            if source_kind == "b2z"
            else None
        )
        src, descriptor = cls._open_source(
            urlpath,
            None,
            traffic=owner.traffic,
            source_format=source_kind if source_kind in {"zarr", "hdf5", "b2z"} else None,
            assume_immutable=source["assume_immutable"],
            dataset=source.get("dataset") if source_kind in {"hdf5", "b2z"} else None,
            hdf5_index=hdf5_index,
            seed=seed,
            blocks=carrier.blocks if source_kind in {"zarr", "hdf5"} else None,
            cparams=carrier.cparams if source_kind in {"zarr", "hdf5"} else None,
            _filesystem=filesystem,
        )
        expected = (
            tuple(carrier.shape),
            np.dtype(carrier.dtype),
            tuple(carrier.chunks),
            tuple(carrier.blocks),
        )
        actual = cls._geometry(src)
        if actual != expected:
            raise ValueError(f"RemoteArray source geometry no longer matches its carrier: {actual!r}")
        if owner.source_validator is not None:
            owner.source_validator(src)
        owner.sources[cache_key] = src
        owner.source_descriptors[cache_key] = descriptor
        kwargs = {}
        if owner.cache_policy is not blosc2.CachePolicy.NONE:
            kwargs["max_cache_bytes"] = owner.max_cache_bytes
        return cls(
            src,
            cache_policy=owner.cache_policy,
            _carrier=carrier,
            _source_descriptor=descriptor,
            _store_owner=owner,
            **kwargs,
        )

    @classmethod
    def _from_payload(cls, payload, carrier):
        allowed = {"kind", "version", "source", "cache_policy", "max_cache_bytes", "mutable"}
        if not set(payload).issubset(allowed) or not {
            "kind",
            "version",
            "source",
            "cache_policy",
            "max_cache_bytes",
        }.issubset(payload):
            raise ValueError("persisted RemoteArray payload contains unsupported fields")
        try:
            policy = blosc2.CachePolicy(payload.get("cache_policy"))
        except ValueError as exc:
            raise ValueError("persisted RemoteArray has an unsupported cache policy") from exc
        mutable = payload.get("mutable", False)
        if not isinstance(mutable, bool):
            raise ValueError("persisted RemoteArray mutable flag must be a boolean")
        limit = payload.get("max_cache_bytes")
        _validate_payload_limit(policy, limit)
        source = payload.get("source")
        source_kind, urlpath = _parse_source_from_payload(source)
        expected = (carrier.shape, carrier.dtype, carrier.chunks, carrier.blocks)
        kwargs = {} if policy is blosc2.CachePolicy.NONE else {"max_cache_bytes": limit}
        carrier_arg = carrier if policy in {blosc2.CachePolicy.DISK, blosc2.CachePolicy.MEMORY} else None
        hdf5_index = _hdf5_index_from_carrier(carrier) if source_kind == "hdf5" else None
        carrier_mode = getattr(carrier.schunk, "mode", "r") if carrier is not None else "r"
        is_disk_file = carrier is not None and bool(getattr(carrier.schunk, "urlpath", None))
        is_runtime_mutable = mutable and (carrier_mode != "r" if is_disk_file else True)
        obj = cls(
            urlpath,
            cache_policy=policy,
            source_format=source_kind if source_kind in {"zarr", "hdf5", "b2z"} else None,
            dataset=source.get("dataset") if source_kind in {"hdf5", "b2z"} else None,
            hdf5_index=hdf5_index,
            assume_immutable=source["assume_immutable"],
            _carrier=carrier_arg,
            _source_blocks=carrier.blocks if source_kind in {"zarr", "hdf5"} else None,
            _source_cparams=carrier.cparams if source_kind in {"zarr", "hdf5"} else None,
            _runtime_is_mutable=is_runtime_mutable,
            **kwargs,
        )
        obj._mutable = False
        obj._validate_geometry(expected)
        if not obj.is_cache_mutable and limit is not None and obj.cache_bytes > limit:
            raise ValueError(
                f"Retained immutable payload ({obj.cache_bytes} bytes) exceeds max_cache_bytes ({limit}); "
                "use a larger allowance or produce a smaller/cold export"
            )
        if carrier is not None:
            if obj._cached_meta is None:
                obj._cached_meta = obj._meta_from_carrier(carrier)
            if obj._cached_vlmeta is None:
                obj._cached_vlmeta = read_b2object_user_vlmeta(carrier)
        return obj

    def __str__(self):
        return f"RemoteArray({self._display_identity()!r}, cache_policy={self.cache_policy.name})"
